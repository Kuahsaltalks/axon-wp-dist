#!/usr/bin/env bash
#
# setup-repos.sh — one-time setup. Creates the two GitHub repos that make self-updating work.
#
#   ./setup-repos.sh
#
# WHY TWO REPOS
# -------------
# A WordPress plugin is shipped as PHP source. Anyone who downloads the zip already has all
# the code — so a private repo does not protect the code itself, and pretending otherwise
# leads to the worst option: baking an access token into a public download.
#
# What a private repo genuinely protects is everything AROUND the code: the git history,
# unreleased work, the release tooling, notes, and any keys. So:
#
#   axon-wp       (PRIVATE)  source, history, release.sh — your workshop
#   axon-wp-dist  (PUBLIC)   update.json + release zips  — your shop window
#
# Sites check the public repo, so updates work everywhere with no token, no license server,
# and nothing to keep running. Your working repo stays yours.
#
# Requires: gh (authenticated), git.

set -euo pipefail

GH_OWNER="Kuahsaltalks"
SRC_REPO="axon-wp"
DIST_REPO="axon-wp-dist"

HERE="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
DIST_DIR="$( dirname "$HERE" )/$DIST_REPO"

step() { printf '\n\033[1;36m▸ %s\033[0m\n' "$1"; }
ok()   { printf '  \033[0;32m✓\033[0m %s\n' "$1"; }
die()  { printf '\n\033[0;31m✗ %s\033[0m\n\n' "$1" >&2; exit 1; }

command -v gh  >/dev/null 2>&1 || die "'gh' is not installed."
command -v git >/dev/null 2>&1 || die "'git' is not installed."
gh auth status >/dev/null 2>&1 || die "GitHub CLI is not logged in. Run: gh auth login"

# --- private source repo -----------------------------------------------------

step "Private source repo: $GH_OWNER/$SRC_REPO"

cd "$HERE"

cat > .gitignore <<'IGNORE'
.DS_Store
*.zip
node_modules/
IGNORE

if [ ! -d .git ]; then
  git init -q
  git branch -M main
  ok "git initialised"
fi

git add -A
git commit -q -m "Axon 2.0.0 — single self-contained plugin: bundled MCP server, OAuth, 24 tools, guided setup, self-updater" 2>/dev/null || ok "already committed"

if gh repo view "$GH_OWNER/$SRC_REPO" >/dev/null 2>&1; then
  ok "repo already exists"
else
  gh repo create "$GH_OWNER/$SRC_REPO" --private --source=. --remote=origin --description "Axon — plugin source (private)" >/dev/null
  ok "created (private)"
fi

git remote get-url origin >/dev/null 2>&1 || git remote add origin "https://github.com/$GH_OWNER/$SRC_REPO.git"
git push -qu origin main
ok "pushed"

# --- public distribution repo ------------------------------------------------

step "Public distribution repo: $GH_OWNER/$DIST_REPO"

mkdir -p "$DIST_DIR"
cd "$DIST_DIR"

if [ ! -d .git ]; then
  git init -q
  git branch -M main
  ok "git initialised"
fi

cat > README.md <<'DOC'
# Axon — downloads

Install files for the **Axon** WordPress plugin.

## Install

1. Download the latest `axon-wp-*.zip` from [Releases](../../releases/latest).
2. In WordPress: **Plugins → Add New → Upload Plugin** → choose the zip → **Install Now** → **Activate**.

That is the only manual install you ever do. From then on the plugin checks this repository
for new versions and offers a normal one-click **Update now** on your Plugins screen, the
same as any plugin from WordPress.org.

## What is in here

- `update.json` — the version manifest each site reads
- Releases — the installable zips

The plugin's source code lives in a separate private repository.
DOC

# A placeholder manifest so the very first update check gets valid JSON rather than a 404.
# Version 0.0.0 is below anything installable, so no site is ever offered this as an update.
if [ ! -f update.json ]; then
  cat > update.json <<'JSON'
{
  "name": "Axon",
  "slug": "axon-wp",
  "version": "0.0.0",
  "download_url": "",
  "requires": "6.4",
  "tested": "7.0",
  "requires_php": "8.0",
  "sections": { "description": "Placeholder until the first release is published." }
}
JSON
  ok "placeholder update.json"
fi

git add -A
git commit -q -m "Distribution channel for Axon" 2>/dev/null || ok "already committed"

if gh repo view "$GH_OWNER/$DIST_REPO" >/dev/null 2>&1; then
  ok "repo already exists"
else
  gh repo create "$GH_OWNER/$DIST_REPO" --public --source=. --remote=origin --description "Axon — installable releases and update manifest" >/dev/null
  ok "created (public)"
fi

git remote get-url origin >/dev/null 2>&1 || git remote add origin "https://github.com/$GH_OWNER/$DIST_REPO.git"
git push -qu origin main
ok "pushed"

printf '\n\033[1;32m━━━ Setup complete ━━━\033[0m\n\n'
printf '  Source (private): https://github.com/%s/%s\n' "$GH_OWNER" "$SRC_REPO"
printf '  Downloads (public): https://github.com/%s/%s\n\n' "$GH_OWNER" "$DIST_REPO"
printf '  Now publish the first release:\n\n'
printf '      cd "%s"\n' "$HERE"
printf '      ./release.sh 2.0.0 "Single self-contained plugin: bundled MCP server, guided setup, one-click updates"\n\n'
