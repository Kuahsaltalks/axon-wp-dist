# Bundled: WordPress MCP Adapter v0.6.1

Source: https://github.com/WordPress/mcp-adapter
License: GPL-2.0-or-later (see LICENSE.md) — same licence as this plugin, so redistribution
inside it is permitted. Copyright and licence notices are retained unmodified.

Bundled so Waah WP MCP is a single self-contained install: a customer should never be told
"first go install two other plugins". The plugin bootstrap loads this copy ONLY when the
standalone MCP Adapter plugin is not already active, so an existing separate install always
wins and the two can never collide.

The only file not copied is the original `mcp-adapter.php` plugin bootstrap — its job (define
WP_MCP_DIR / WP_MCP_VERSION, run the autoloader, call Plugin::instance()) is done by
`waah_wp_mcp_boot_adapter()` in the main plugin file instead, with guards so nothing is
defined or instantiated twice.
