## 2.5.4 — 2026-09-15

Add Google Antigravity to Axon Admin Screen and MCP config

## 2.5.3 — 2026-09-14

Add Google Antigravity MCP direct integration & REST endpoints

## 2.5.2 — 2026-08-21

Fixes every tool disappearing on strict MCP clients. Two tools declared no parameters as an empty PHP array, which JSON-encodes to [] — but JSON Schema requires properties to be an object, {}. A strict client validates the entire tools/list response, so those two malformed entries invalidated ALL 40 tools with 'expected record, received array', naming neither the plugin nor the tools at fault. claude.ai tolerated it; another client did not. Both definitions are fixed, and schemas are now normalised centrally at registration so a future zero-argument tool cannot reintroduce it by writing the natural thing. Verified: all 40 tools now emit a valid object for properties.

## 2.5.1 — 2026-08-21

Upgrades the bundled MCP Adapter from 0.5.0 to 0.6.1, which fixes every tool call failing with 'parameters is not of type object'. The adapter release notes for 0.6.0 name the cause exactly: empty arguments were not normalised for schema-defining abilities, so a valid zero-argument tool call was rejected before it reached the ability. Verified on WordPress 7.1: the same calls that 0.5.0 refused are accepted by 0.6.1, both as an empty array and as an empty object. Bundling a dependency means owning its bugs, and this one was fixed upstream six days before it was hit here.

## 2.5.0 — 2026-08-21

Exposes every Axon tool directly to MCP clients instead of routing them all through one generic wrapper. Previously a client saw three tools and had to pass an ability name plus a parameters object to execute-ability for every call. That indirection cost three round trips per action, and made every single tool depend on the parameters object surviving serialisation intact: a client that sent it as a string got 'parameters is not of type object' and EVERY tool failed at once, with nothing in the site's logs because the request never reached the ability. Observed live on a WordPress 7.1 site. Each tool now arrives with its own name, description and schema, which is what clients are built to consume. The three generic tools remain registered so anything already using them keeps working.

## 2.4.1 — 2026-08-21

Makes a failed update check visible. When WordPress showed no update, there was nothing to look at: a genuinely current install and a site that could not reach the update server at all looked identical. The Axon screen now has a 'Why is my update not showing?' button that performs a live check, bypassing every cache, and reports the real result: whether the server is reachable, what version it advertises, when the last check happened, and on failure the actual HTTP or DNS error with what to do about it. Blocked outbound HTTPS, an intercepting proxy and a stale WordPress cache now each produce a different, specific message instead of silence.

## 2.4.0 — 2026-08-21

Adds bulk editing and malware scanning. bulk_edit applies one change across many posts: find and replace text, add or remove categories and tags, set status, set a focus keyword, or generate schema. It PREVIEWS BY DEFAULT and writes nothing until dry_run is explicitly set to false; a missing flag always means preview. Content changes go through wp_update_post so WordPress stores a revision first and any single post can be rolled back. A find string under three characters is refused because it would match inside HTML tags and URLs, and a category that does not already exist is skipped rather than invented. One call can touch at most 200 posts. scan_malware looks for executable PHP hiding in the uploads folder, core files that no longer match the official WordPress release, a short list of genuine backdoor code patterns, and optionally recently modified PHP. It is read-only and never deletes or quarantines anything, because automated removal of a false positive does more damage than the file it removes.

## 2.3.0 — 2026-08-21

Adds coded page design, with no page builder. design_page writes HTML and CSS straight into a page: the markup lives in post_content so it stays editable and revisionable in wp-admin, and the CSS is printed on that page only so it can never leak site-wide. Mode 'full' renders a blank canvas with no theme header or footer for landing pages, while 'themed' sits inside the theme. wp_head and wp_footer still run on the canvas, so Rank Math meta, JSON-LD and analytics keep working. get_design reads a page back so edits are made against what is really there. analyze_design studies a reference URL and reports its structure, colour palette, typography and layout patterns to inform an original build, without copying text, images or markup. Guardrails refuse a full HTML document, a duplicate h1, or an inline style block, each with an explanation. Replaces the earlier hardcoded single-slug landing template with a general system any page can use.

## 2.2.1 — 2026-08-21

Fixes SEO meta being written to the wrong plugin. set_seo_meta wrote Yoast's meta keys unconditionally, so on a Rank Math site every write was a silent no-op: the tool reported success while Rank Math went on showing 'Keyword: Not Set', because the two plugins use entirely different post meta keys and neither reads the other's. The tool now detects which SEO plugin the site runs and writes that plugin's keys, and reads back from whichever holds a value. This removes the need for browser automation to set focus keywords and meta descriptions after publishing.

## 2.2.0 — 2026-08-21

Adds full site control. Until now Axon could audit and optimise a site but not build one: it could change a post's status but never create a post, and could set alt text but never upload an image. New tools: create_post, update_post, get_post, list_posts, delete_post, manage_terms, upload_media, and wp_rest. Partial updates only change the fields passed, so editing a title cannot blank an excerpt. Deletion trashes by default and permanent removal needs an explicit flag. upload_media accepts a URL or base64 and enforces WordPress's own allowed file types. wp_rest reaches any REST route through WordPress's own dispatcher, so every route's permission check still applies and the tool can never exceed the connected account — it refuses only to set user passwords. Editing post content on an Elementor page now warns that the builder renders from its own data.

## 2.1.1 — 2026-08-19

Prevents FAQPage schema being generated from calls to action and site footers. A heading ending in a question mark was treated as an FAQ, so promotional prompts such as 'Not sure which programme fits you?' were marked up as questions, and because an answer runs to the next heading the final question absorbed the page footer as its answer. Google treats promotional FAQPage markup as structured data spam and can issue a manual action for it. Questions must now open with an interrogative, and the footer is removed before extraction.

## 2.1.0 — 2026-08-19

Full audit pass. Update reliability: the manifest cache now follows WordPress's own check cycle, so a release is picked up the moment core re-checks instead of waiting out an invisible private timer; cache lifetime cut from 6 hours to 1, and a failed lookup is retried after 5 minutes instead of an hour. Output correctness: HTML entities are now decoded across every tool, not just llms.txt, so titles no longer arrive as 'Fees &#038; Scholarships' and Schema.org names no longer carry markup into Google's rich results. Includes the 2.0.6 fix serving /llms.txt with a 200 status instead of 404.

## 2.0.6 — 2026-08-19

Fixes /llms.txt being served with a 404 status. WordPress resolves the path to a 404 before the plugin outputs the file, so the correct content was returned under a 'does not exist' status line and every AI crawler discarded it. Now sends an explicit 200 with Content-Length and a cache header, handles HEAD requests, and no longer sends X-Robots-Tag: noindex, which was the wrong instruction for a file that exists to be read by AI crawlers.

## 2.0.5 — 2026-08-19

Removes the theme byline tail from llms.txt descriptions on posts without a meta description. Themes print an author, date and reading time immediately after the excerpt and follow it with the nav menu, so descriptions ended with 'By Author-19 Jul 2026-5 min read HOME WHY...'. Cuts at the byline, bullet-separated post meta, or a trailing 'N min read', while leaving prose that legitimately contains an ellipsis or the word 'By' untouched.

## 2.0.4 — 2026-08-19

Fixes updates appearing to be unavailable when they exist. The plugin caches its update manifest for six hours, and only its own 'Check for updates' link cleared that cache — so WordPress's native 'Check again' reported the site as current for up to six hours after a release. A forced WordPress update check now bypasses the cache. This is why 2.0.3 did not reach sites that used the standard WordPress update workflow.

## 2.0.3 — 2026-08-19

Completes the llms.txt cleanup started in 2.0.2. Breadcrumb separators are stored as HTML entities, and 2.0.2 stripped them before decoding, so every breadcrumb survived on posts without a meta description. Text is now decoded first, the repeated post title and category label are removed whether the theme truncates the title or prints it in full, and a bare '>' is no longer treated as a breadcrumb separator because it mangled legitimate prose such as '5 > 3'.

## 2.0.2 — 2026-08-19

Fixes llms.txt generation on page-builder sites. Descriptions were being scraped from the navigation menu and breadcrumb trails instead of real page content, which would have told AI models that every page was about the site menu. Now prefers the Rank Math or Yoast meta description, then the excerpt, and only falls back to page content after stripping breadcrumbs and rejecting run-together menu text. Also excludes noindex pages from the file and decodes HTML entities in titles.

## 2.0.1 — 2026-08-19

Fixes a false 'Endpoint: no server registered' warning on the setup screen. The MCP server registers itself lazily on the first REST request, so the admin page saw an empty registry and wrongly reported a healthy site as broken. The endpoint is now verified over HTTP, and a check that cannot run shows amber rather than red.

