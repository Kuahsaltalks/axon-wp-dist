<?php
/**
 * Axon Canvas — a blank page for coded designs.
 *
 * Deliberately minimal: a valid document, the page's own markup, and nothing else. No theme
 * header, no theme footer, no entry title, no sidebar. The design in post_content is the
 * whole page.
 *
 * `wp_head()` and `wp_footer()` still run, and that matters — it is how Rank Math's meta tags,
 * this plugin's JSON-LD, analytics and anything else that hooks the document keep working. A
 * "clean" template that dropped them would silently strip the site's SEO from every page built
 * with it.
 *
 * A modest reset is included because a page with no theme has no styles at all, and the most
 * common first complaint would otherwise be "my text is touching the edge of the screen".
 * Everything here is easily overridden by the page's own CSS.
 *
 * @package Axon
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
	<style id="axon-canvas-reset">
		*, *::before, *::after { box-sizing: border-box; }
		body {
			margin: 0;
			font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
			line-height: 1.6;
			color: #1d2327;
			background: #fff;
			-webkit-font-smoothing: antialiased;
		}
		img, svg, video { max-width: 100%; height: auto; display: block; }
		a { color: inherit; }
		h1, h2, h3, h4 { line-height: 1.2; margin: 0 0 .5em; }
		p { margin: 0 0 1em; }
		/* Wide content must scroll inside itself rather than pushing the page sideways. */
		table, pre { max-width: 100%; overflow-x: auto; display: block; }
	</style>
</head>
<body <?php body_class( 'axon-canvas' ); ?>>

<?php
while ( have_posts() ) :
	the_post();

	// the_content() rather than echoing post_content raw: shortcodes, embeds and every
	// content filter the site relies on keep working inside a coded page.
	the_content();

endwhile;
?>

<?php wp_footer(); ?>
</body>
</html>
