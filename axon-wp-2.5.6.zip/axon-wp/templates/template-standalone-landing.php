<?php
/**
 * Template Name: Standalone Clean Landing Page
 * Description: Pure standalone HTML/CSS canvas template without theme header/footer overrides.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo( 'charset' ); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>IIMT Institute of Hotel Management Haldwani | Admissions 2026</title>
  <meta name="description" content="Top Hotel Management College in Haldwani, Uttarakhand. 100% Placement Record in Taj, Marriott & Oberoi. Offering BHM, Advanced Diploma & Craft Certificates.">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@600;700;800&family=Source+Sans+3:wght@400;600;700&display=swap" rel="stylesheet">
  <?php wp_head(); ?>
  <style>
    /* HARD PURGE WORDPRESS & HELLO ELEMENTOR THEME HEADERS / TITLES */
    header.site-header, 
    footer.site-footer, 
    .entry-header, 
    .entry-title, 
    h1.entry-title, 
    .site-branding, 
    .main-navigation, 
    .page-header, 
    #masthead,
    .elementor-location-header,
    .hello-header {
      display: none !important;
      visibility: hidden !important;
      height: 0 !important;
      margin: 0 !important;
      padding: 0 !important;
      overflow: hidden !important;
    }

    #page, #content, #primary, #main, .site-content, .entry-content {
      width: 100% !important;
      max-width: 100% !important;
      margin: 0 !important;
      padding: 0 !important;
      float: none !important;
      position: static !important;
      box-sizing: border-box !important;
    }
    .entry-content > * { margin-bottom: 0 !important; margin-top: 0 !important; }

    html, body {
      margin: 0 !important;
      padding: 0 !important;
      width: 100% !important;
      overflow-x: hidden !important;
      background-color: #F0F5FA !important;
      font-family: 'Source Sans 3', sans-serif !important;
      -webkit-font-smoothing: antialiased;
    }
    *, *::before, *::after { box-sizing: border-box !important; }
  </style>
</head>
<body <?php body_class(); ?> style="margin:0 !important; padding:0 !important; background:#F0F5FA !important;">

  <?php
  if ( have_posts() ) {
      while ( have_posts() ) {
          the_post();
          the_content();
      }
  }
  ?>

  <?php wp_footer(); ?>
</body>
</html>
