<?php
/**
 * Plugin Name:       Axon
 * Plugin URI:        https://github.com/Kuahsaltalks/axon-wp-dist
 * Description:       Hand your WordPress site to your AI. One install, nothing else needed: the MCP server, one-click OAuth sign-in for Claude, Codex or any MCP client, and 32 tools that create and edit content, upload media, manage taxonomies and settings, and handle SEO, speed, schema, redirects and AI-search visibility — plus direct access to any WordPress REST route. Guided setup inside the plugin, and it updates itself.
 * Version:           2.5.6
 * Requires at least: 6.9
 * Requires PHP:      8.0
 * Author:            Waah School
 * Author URI:        https://waah.school
 * License:           GPL-2.0-or-later
 * Text Domain:       axon-wp
 * Update URI:        https://github.com/Kuahsaltalks/axon-wp-dist
 *
 * WHAT THIS IS
 * ------------
 * The merge of two plugins that were always meant to be one product:
 *
 *   axon-wp-extensions 0.7.1 — the 24 MCP tools (SEO, media, workflow, speed,
 *                                  security, GEO, schema, redirects)
 *   mcp-oauth-bridge 0.2.0       — the OAuth 2.1 server that lets an MCP client connect
 *                                  without a manually copied token
 *
 * They shipped separately, were versioned separately, and had to be uploaded separately.
 * From 1.0.0 there is one plugin, one version number, one "Update now" button. Existing
 * OAuth tokens survive the merge untouched: the token store still owns the same
 * {prefix}mcp_oauth_* tables under the same class names, so a site already connected to
 * claude.ai stays connected across the upgrade.
 *
 * The `Update URI` header above does real work. Since WordPress 5.8, core skips the
 * wordpress.org update check for any plugin whose Update URI points somewhere other than
 * wordpress.org — which means a .org plugin that ever takes the "axon-wp" slug can
 * never overwrite this one with unrelated code. See includes/class-updater.php for how
 * updates are actually served.
 *
 * ABILITY REGISTRATION
 * --------------------
 * Tools reach MCP clients through the WordPress core Abilities API
 * (`wp_register_ability()`, REST namespace wp-abilities/v1), surfaced by the mcp-adapter at
 * /mcp/mcp-adapter-default-server. Categories must be registered on
 * `wp_abilities_api_categories_init` BEFORE abilities register on `wp_abilities_api_init`,
 * and `category` must be a TOP-LEVEL arg on each ability — not nested in `meta`.
 * WP_Abilities_Registry::register() catches WP_Ability's InvalidArgumentException
 * internally and returns null instead of re-throwing, so a wrong shape here fails silently
 * and no try/catch can ever see it. Check the return value, not exceptions. (0.6.0 lost all
 * 24 abilities to exactly this.)
 *
 * A second, older registration path against the Automattic wordpress-mcp plugin's
 * RegisterMcpTool API is kept below. It registers nothing on installs using the Abilities
 * API, and costs one class_exists() check when unused.
 *
 * @package Axon
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'AXON_VERSION', '2.5.6' );
define( 'AXON_DIR', plugin_dir_path( __FILE__ ) );
define( 'AXON_FILE', __FILE__ );

/**
 * Where this plugin asks about new versions.
 *
 * A static file on a CDN rather than an API call — api.github.com rate-limits
 * unauthenticated requests to 60/hour per IP, and shared hosting puts many sites behind one
 * IP, so an API-based check fails intermittently on cheap hosts. Overridable via wp-config
 * for anyone running their own release channel.
 */
if ( ! defined( 'AXON_UPDATE_MANIFEST' ) ) {
	define( 'AXON_UPDATE_MANIFEST', 'https://raw.githubusercontent.com/Kuahsaltalks/axon-wp-dist/main/update.json' );
}

// ---------------------------------------------------------------------------
// Predecessor conflict guard — MUST run before any require below
// ---------------------------------------------------------------------------

/**
 * Which superseded plugins are already loaded in this very request.
 *
 * This plugin contains copies of every class from both predecessors. `require_once` only
 * prevents loading the same FILE twice — it does nothing about a class name another file
 * already declared. Plugins load in path order, and both
 * `axon-wp-extensions/...` and `mcp-oauth-bridge/...` sort before `axon-wp/...`
 * ('-' and 'm' both precede '/'), so if either is active its classes are declared first and
 * the requires below fatal with "Cannot redeclare class".
 *
 * Deactivating them in the activation hook does not help: WordPress runs
 * plugin_sandbox_scrape() — which includes this file — BEFORE it fires the activation hook,
 * so the fatal happens while the old plugin is still loaded and the hook never runs. That
 * is a white screen on activation, on a live site, with no obvious way back.
 *
 * So the check happens here, at the top, before anything is required. If a predecessor is
 * present this plugin loads nothing at all and shows a notice with a one-click fix. The
 * site keeps running on the old plugins in the meantime — degraded to "no new features",
 * never broken.
 *
 * @return array<string, string> Plugin basename => display name.
 */
function axon_detect_predecessors() {
	$found = array();

	// The `false` second argument disables autoloading: this asks only "is this class
	// already declared", with no side effects.
	if ( class_exists( 'MCP_OAuth_Bridge\\Token_Store', false ) ) {
		$found['mcp-oauth-bridge/mcp-oauth-bridge.php'] = 'MCP OAuth Bridge';
	}
	if ( class_exists( 'Waah_MCP_SEO_Tools', false ) ) {
		$found['waah-wp-mcp-extensions/waah-wp-mcp-extensions.php'] = 'Waah School WP MCP Extensions';
	}

	return $found;
}

$axon_predecessors = axon_detect_predecessors();

if ( $axon_predecessors ) {

	/**
	 * Offer a one-click retirement of the superseded plugins.
	 *
	 * Deactivate, not delete: deactivating is reversible and their data lives in shared
	 * tables this plugin adopts as-is, so nothing is lost either way.
	 */
	function axon_predecessor_notice() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}

		$names = axon_detect_predecessors();
		if ( ! $names ) {
			return;
		}

		$url = wp_nonce_url(
			add_query_arg( 'axon_retire', '1', admin_url( 'plugins.php' ) ),
			'axon_retire'
		);

		printf(
			'<div class="notice notice-warning"><p><strong>Axon</strong> replaces %s, and cannot start while %s still active. '
			. 'Your site is unaffected and still running normally.</p><p><a href="%s" class="button button-primary">Deactivate %s and finish setup</a></p></div>',
			esc_html( implode( ' and ', $names ) ),
			count( $names ) > 1 ? 'they are' : 'it is',
			esc_url( $url ),
			count( $names ) > 1 ? 'them' : 'it'
		);
	}
	add_action( 'admin_notices', 'axon_predecessor_notice' );

	/**
	 * Handle the click from that notice.
	 */
	function axon_handle_retire() {
		if ( empty( $_GET['axon_retire'] ) || ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		if ( ! check_admin_referer( 'axon_retire' ) ) {
			return;
		}

		if ( ! function_exists( 'deactivate_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$retired = array_keys( axon_detect_predecessors() );
		deactivate_plugins( $retired, true );
		update_option( 'axon_superseded', $retired, false );

		// Force the one-time setup below to run on the next load, now that this plugin can
		// actually boot.
		delete_option( 'axon_installed_version' );

		wp_safe_redirect( admin_url( 'plugins.php' ) );
		exit;
	}
	add_action( 'admin_init', 'axon_handle_retire' );

	// Load nothing else. A top-level return in a plugin file is ordinary PHP and WordPress
	// handles it cleanly — the plugin stays "active" but inert until the conflict is gone.
	return;
}

// ---------------------------------------------------------------------------
// MCP tools
// ---------------------------------------------------------------------------
require_once AXON_DIR . 'includes/class-content-tools.php';
require_once AXON_DIR . 'includes/class-site-tools.php';
require_once AXON_DIR . 'includes/class-design-tools.php';
require_once AXON_DIR . 'includes/class-bulk-tools.php';
require_once AXON_DIR . 'includes/class-malware-tools.php';
require_once AXON_DIR . 'includes/class-seo-tools.php';
require_once AXON_DIR . 'includes/class-media-tools.php';
require_once AXON_DIR . 'includes/class-workflow-tools.php';
require_once AXON_DIR . 'includes/class-speed-tools.php';
require_once AXON_DIR . 'includes/class-security-tools.php';
require_once AXON_DIR . 'includes/class-geo-tools.php';
require_once AXON_DIR . 'includes/class-schema-tools.php';
require_once AXON_DIR . 'includes/class-redirect-tools.php';
require_once AXON_DIR . 'includes/class-antigravity-mcp.php';

// ---------------------------------------------------------------------------
// OAuth 2.1 authorization server
// ---------------------------------------------------------------------------
require_once AXON_DIR . 'includes/class-token-store.php';
require_once AXON_DIR . 'includes/class-pkce.php';
require_once AXON_DIR . 'includes/class-discovery.php';
require_once AXON_DIR . 'includes/class-client-registration.php';
require_once AXON_DIR . 'includes/class-authorize.php';
require_once AXON_DIR . 'includes/class-token-endpoint.php';
require_once AXON_DIR . 'includes/class-resource-server.php';

// ---------------------------------------------------------------------------
// The MCP server itself (bundled)
// ---------------------------------------------------------------------------

/**
 * Boot the bundled WordPress MCP Adapter — the component that actually serves MCP.
 *
 * WHY IT IS BUNDLED
 * -----------------
 * The adapter is what exposes registered abilities to MCP clients over HTTP. Without it
 * there is no MCP server, only tools with nothing to serve them. Shipping it separately
 * would mean telling a customer "install these other plugins first, then mine" — which is
 * not a product. It is GPL-2.0-or-later, the same licence as this plugin, so redistributing
 * it here is permitted; see lib/mcp-adapter/BUNDLED.md and LICENSE.md.
 *
 * The Abilities API this builds on is in WordPress core as of 6.9
 * (wp-includes/abilities-api.php), so nothing else is needed. In particular the Automattic
 * `wordpress-mcp` plugin is NOT required — its own RegisterMcpTool path registers nothing on
 * an Abilities-API install, which is why this plugin does not ask for it.
 *
 * WHY THE GUARDS
 * --------------
 * If the standalone MCP Adapter plugin is also active, its classes are already declared and
 * loading this copy would fatal with "Cannot redeclare" — the same class of bug documented
 * on the predecessor guard above. So an existing separate install always wins: this copy
 * loads only when nothing else has claimed `WP\MCP\Plugin`. Both constants are guarded the
 * same way, since the standalone plugin defines them unconditionally.
 */
function axon_boot_adapter() {
	// Someone else already loaded the adapter (standalone plugin, or another plugin
	// bundling it). Use theirs, touch nothing.
	if ( class_exists( 'WP\\MCP\\Plugin', false ) ) {
		return;
	}

	$lib = AXON_DIR . 'lib/mcp-adapter';

	if ( ! is_readable( $lib . '/includes/Autoloader.php' ) ) {
		return;
	}

	if ( ! defined( 'WP_MCP_DIR' ) ) {
		define( 'WP_MCP_DIR', $lib );
	}
	if ( ! defined( 'WP_MCP_VERSION' ) ) {
		define( 'WP_MCP_VERSION', '0.6.1' );
	}

	require_once $lib . '/includes/Autoloader.php';

	// Autoloader::autoload() returns false if the composer autoload file is unreadable.
	// Calling Plugin::instance() anyway would fatal on a missing class, so both conditions
	// are checked before booting.
	if ( ! \WP\MCP\Autoloader::autoload() || ! class_exists( '\WP\MCP\Plugin' ) ) {
		return;
	}

	\WP\MCP\Plugin::instance();
}
axon_boot_adapter();

/**
 * Plain-text form of a WordPress string.
 *
 * get_the_title() and friends return text encoded for HTML output — "Salary &#038; Roles".
 * Every tool here returns JSON to an AI client, or builds JSON-LD, or writes a .txt file;
 * none of those are HTML. Leaving the entities in place means an assistant reads "&#038;"
 * as literal characters and Google reads schema names with markup in them.
 *
 * @param string $text
 * @return string
 */
function axon_text( $text ) {
	return html_entity_decode( (string) $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
}

// ---------------------------------------------------------------------------
// Admin: connection guidance and status
// ---------------------------------------------------------------------------
require_once AXON_DIR . 'includes/class-admin.php';

new Axon_Admin();

// ---------------------------------------------------------------------------
// Self-update
// ---------------------------------------------------------------------------
require_once AXON_DIR . 'includes/class-updater.php';

$GLOBALS['axon_updater'] = new Axon_Updater( __FILE__, AXON_VERSION, AXON_UPDATE_MANIFEST );

// ---------------------------------------------------------------------------
// Activation / migration
// ---------------------------------------------------------------------------

/**
 * Everything that must happen once per installed version.
 *
 * Token_Store::install() uses dbDelta, so running it against tables that already exist from
 * mcp-oauth-bridge is a no-op — which is what keeps a live claude.ai connection working
 * through the merge rather than forcing every connected client to re-authorize. That also
 * makes this function safe to call repeatedly.
 */
function axon_run_setup() {
	if ( class_exists( 'MCP_OAuth_Bridge\\Token_Store' ) ) {
		MCP_OAuth_Bridge\Token_Store::install();
	}

	// The OAuth discovery and authorize endpoints register rewrite rules; without a flush
	// they 404 until someone happens to re-save permalinks.
	flush_rewrite_rules();

	update_option( 'axon_installed_version', AXON_VERSION, false );
}

/**
 * First activation.
 */
function axon_activate() {
	axon_run_setup();
}
register_activation_hook( __FILE__, 'axon_activate' );

/**
 * Run setup after a self-update.
 *
 * WordPress does NOT fire activation hooks when a plugin updates — it deactivates, swaps
 * the files, and reactivates without calling the activation hook at all. For a plugin that
 * updates itself in the background, that means any setup step written only into the
 * activation hook would run on a fresh install and then never again, so a future release
 * that needed a new table or a rewrite-rule change would quietly ship broken to every
 * existing site while testing perfectly on a new one.
 *
 * Comparing a stored version against the running one closes that gap: it fires exactly once
 * per version, whether the version arrived by upload, by auto-update, or by hand.
 */
function axon_maybe_upgrade() {
	if ( get_option( 'axon_installed_version' ) === AXON_VERSION ) {
		return;
	}
	axon_run_setup();
}
add_action( 'admin_init', 'axon_maybe_upgrade' );

/**
 * Leave no stale rewrite rules behind on deactivation.
 */
function axon_deactivate() {
	flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'axon_deactivate' );

// ---------------------------------------------------------------------------
// Boot
// ---------------------------------------------------------------------------

add_action(
	'plugins_loaded',
	function () {
		new MCP_OAuth_Bridge\Discovery();
		new MCP_OAuth_Bridge\Client_Registration();
		new MCP_OAuth_Bridge\Authorize();
		new MCP_OAuth_Bridge\Token_Endpoint();
		new MCP_OAuth_Bridge\Resource_Server();
	}
);

// Runtime hooks. Everything else in this plugin is on-demand via MCP and adds nothing to a
// normal page load. The redirect hooks run only on requests that would 404.
add_action( 'template_redirect', array( 'Axon_GEO_Tools', 'maybe_serve_llms_txt' ), 0 );
add_action( 'template_redirect', array( 'Axon_Redirect_Tools', 'maybe_redirect' ), 1 );
add_action( 'template_redirect', array( 'Axon_Redirect_Tools', 'log_404' ), 999 );
add_action( 'wp_head', array( 'Axon_Schema_Tools', 'output_schema' ), 20 );

// Coded page design: per-page CSS/JS, and the blank canvas template for "full" mode pages.
// This replaces an earlier hack that pointed one hardcoded page slug at one hardcoded
// template file — the same idea, generalised so any page can be built this way.
add_action( 'wp_head', array( 'Axon_Design_Tools', 'print_assets' ), 99 );
add_action( 'wp_footer', array( 'Axon_Design_Tools', 'print_js' ), 99 );
add_filter( 'template_include', array( 'Axon_Design_Tools', 'maybe_canvas_template' ), 99 );

// ---------------------------------------------------------------------------
// Admin notices
// ---------------------------------------------------------------------------

/**
 * Report the result of a manual "Check for updates" click, and flag a superseded plugin
 * that has been switched back on.
 */
function axon_admin_notices() {
	if ( ! current_user_can( 'update_plugins' ) ) {
		return;
	}

	$notice = isset( $_GET['axon_notice'] ) ? sanitize_key( wp_unslash( $_GET['axon_notice'] ) ) : '';

	if ( 'axon-update-current' === $notice ) {
		printf(
			'<div class="notice notice-success is-dismissible"><p><strong>Axon</strong> is up to date (version %s).</p></div>',
			esc_html( AXON_VERSION )
		);
	} elseif ( 'axon-update-found' === $notice ) {
		echo '<div class="notice notice-info is-dismissible"><p>A new version of <strong>Axon</strong> is available — see the row below to update.</p></div>';
	} elseif ( 'axon-update-failed' === $notice ) {
		echo '<div class="notice notice-error is-dismissible"><p><strong>Axon</strong> could not reach the update server. The site is unaffected and still running the installed version. Try again shortly.</p></div>';
	}
}
add_action( 'admin_notices', 'axon_admin_notices' );

// ---------------------------------------------------------------------------
// Tool definitions
// ---------------------------------------------------------------------------

/**
 * Operation type and minimum capability for each tool.
 *
 * The capability listed here is a coarse gate. Each callback still performs its own
 * fine-grained check (edit_post on the specific post, upload_files, and so on), so a tool
 * can never exceed what the connected MCP user is allowed to do.
 *
 * @return array<string, array{0: string, 1: string}>
 */
function axon_tool_meta() {
	return array(
		// Content control.
		'create_post'            => array( 'create', 'edit_posts' ),
		'update_post'            => array( 'update', 'edit_posts' ),
		'get_post'               => array( 'read', 'edit_posts' ),
		'list_posts'             => array( 'read', 'edit_posts' ),
		'delete_post'            => array( 'delete', 'delete_posts' ),
		'manage_terms'           => array( 'update', 'edit_posts' ),
		'upload_media'           => array( 'create', 'upload_files' ),
		'wp_rest'                => array( 'action', 'edit_posts' ),
		'design_page'            => array( 'update', 'edit_pages' ),
		'get_design'             => array( 'read', 'edit_pages' ),
		'analyze_design'         => array( 'read', 'edit_pages' ),
		'bulk_edit'              => array( 'update', 'edit_others_posts' ),
		'scan_malware'           => array( 'read', 'manage_options' ),
		// Content and workflow.
		'get_seo_meta'           => array( 'read', 'edit_posts' ),
		'set_seo_meta'           => array( 'update', 'edit_posts' ),
		'seo_readiness_check'    => array( 'read', 'edit_posts' ),
		'set_media_alt_text'     => array( 'update', 'edit_posts' ),
		'set_editorial_status'   => array( 'update', 'edit_posts' ),
		'schedule_post'          => array( 'update', 'edit_posts' ),
		// Speed.
		'get_performance_report' => array( 'read', 'manage_options' ),
		'convert_media_to_webp'  => array( 'action', 'upload_files' ),
		'enable_webp_delivery'   => array( 'action', 'manage_options' ),
		'cleanup_database'       => array( 'action', 'manage_options' ),
		// Security.
		'audit_plugins'          => array( 'read', 'activate_plugins' ),
		'audit_site_hardening'   => array( 'read', 'manage_options' ),
		'check_core_integrity'   => array( 'read', 'manage_options' ),
		// GEO / AEO.
		'audit_ai_crawlers'      => array( 'read', 'manage_options' ),
		'audit_ai_readiness'     => array( 'read', 'edit_posts' ),
		'generate_llms_txt'      => array( 'action', 'manage_options' ),
		'find_orphan_pages'      => array( 'read', 'edit_posts' ),
		// Schema.
		'generate_schema'        => array( 'read', 'edit_posts' ),
		'apply_schema'           => array( 'update', 'edit_posts' ),
		'validate_schema'        => array( 'read', 'edit_posts' ),
		'audit_schema_coverage'  => array( 'read', 'edit_posts' ),
		// Redirects.
		'manage_redirects'       => array( 'update', 'manage_options' ),
		'audit_404s'             => array( 'read', 'manage_options' ),
		'find_broken_links'      => array( 'read', 'edit_posts' ),
	);
}

/**
 * Every module's tools, keyed by module slug.
 *
 * @return array<string, array>
 */
function axon_modules() {
	return array(
		'content'  => Axon_Content_Tools::tools(),
		'site'     => Axon_Site_Tools::tools(),
		'design'   => Axon_Design_Tools::tools(),
		'bulk'     => Axon_Bulk_Tools::tools(),
		'malware'  => Axon_Malware_Tools::tools(),
		'seo'      => Axon_SEO_Tools::tools(),
		'media'    => Axon_Media_Tools::tools(),
		'workflow' => Axon_Workflow_Tools::tools(),
		'speed'    => Axon_Speed_Tools::tools(),
		'security' => Axon_Security_Tools::tools(),
		'geo'      => Axon_GEO_Tools::tools(),
		'schema'   => Axon_Schema_Tools::tools(),
		'redirect' => Axon_Redirect_Tools::tools(),
	);
}

/**
 * Behaviour hints for an ability, derived from the same (type, capability) map used by both
 * registration paths so the two can never disagree about what a tool is allowed to do.
 *
 * 'destructive' is true only for cleanup_database: it is the one tool here that can
 * permanently remove data. convert_media_to_webp, enable_webp_delivery and
 * generate_llms_txt only add or toggle something and are trivially reversible, so they are
 * not flagged destructive even though their type is 'action'.
 *
 * @param string $type Operation type.
 * @param string $name Tool name.
 * @return array{readonly: bool, destructive: bool, idempotent: bool}
 */
function axon_annotations( $type, $name ) {
	return array(
		'readonly'    => ( 'read' === $type ),
		'destructive' => in_array( $name, array( 'cleanup_database', 'delete_post', 'bulk_edit' ), true ),
		'idempotent'  => ( 'action' !== $type ),
	);
}

/**
 * Module slugs used as ability category slugs.
 *
 * @return array<string, string>
 */
function axon_categories() {
	return array(
		'axon-content'  => 'Create, edit, organise and remove posts, pages and taxonomies.',
		'axon-site'     => 'Media uploads and direct access to any WordPress REST route.',
		'axon-design'   => 'Build and redesign pages by writing HTML and CSS, with no page builder.',
		'axon-bulk'     => 'Apply one change across many posts at once, previewed before it writes.',
		'axon-malware'  => 'Read-only malware and file-integrity scanning.',
		'axon-seo'      => 'SEO metadata reading and writing.',
		'axon-media'    => 'Media Library accessibility tools.',
		'axon-workflow' => 'Editorial workflow: status and scheduling.',
		'axon-speed'    => 'Page weight, image formats and database cleanup.',
		'axon-security' => 'Read-only plugin, hardening and core-integrity audits.',
		'axon-geo'      => 'AI search visibility: crawlers, citability, llms.txt.',
		'axon-schema'   => 'Schema.org JSON-LD generation and validation.',
		'axon-redirect' => 'Redirects and 404 recovery.',
	);
}

/**
 * Register one ability category per module.
 *
 * REQUIRED before any ability can reference it: WP_Abilities_Registry::register() checks
 * wp_has_ability_category() and refuses the ability if it fails — silently, returning null
 * and logging a _doing_it_wrong() that is easy to miss.
 */
function axon_register_categories() {
	if ( ! function_exists( 'wp_register_ability_category' ) ) {
		return;
	}
	foreach ( axon_categories() as $slug => $description ) {
		wp_register_ability_category(
			$slug,
			array(
				'label'       => ucwords( str_replace( '-', ' ', $slug ) ),
				'description' => $description,
			)
		);
	}
}
add_action( 'wp_abilities_api_categories_init', 'axon_register_categories' );

/**
 * Register every tool as a WordPress Ability — the path that actually reaches MCP clients.
 *
 * Ability IDs are namespaced 'axon/<dashed-tool-name>' to match the convention already used
 * by Rank Math ('rank-math/audit-site-seo') and WPForms ('wpforms/list-forms').
 */
/**
 * Force a schema's `properties` to encode as a JSON object, never an array.
 *
 * PHP has one array type; JSON has two. An empty `array()` encodes to `[]`, but JSON Schema
 * requires `properties` to be an OBJECT — `{}`. A tool declaring no parameters therefore
 * ships `"properties": []`, which is invalid.
 *
 * The consequence is far worse than one bad tool. A strict MCP client validates the whole
 * `tools/list` response, so two malformed entries made EVERY tool on the site unusable with:
 *
 *   Invalid result for tools/list: tools.3.inputSchema.properties: expected record,
 *   received array
 *
 * claude.ai happened to tolerate it; another client did not, and the entire toolset vanished
 * with an error that named neither the plugin nor the tools at fault. Normalising centrally
 * means a future zero-argument tool cannot reintroduce it by writing the natural thing.
 *
 * @param array $schema Input schema.
 * @return array
 */
function axon_normalize_schema( $schema ) {
	if ( ! is_array( $schema ) ) {
		return $schema;
	}

	if ( ! isset( $schema['properties'] ) || ( is_array( $schema['properties'] ) && empty( $schema['properties'] ) ) ) {
		$schema['properties'] = new stdClass();
	}

	return $schema;
}

function axon_register_abilities() {
	if ( ! function_exists( 'wp_register_ability' ) ) {
		return;
	}

	$meta = axon_tool_meta();

	foreach ( axon_modules() as $module => $tools ) {
		foreach ( $tools as $tool ) {
			$name = $tool['name'] ?? '';
			if ( '' === $name ) {
				continue;
			}

			list( $type, $cap ) = $meta[ $name ] ?? array( 'read', 'manage_options' );
			$ability_id         = 'axon/' . str_replace( '_', '-', $name );

			// Required top-level fields per WP_Ability::prepare_properties(): label,
			// description, category, execute_callback, permission_callback — all five, or
			// the registry rejects the ability outright.
			$args = array(
				'label'               => ucwords( str_replace( array( '_', '-' ), ' ', $name ) ),
				'description'         => $tool['description'] ?? '',
				'category'            => 'axon-' . $module,
				'execute_callback'    => $tool['callback'],
				'permission_callback' => static function () use ( $cap ) {
					return current_user_can( $cap );
				},
				// Every tool here accepts an empty call (all-optional args with defaults
				// applied inside the callback), which is what an MCP client sends for a
				// no-argument invocation. WP_Ability only fills that gap from a top-level
				// `default` on the schema — without it, a missing input stays null and
				// fails "not of type object" against a `type: object` schema.
				'input_schema'        => axon_normalize_schema(
					array_merge(
						array( 'default' => array() ),
						! empty( $tool['inputSchema'] ) ? $tool['inputSchema'] : array( 'type' => 'object' )
					)
				),
				'output_schema'       => array( 'type' => 'object' ),
				'meta'                => array(
					'annotations'  => axon_annotations( $type, $name ),
					// Defaults to false; without it the ability is invisible at
					// /wp-json/wp-abilities/v1/abilities, which is also how this whole
					// registration path gets verified.
					'show_in_rest' => true,
					// meta.mcp.public is mcp-adapter's own field; meta.public is its
					// fallback. Setting both costs nothing and covers either reading.
					'mcp'          => array( 'public' => true ),
					'public'       => true,
				),
			);

			// wp_register_ability() does not throw on a bad definition — the registry
			// catches WP_Ability's InvalidArgumentException internally and returns null.
			// The return value is the only signal there is.
			$registered = wp_register_ability( $ability_id, $args );
			if ( null === $registered && defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				error_log( sprintf( '[axon-wp] wp_register_ability() returned null for "%s" — check the debug log for a _doing_it_wrong() notice naming the invalid field.', $ability_id ) ); // phpcs:ignore
			}
		}
	}
}
add_action( 'wp_abilities_api_init', 'axon_register_abilities' );

/**
 * Expose Axon's abilities as first-class MCP tools, not just through the generic wrapper.
 *
 * By default the adapter's server offers exactly three tools — discover-abilities,
 * get-ability-info and execute-ability — and every real ability is reached by passing its
 * name and a `parameters` object to that last one.
 *
 * That indirection costs more than it looks:
 *
 * 1. The client sees three vague tools instead of thirty-seven described ones, so it has to
 *    discover, then look up a schema, then call — three round trips to do one thing, and it
 *    is choosing arguments for a schema it has to fetch separately.
 * 2. Every call depends on `parameters` surviving serialisation as a JSON object. A client
 *    that sends it as a string gets "parameters is not of type object" and EVERY tool fails
 *    at once, with nothing in the site's own logs, because the request never reaches the
 *    ability at all. That failure was observed live.
 *
 * Listing the abilities directly removes the wrapper from the path. Each tool arrives with
 * its own name, description and schema, which is what the client is designed to consume. The
 * three generic tools stay registered, so anything already calling them keeps working.
 *
 * @param array $config Default server configuration.
 * @return array
 */
function axon_expose_abilities_as_tools( $config ) {
	if ( ! is_array( $config ) ) {
		return $config;
	}

	$tools = isset( $config['tools'] ) && is_array( $config['tools'] ) ? $config['tools'] : array();

	foreach ( axon_modules() as $module => $module_tools ) {
		foreach ( $module_tools as $tool ) {
			$name = $tool['name'] ?? '';
			if ( '' === $name ) {
				continue;
			}
			$tools[] = 'axon/' . str_replace( '_', '-', $name );
		}
	}

	$config['tools'] = array_values( array_unique( $tools ) );

	return $config;
}
add_filter( 'mcp_adapter_default_server_config', 'axon_expose_abilities_as_tools' );

/**
 * Legacy registration path for the Automattic wordpress-mcp plugin's own tool API.
 *
 * Registers nothing on installs using the Abilities API. Kept because it costs one
 * class_exists() check and covers a wordpress-mcp release that relies on it again.
 */
function axon_register_legacy_tools() {
	if ( ! class_exists( '\Automattic\WordpressMcp\Core\RegisterMcpTool' ) ) {
		return;
	}

	$meta  = axon_tool_meta();
	$tools = array_merge( ...array_values( axon_modules() ) );

	foreach ( $tools as $tool ) {
		$name               = $tool['name'] ?? '';
		list( $type, $cap ) = $meta[ $name ] ?? array( 'read', 'manage_options' );

		$tool['type']                = $type;
		$tool['permission_callback'] = static function () use ( $cap ) {
			return current_user_can( $cap );
		};
		if ( empty( $tool['inputSchema'] ) ) {
			$tool['inputSchema'] = array( 'type' => 'object' );
		}

		// RegisterMcpTool throws on any invalid definition. Without this catch a single
		// malformed tool would fatal every admin and MCP request — the exact failure that
		// takes a site offline. Skip the bad tool, keep the rest working, leave a trace.
		try {
			new \Automattic\WordpressMcp\Core\RegisterMcpTool( $tool );
		} catch ( \Throwable $e ) {
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				error_log( sprintf( '[axon-wp] Could not register tool "%s": %s', $name, $e->getMessage() ) ); // phpcs:ignore
			}
		}
	}
}
add_action( 'wordpress_mcp_init', 'axon_register_legacy_tools' );
