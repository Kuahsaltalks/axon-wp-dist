#!/usr/bin/env bash
#
# release.sh — publish a new version of Axon.
#
#   ./release.sh 1.1.0 "Fixed the media upload gap"
#
# Everything a release needs happens here, in order, and the script stops at the first
# thing that goes wrong rather than half-publishing:
#
#   1. Check the version is valid and actually newer than what is installed.
#   2. Write the new version into all three places it appears (plugin header, the PHP
#      constant, readme.txt) — these drifting apart is the classic cause of "I released it
#      but nobody sees the update".
#   3. Lint every PHP file. A syntax error shipped to a live site is a white screen.
#   4. Build the zip, with the folder inside named exactly `axon-wp`. WordPress
#      activates plugins by path; a differently named folder installs as a SEPARATE plugin
#      and silently deactivates the running one.
#   5. Commit and tag the private source repo.
#   6. Upload the zip as a GitHub Release asset on the public dist repo.
#   7. Publish update.json LAST — it is the switch that tells every site an update exists,
#      so it must never point at a download that is not uploaded yet.
#
# Requires: gh (authenticated), git, php, zip.

set -euo pipefail

# --- configuration -----------------------------------------------------------

GH_OWNER="Kuahsaltalks"
SRC_REPO="axon-wp"          # private — source, history, this script
DIST_REPO="axon-wp-dist"    # public  — update.json + release zips

PLUGIN_SLUG="axon-wp"
PLUGIN_NAME="Axon"
PLUGIN_AUTHOR="Waah School"
REQUIRES_WP="6.9"
TESTED_WP="7.0"
REQUIRES_PHP="8.0"

HERE="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
DIST_DIR="$( dirname "$HERE" )/$DIST_REPO"
MAIN_FILE="$HERE/$PLUGIN_SLUG.php"

# --- pretty output -----------------------------------------------------------

step() { printf '\n\033[1;36m▸ %s\033[0m\n' "$1"; }
ok()   { printf '  \033[0;32m✓\033[0m %s\n' "$1"; }
die()  { printf '\n\033[0;31m✗ %s\033[0m\n\n' "$1" >&2; exit 1; }

# --- arguments ---------------------------------------------------------------

NEW_VERSION="${1:-}"
CHANGELOG_MSG="${2:-}"

if [ -z "$NEW_VERSION" ]; then
  die "Usage: ./release.sh <version> \"<what changed>\"
       e.g. ./release.sh 1.1.0 \"Added media upload support\""
fi

if ! [[ "$NEW_VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
  die "Version must look like 1.2.3 — got '$NEW_VERSION'."
fi

if [ -z "$CHANGELOG_MSG" ]; then
  die "Say what changed, so the update notice means something:
       ./release.sh $NEW_VERSION \"Added media upload support\""
fi

for cmd in gh git php zip; do
  command -v "$cmd" >/dev/null 2>&1 || die "'$cmd' is not installed."
done

gh auth status >/dev/null 2>&1 || die "GitHub CLI is not logged in. Run: gh auth login"

# --- 1. version sanity -------------------------------------------------------

step "Checking version"

CUR_VERSION="$( grep -m1 "^ \* Version:" "$MAIN_FILE" | sed -E 's/.*Version:[[:space:]]*//' | tr -d '[:space:]' )"
[ -n "$CUR_VERSION" ] || die "Could not read the current version from $MAIN_FILE"

# sort -V puts versions in order; if the new one is not strictly the later of the two,
# WordPress will never offer it — version_compare() on the site requires greater-than.
LATER="$( printf '%s\n%s\n' "$CUR_VERSION" "$NEW_VERSION" | sort -V | tail -1 )"
if [ "$LATER" != "$NEW_VERSION" ] || [ "$CUR_VERSION" = "$NEW_VERSION" ]; then
  die "$NEW_VERSION is not newer than the current $CUR_VERSION. Sites would ignore it."
fi
ok "$CUR_VERSION → $NEW_VERSION"

# --- 2. write the version everywhere ----------------------------------------

step "Updating version numbers"

# BSD sed (macOS) needs an explicit empty backup suffix for -i.
sedi() { sed -i '' "$@"; }

sedi -E "s/^( \* Version:[[:space:]]*).*/\1$NEW_VERSION/" "$MAIN_FILE"
sedi -E "s/(define\( 'AXON_VERSION', ')[^']*(' \);)/\1$NEW_VERSION\2/" "$MAIN_FILE"
ok "plugin header + AXON_VERSION"

if [ -f "$HERE/readme.txt" ]; then
  sedi -E "s/^(Stable tag:[[:space:]]*).*/\1$NEW_VERSION/" "$HERE/readme.txt"
  ok "readme.txt stable tag"
fi

# Verify rather than trust: a sed that silently matched nothing is the failure mode that
# publishes a "new" release carrying the old version number.
HDR="$( grep -m1 "^ \* Version:" "$MAIN_FILE" | sed -E 's/.*Version:[[:space:]]*//' | tr -d '[:space:]' )"
CST="$( grep -m1 "AXON_VERSION" "$MAIN_FILE" | sed -E "s/.*'AXON_VERSION', '([^']*)'.*/\1/" )"
[ "$HDR" = "$NEW_VERSION" ] || die "Plugin header still reads $HDR — version bump failed."
[ "$CST" = "$NEW_VERSION" ] || die "AXON_VERSION still reads $CST — version bump failed."
ok "verified: header and constant both read $NEW_VERSION"

# --- 3. lint ----------------------------------------------------------------

step "Checking PHP syntax"

LINT_FAILED=0
while IFS= read -r f; do
  if ! php -l "$f" >/dev/null 2>&1; then
    printf '\033[0;31m  %s\033[0m\n' "$( php -l "$f" 2>&1 | sed -n '1,3p' )"
    LINT_FAILED=1
  fi
done < <( find "$HERE" -name '*.php' -not -path '*/.git/*' )

[ "$LINT_FAILED" -eq 0 ] || die "PHP syntax errors — nothing published. Fix them and re-run."
ok "all PHP files parse"

# --- 4. build the zip -------------------------------------------------------

step "Building the zip"

BUILD="$( mktemp -d )"
trap 'rm -rf "$BUILD"' EXIT

mkdir -p "$BUILD/$PLUGIN_SLUG"
# Ship only what the plugin needs at runtime. release.sh, .git and macOS metadata have no
# business on a customer's server.
rsync -a \
  --exclude '.git' --exclude '.github' --exclude '.DS_Store' \
  --exclude 'release.sh' --exclude '*.zip' --exclude 'CHANGELOG.md' \
  "$HERE/" "$BUILD/$PLUGIN_SLUG/"

ZIP_NAME="$PLUGIN_SLUG-$NEW_VERSION.zip"
( cd "$BUILD" && zip -qr "$ZIP_NAME" "$PLUGIN_SLUG" -x '*.DS_Store' )

ZIP_PATH="$BUILD/$ZIP_NAME"
[ -f "$ZIP_PATH" ] || die "Zip was not created."

# The folder inside the zip must be exactly the plugin slug (see header note).
# `unzip | head -1` looks natural but kills this script: head closes the pipe after one
# line, unzip dies of SIGPIPE, and `set -o pipefail` turns that into a failed release with
# an opaque exit 141. sed consumes the whole stream, so nothing is left holding a dead pipe.
TOP="$( unzip -Z1 "$ZIP_PATH" | sed -n '1s|/.*||p' )"
[ "$TOP" = "$PLUGIN_SLUG" ] || die "Zip contains folder '$TOP', expected '$PLUGIN_SLUG'."

ok "$ZIP_NAME ($( du -h "$ZIP_PATH" | cut -f1 | tr -d ' ' )), top folder '$TOP'"

# --- 5. commit + tag the source repo ----------------------------------------

step "Committing source ($SRC_REPO, private)"

cd "$HERE"
if [ ! -d .git ]; then
  die "$HERE is not a git repository yet. Run setup-repos.sh first."
fi

# Record the change where a human reads it, newest first.
CHANGELOG="$HERE/CHANGELOG.md"
{
  echo "## $NEW_VERSION — $( date +%Y-%m-%d )"
  echo
  echo "$CHANGELOG_MSG"
  echo
  [ -f "$CHANGELOG" ] && cat "$CHANGELOG"
} > "$CHANGELOG.tmp"
mv "$CHANGELOG.tmp" "$CHANGELOG"

git add -A
git commit -q -m "Release $NEW_VERSION

$CHANGELOG_MSG" || ok "nothing new to commit"
git tag -f "v$NEW_VERSION" >/dev/null
git push -q origin HEAD
git push -q -f origin "v$NEW_VERSION"
ok "pushed and tagged v$NEW_VERSION"

# --- 6. upload the release asset --------------------------------------------

step "Publishing release ($DIST_REPO, public)"

if gh release view "v$NEW_VERSION" --repo "$GH_OWNER/$DIST_REPO" >/dev/null 2>&1; then
  gh release delete "v$NEW_VERSION" --repo "$GH_OWNER/$DIST_REPO" --yes --cleanup-tag >/dev/null 2>&1 || true
  ok "replaced existing v$NEW_VERSION release"
fi

gh release create "v$NEW_VERSION" "$ZIP_PATH" \
  --repo "$GH_OWNER/$DIST_REPO" \
  --title "$PLUGIN_NAME $NEW_VERSION" \
  --notes "$CHANGELOG_MSG" >/dev/null

DOWNLOAD_URL="https://github.com/$GH_OWNER/$DIST_REPO/releases/download/v$NEW_VERSION/$ZIP_NAME"
ok "asset uploaded"

# Do not announce a download that cannot be downloaded. If GitHub is still processing the
# asset when update.json goes live, every site that checks in that window gets a failed
# update instead of a working one.
step "Verifying the download works"
for attempt in 1 2 3 4 5; do
  CODE="$( curl -sIL -o /dev/null -w '%{http_code}' "$DOWNLOAD_URL" )"
  [ "$CODE" = "200" ] && break
  sleep 3
done
[ "$CODE" = "200" ] || die "Download URL returned HTTP $CODE. update.json was NOT published, so no site will attempt this broken update.
       $DOWNLOAD_URL"
ok "HTTP 200 — the zip is live"

# --- 7. publish update.json (the switch) ------------------------------------

step "Publishing update.json"

[ -d "$DIST_DIR/.git" ] || die "$DIST_DIR is not a git repository. Run setup-repos.sh first."

# Escape for JSON embedding — a stray quote or newline in the message would otherwise
# produce a manifest that fails to parse, which reads on every site as "update server down".
ESCAPED_MSG="$( printf '%s' "$CHANGELOG_MSG" | php -r 'echo trim(json_encode(stream_get_contents(STDIN)), "\"");' )"

cat > "$DIST_DIR/update.json" <<JSON
{
  "name": "$PLUGIN_NAME",
  "slug": "$PLUGIN_SLUG",
  "version": "$NEW_VERSION",
  "download_url": "$DOWNLOAD_URL",
  "requires": "$REQUIRES_WP",
  "tested": "$TESTED_WP",
  "requires_php": "$REQUIRES_PHP",
  "author": "<a href=\"https://waah.school\">$PLUGIN_AUTHOR</a>",
  "homepage": "https://github.com/$GH_OWNER/$DIST_REPO",
  "last_updated": "$( date -u +'%Y-%m-%d %H:%M:%S' )",
  "sections": {
    "description": "One plugin that turns WordPress into an AI-controllable site: 24 MCP tools for SEO, speed, security, GEO/AEO, schema and redirects, plus a full OAuth 2.1 server so MCP clients connect with a click.",
    "changelog": "<h4>$NEW_VERSION</h4><p>$ESCAPED_MSG</p>"
  }
}
JSON

php -r 'json_decode(file_get_contents($argv[1]), true, 512, JSON_THROW_ON_ERROR);' "$DIST_DIR/update.json" \
  || die "Generated update.json is not valid JSON. Not published."
ok "manifest valid"

cd "$DIST_DIR"
git add update.json
git commit -q -m "Release $NEW_VERSION" || true
git push -q origin HEAD
ok "update.json live"

# --- done -------------------------------------------------------------------

printf '\n\033[1;32m━━━ Released %s %s ━━━\033[0m\n\n' "$PLUGIN_NAME" "$NEW_VERSION"
printf '  Every site running this plugin will show "Update now" within 12 hours,\n'
printf '  or right away via Plugins → "Check for updates".\n\n'
printf '  Download: %s\n\n' "$DOWNLOAD_URL"
