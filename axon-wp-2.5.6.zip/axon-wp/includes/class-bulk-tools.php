<?php
/**
 * Bulk operations across many posts at once.
 *
 * This is where an AI genuinely beats a person: applying one careful decision to two hundred
 * posts. It is also where an AI can do the most damage in a single call, so the whole design
 * is built around one rule.
 *
 * DRY RUN IS THE DEFAULT
 * ----------------------
 * Every call previews by default and changes nothing. You must pass `dry_run: false` to write.
 * The preview shows exactly which posts match and, for text replacement, the before and after
 * of each change. A bulk edit is not reversible with an undo button — the safety has to be in
 * front of it, not behind it.
 *
 * Two more limits back that up:
 *
 * - A hard cap on how many posts one call can touch, so a filter that accidentally matches
 *   everything cannot rewrite the site in one go.
 * - Content changes go through wp_update_post(), so WordPress stores a revision of each post
 *   before overwriting it. If a replacement turns out wrong, every affected post can be rolled
 *   back individually from its own revision history.
 *
 * @package Axon
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Apply one operation to many posts.
 */
class Axon_Bulk_Tools {

	/**
	 * Most posts a single call may modify.
	 *
	 * Deliberately modest. Bulk edits are usually applied to a considered subset, and a
	 * request that legitimately needs more can be run again — whereas a runaway filter that
	 * rewrites two thousand posts is a restore-from-backup afternoon.
	 */
	const MAX_POSTS = 200;

	/**
	 * @return array<int, array<string, mixed>>
	 */
	public static function tools() {
		return array(
			array(
				'name'        => 'bulk_edit',
				'description' => 'Apply one change across many posts at once: find and replace text, add or remove categories and tags, change status, set a focus keyword, or generate schema. PREVIEWS BY DEFAULT and changes nothing until you pass dry_run=false. Always run the preview first and read it — a bulk edit has no undo button.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'action'    => array(
							'type'        => 'string',
							'description' => 'replace_text, add_category, remove_category, add_tag, remove_tag, set_status, set_focus_keyword or apply_schema.',
						),
						'post_type' => array( 'type' => 'string', 'description' => 'Limit to a post type. Default "post".' ),
						'status'    => array( 'type' => 'string', 'description' => 'Limit to a status: publish, draft, pending, any. Default "publish".' ),
						'category'  => array( 'type' => 'string', 'description' => 'Limit to a category slug.' ),
						'search'    => array( 'type' => 'string', 'description' => 'Limit to posts matching this text.' ),
						'ids'       => array( 'type' => 'string', 'description' => 'Comma-separated post IDs to act on. Overrides all other filters — the safest way to run a bulk edit.' ),
						'find'      => array( 'type' => 'string', 'description' => 'Text to find, for replace_text. Matched literally, not as a pattern.' ),
						'replace'   => array( 'type' => 'string', 'description' => 'Replacement text, for replace_text. May be empty to delete the found text.' ),
						'value'     => array( 'type' => 'string', 'description' => 'The category name, tag name, status or focus keyword to apply.' ),
						'dry_run'   => array( 'type' => 'boolean', 'description' => 'Preview without changing anything. Default TRUE. Pass false to actually write.' ),
						'limit'     => array( 'type' => 'integer', 'description' => 'Maximum posts to touch. Default 50, hard maximum 200.' ),
					),
					'required'   => array( 'action' ),
				),
				'callback'    => array( __CLASS__, 'bulk_edit' ),
			),
		);
	}

	/**
	 * @param array $args
	 * @return array|WP_Error
	 */
	public static function bulk_edit( $args ) {
		if ( ! current_user_can( 'edit_others_posts' ) ) {
			return new WP_Error( 'forbidden', 'Bulk editing needs the edit_others_posts capability — an editor or administrator account.' );
		}

		$action = sanitize_key( $args['action'] ?? '' );
		$valid  = array( 'replace_text', 'add_category', 'remove_category', 'add_tag', 'remove_tag', 'set_status', 'set_focus_keyword', 'apply_schema' );

		if ( ! in_array( $action, $valid, true ) ) {
			return new WP_Error( 'bad_action', 'action must be one of: ' . implode( ', ', $valid ) );
		}

		// Absent means true. A caller that forgets the flag gets a preview, never a write.
		$dry_run = ! array_key_exists( 'dry_run', $args ) || (bool) $args['dry_run'];

		$limit = (int) ( $args['limit'] ?? 50 );
		$limit = max( 1, min( self::MAX_POSTS, $limit ) );

		$validation = self::validate_action( $action, $args );
		if ( is_wp_error( $validation ) ) {
			return $validation;
		}

		$posts = self::find_posts( $args, $limit );

		if ( ! $posts ) {
			return array(
				'matched'   => 0,
				'note'      => 'No posts matched those filters, so there is nothing to change. Widen the filter or check the category slug.',
			);
		}

		$changes = array();
		$skipped = array();

		foreach ( $posts as $post ) {
			if ( ! current_user_can( 'edit_post', $post->ID ) ) {
				$skipped[] = array( 'post_id' => $post->ID, 'reason' => 'no permission' );
				continue;
			}

			$change = self::apply_to_post( $action, $post, $args, $dry_run );

			if ( null === $change ) {
				continue; // Nothing to do on this post.
			}
			if ( is_wp_error( $change ) ) {
				$skipped[] = array( 'post_id' => $post->ID, 'reason' => $change->get_error_message() );
				continue;
			}

			$changes[] = $change;
		}

		return array(
			'action'    => $action,
			'dry_run'   => $dry_run,
			'matched'   => count( $posts ),
			'affected'  => count( $changes ),
			'skipped'   => $skipped,
			'changes'   => array_slice( $changes, 0, 50 ),
			'next_step' => $dry_run
				? ( $changes
					? 'PREVIEW ONLY — nothing has changed. Read the changes above, and if they are right, run the same call again with dry_run=false.'
					: 'PREVIEW ONLY — nothing matched for this action, so running it for real would do nothing.' )
				: sprintf( '%d post(s) changed. Content edits stored a revision first, so any single post can be rolled back from its revision history.', count( $changes ) ),
		);
	}

	/* ===================================================================== */

	/**
	 * Reject a call that cannot possibly work before it touches anything.
	 *
	 * @param string $action
	 * @param array  $args
	 * @return true|WP_Error
	 */
	private static function validate_action( $action, $args ) {
		if ( 'replace_text' === $action ) {
			$find = (string) ( $args['find'] ?? '' );

			if ( '' === $find ) {
				return new WP_Error( 'missing_find', 'replace_text needs a "find" value.' );
			}

			// A one or two character find string will match inside HTML attributes, URLs and
			// the middle of unrelated words, wrecking markup across every post it touches.
			if ( mb_strlen( $find ) < 3 ) {
				return new WP_Error(
					'find_too_short',
					'That "find" value is too short to be safe — it would match inside HTML tags, URLs and unrelated words. Use at least 3 characters, and prefer a distinctive phrase.'
				);
			}
		}

		if ( in_array( $action, array( 'add_category', 'remove_category', 'add_tag', 'remove_tag', 'set_status', 'set_focus_keyword' ), true ) ) {
			if ( '' === trim( (string) ( $args['value'] ?? '' ) ) ) {
				return new WP_Error( 'missing_value', sprintf( '%s needs a "value".', $action ) );
			}
		}

		if ( 'set_status' === $action ) {
			$status = sanitize_key( (string) $args['value'] );
			if ( ! in_array( $status, array( 'draft', 'pending', 'publish', 'private' ), true ) ) {
				return new WP_Error( 'bad_status', 'value must be draft, pending, publish or private.' );
			}
		}

		return true;
	}

	/**
	 * @param array $args
	 * @param int   $limit
	 * @return array<int, WP_Post>
	 */
	private static function find_posts( $args, $limit ) {
		// Explicit IDs beat every filter. It is the precise mode, and the one to reach for
		// when the change matters.
		if ( ! empty( $args['ids'] ) ) {
			$ids = array_filter( array_map( 'intval', explode( ',', (string) $args['ids'] ) ) );
			if ( ! $ids ) {
				return array();
			}

			return get_posts(
				array(
					'post__in'       => array_slice( $ids, 0, $limit ),
					'post_type'      => 'any',
					'post_status'    => 'any',
					'posts_per_page' => $limit,
					'orderby'        => 'post__in',
				)
			);
		}

		$query = array(
			'post_type'      => $args['post_type'] ?? 'post',
			'post_status'    => $args['status'] ?? 'publish',
			'posts_per_page' => $limit,
			'orderby'        => 'date',
			'order'          => 'DESC',
		);

		if ( ! empty( $args['category'] ) ) {
			$query['category_name'] = sanitize_title( (string) $args['category'] );
		}
		if ( ! empty( $args['search'] ) ) {
			$query['s'] = sanitize_text_field( (string) $args['search'] );
		}

		return get_posts( $query );
	}

	/**
	 * @param string  $action
	 * @param WP_Post $post
	 * @param array   $args
	 * @param bool    $dry_run
	 * @return array|WP_Error|null Null when this post needs no change.
	 */
	private static function apply_to_post( $action, $post, $args, $dry_run ) {
		$base = array(
			'post_id' => $post->ID,
			'title'   => axon_text( get_the_title( $post ) ),
			'url'     => get_permalink( $post ),
		);

		switch ( $action ) {
			case 'replace_text':
				$find    = (string) $args['find'];
				$replace = (string) ( $args['replace'] ?? '' );

				if ( false === strpos( $post->post_content, $find ) ) {
					return null;
				}

				$hits    = substr_count( $post->post_content, $find );
				$updated = str_replace( $find, $replace, $post->post_content );

				if ( ! $dry_run ) {
					// wp_update_post stores a revision of the old content first, which is what
					// makes a wrong replacement recoverable per post.
					$res = wp_update_post(
						array(
							'ID'           => $post->ID,
							'post_content' => $updated,
						),
						true
					);
					if ( is_wp_error( $res ) ) {
						return $res;
					}
				}

				return $base + array(
					'occurrences' => $hits,
					'before'      => self::snippet( $post->post_content, $find ),
					'after'       => self::snippet( $updated, '' === $replace ? '' : $replace ),
				);

			case 'add_category':
			case 'remove_category':
				$name = trim( (string) $args['value'] );
				$term = get_term_by( 'name', $name, 'category' );

				if ( ! $term ) {
					return new WP_Error( 'no_such_term', sprintf( 'No category named "%s". Create it first with manage_terms — bulk edit will not invent categories.', $name ) );
				}

				$current = wp_get_post_categories( $post->ID );
				$has     = in_array( (int) $term->term_id, $current, true );

				if ( ( 'add_category' === $action && $has ) || ( 'remove_category' === $action && ! $has ) ) {
					return null;
				}

				$new = 'add_category' === $action
					? array_merge( $current, array( (int) $term->term_id ) )
					: array_diff( $current, array( (int) $term->term_id ) );

				if ( ! $dry_run ) {
					wp_set_post_categories( $post->ID, array_values( $new ) );
				}

				return $base + array( 'category' => $name, 'operation' => $action );

			case 'add_tag':
			case 'remove_tag':
				$name    = trim( (string) $args['value'] );
				$current = wp_get_post_tags( $post->ID, array( 'fields' => 'names' ) );
				$has     = in_array( $name, (array) $current, true );

				if ( ( 'add_tag' === $action && $has ) || ( 'remove_tag' === $action && ! $has ) ) {
					return null;
				}

				$new = 'add_tag' === $action
					? array_merge( (array) $current, array( $name ) )
					: array_values( array_diff( (array) $current, array( $name ) ) );

				if ( ! $dry_run ) {
					wp_set_post_tags( $post->ID, $new, false );
				}

				return $base + array( 'tag' => $name, 'operation' => $action );

			case 'set_status':
				$status = sanitize_key( (string) $args['value'] );

				if ( $post->post_status === $status ) {
					return null;
				}

				if ( ! $dry_run ) {
					$res = wp_update_post( array( 'ID' => $post->ID, 'post_status' => $status ), true );
					if ( is_wp_error( $res ) ) {
						return $res;
					}
				}

				return $base + array( 'from' => $post->post_status, 'to' => $status );

			case 'set_focus_keyword':
				if ( ! $dry_run ) {
					$res = Axon_SEO_Tools::set_seo_meta(
						array(
							'post_id'       => $post->ID,
							'focus_keyword' => (string) $args['value'],
						)
					);
					if ( is_wp_error( $res ) ) {
						return $res;
					}
				}

				return $base + array( 'focus_keyword' => (string) $args['value'] );

			case 'apply_schema':
				if ( ! class_exists( 'Axon_Schema_Tools' ) ) {
					return new WP_Error( 'unavailable', 'The schema module is not loaded.' );
				}

				if ( $dry_run ) {
					$preview = Axon_Schema_Tools::generate_schema( array( 'post_id' => $post->ID ) );
					if ( is_wp_error( $preview ) ) {
						return $preview;
					}

					return $base + array( 'would_generate' => $preview['detected'] ?? array() );
				}

				$res = Axon_Schema_Tools::apply_schema( array( 'post_id' => $post->ID, 'auto' => true ) );
				if ( is_wp_error( $res ) ) {
					return $res;
				}

				return $base + array( 'applied' => $res['types'] ?? $res['detected'] ?? 'schema' );
		}

		return null;
	}

	/**
	 * A short window of text around a match, so a preview shows real context.
	 *
	 * @param string $haystack
	 * @param string $needle
	 * @return string
	 */
	private static function snippet( $haystack, $needle ) {
		if ( '' === $needle ) {
			return mb_substr( trim( wp_strip_all_tags( $haystack ) ), 0, 120 ) . '…';
		}

		$pos = strpos( $haystack, $needle );
		if ( false === $pos ) {
			return '';
		}

		$start = max( 0, $pos - 50 );

		return '…' . trim( preg_replace( '/\s+/u', ' ', substr( $haystack, $start, 160 ) ) ) . '…';
	}
}
