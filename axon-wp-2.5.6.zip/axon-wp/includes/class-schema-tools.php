<?php
/**
 * Structured data (Schema.org JSON-LD) generation, validation and coverage auditing.
 *
 * Schema is what tells a search or answer engine what a page *is* rather than merely
 * what it says — and FAQ/HowTo/Course markup is disproportionately likely to be lifted
 * into an AI answer or a rich result.
 *
 * Duplicate schema is worse than none: two conflicting FAQPage blocks on one URL make
 * Google distrust both. So every generator here checks what an existing SEO plugin is
 * already emitting and refuses to stack a second copy on top unless told to.
 *
 * Tools:
 *   generate_schema         - build JSON-LD from real page content (preview by default)
 *   apply_schema            - store and output it in wp_head
 *   validate_schema         - required/recommended field check
 *   audit_schema_coverage   - which pages have structured data, and which types
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Axon_Schema_Tools {

	const META = '_axon_schema';

	/**
	 * Google's required + recommended properties for the rich-result types we emit.
	 * Required fields missing means the markup is simply ignored.
	 *
	 * @var array<string, array{required: array<int,string>, recommended: array<int,string>}>
	 */
	const REQUIREMENTS = array(
		'FAQPage'      => array( 'required' => array( 'mainEntity' ), 'recommended' => array() ),
		'Article'      => array( 'required' => array( 'headline' ), 'recommended' => array( 'image', 'datePublished', 'dateModified', 'author' ) ),
		'BlogPosting'  => array( 'required' => array( 'headline' ), 'recommended' => array( 'image', 'datePublished', 'dateModified', 'author' ) ),
		'HowTo'        => array( 'required' => array( 'name', 'step' ), 'recommended' => array( 'totalTime', 'image' ) ),
		'Course'       => array( 'required' => array( 'name', 'description', 'provider' ), 'recommended' => array( 'hasCourseInstance', 'offers' ) ),
		'LocalBusiness'=> array( 'required' => array( 'name', 'address' ), 'recommended' => array( 'telephone', 'openingHoursSpecification', 'geo', 'priceRange' ) ),
		'Organization' => array( 'required' => array( 'name', 'url' ), 'recommended' => array( 'logo', 'sameAs', 'contactPoint' ) ),
		'BreadcrumbList' => array( 'required' => array( 'itemListElement' ), 'recommended' => array() ),
		'WebPage'      => array( 'required' => array( 'name' ), 'recommended' => array( 'description' ) ),
	);

	/**
	 * @return array<int, array<string, mixed>>
	 */
	public static function tools() {
		return array(
			array(
				'name'        => 'generate_schema',
				'description' => 'Build Schema.org JSON-LD from a page\'s actual content — FAQPage from question headings, HowTo from numbered steps, Article for posts, Course for programme pages, plus BreadcrumbList. Returns a preview by default and warns if another SEO plugin already emits schema for that URL.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'post_id' => array(
							'type'        => 'integer',
							'description' => 'Post or page ID to generate schema for.',
						),
						'types'   => array(
							'type'        => 'string',
							'description' => 'Comma-separated types to attempt: FAQPage, HowTo, Article, Course, BreadcrumbList, WebPage. Omit to auto-detect from the content.',
						),
					),
					'required'   => array( 'post_id' ),
				),
				'callback'    => array( __CLASS__, 'generate_schema' ),
			),
			array(
				'name'        => 'apply_schema',
				'description' => 'Store JSON-LD for a post and output it in the page head. Pass schema_json from generate_schema, or auto=true to generate and apply in one step. Set remove=true to strip it again. Always check for conflicts first — duplicate schema is worse than none.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'post_id'     => array( 'type' => 'integer', 'description' => 'Post or page ID.' ),
						'schema_json' => array( 'type' => 'string', 'description' => 'JSON-LD to store, as a JSON string. Ignored when auto=true.' ),
						'auto'        => array( 'type' => 'boolean', 'description' => 'Generate from content and apply in one step. Default false.' ),
						'remove'      => array( 'type' => 'boolean', 'description' => 'Remove stored schema for this post. Default false.' ),
						'force'       => array( 'type' => 'boolean', 'description' => 'Apply even when another SEO plugin already emits schema for this URL. Default false.' ),
					),
					'required'   => array( 'post_id' ),
				),
				'callback'    => array( __CLASS__, 'apply_schema' ),
			),
			array(
				'name'        => 'validate_schema',
				'description' => 'Validate the structured data on a post against Google\'s required and recommended properties for each type. Reports missing required fields (which make the markup ignored entirely) separately from missing recommended ones.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'post_id' => array( 'type' => 'integer', 'description' => 'Post or page ID to validate.' ),
					),
					'required'   => array( 'post_id' ),
				),
				'callback'    => array( __CLASS__, 'validate_schema' ),
			),
			array(
				'name'        => 'audit_schema_coverage',
				'description' => 'Site-wide structured data coverage: which published pages have schema, from which source (this plugin, Rank Math, Yoast, or inline), which types are present, and which high-value pages have none. Read-only.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'limit' => array( 'type' => 'integer', 'description' => 'How many published items to check. Default 100.' ),
					),
					'required'   => array(),
				),
				'callback'    => array( __CLASS__, 'audit_schema_coverage' ),
			),
		);
	}

	/* ===================================================================== */
	/* Generation                                                             */
	/* ===================================================================== */

	/**
	 * @param array $args
	 * @return array|WP_Error
	 */
	public static function generate_schema( $args ) {
		$id = isset( $args['post_id'] ) ? absint( $args['post_id'] ) : 0;
		if ( ! $id || ! get_post( $id ) ) {
			return new WP_Error( 'invalid_post', 'A valid post_id is required.' );
		}
		if ( ! current_user_can( 'edit_post', $id ) ) {
			return new WP_Error( 'forbidden', 'You do not have permission to edit this item.' );
		}

		$post = get_post( $id );
		$html = self::rendered_content( $post );

		$requested = ! empty( $args['types'] )
			? array_filter( array_map( 'trim', explode( ',', (string) $args['types'] ) ) )
			: array();

		$graph    = array();
		$detected = array();

		// --- FAQPage
		if ( ! $requested || in_array( 'FAQPage', $requested, true ) ) {
			$faq = self::extract_faq( $html );
			if ( count( $faq ) >= 2 ) {
				$graph[]    = array(
					'@type'      => 'FAQPage',
					'mainEntity' => array_map(
						static fn( $qa ) => array(
							'@type'          => 'Question',
							'name'           => $qa['q'],
							'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $qa['a'] ),
						),
						$faq
					),
				);
				$detected[] = 'FAQPage (' . count( $faq ) . ' Q&A pairs)';
			}
		}

		// --- HowTo
		if ( ! $requested || in_array( 'HowTo', $requested, true ) ) {
			$steps = self::extract_steps( $html );
			if ( count( $steps ) >= 3 ) {
				$graph[]    = array(
					'@type' => 'HowTo',
					'name'  => axon_text( get_the_title( $id ) ),
					'step'  => array_map(
						static fn( $s, $i ) => array(
							'@type'    => 'HowToStep',
							'position' => $i + 1,
							'name'     => $s['name'],
							'text'     => $s['text'],
						),
						$steps,
						array_keys( $steps )
					),
				);
				$detected[] = 'HowTo (' . count( $steps ) . ' steps)';
			}
		}

		// --- Course (explicit only: auto-detecting courses produces false positives)
		if ( in_array( 'Course', $requested, true ) ) {
			$graph[]    = array(
				'@type'       => 'Course',
				'name'        => axon_text( get_the_title( $id ) ),
				'description' => self::description_for( $post ),
				'url'         => get_permalink( $id ),
				'provider'    => array(
					'@type' => 'EducationalOrganization',
					'name'  => get_bloginfo( 'name' ),
					'url'   => home_url( '/' ),
				),
			);
			$detected[] = 'Course';
		}

		// --- Article / BlogPosting for posts
		if ( ( ! $requested && 'post' === $post->post_type ) || array_intersect( array( 'Article', 'BlogPosting' ), $requested ) ) {
			$article = array(
				'@type'         => 'BlogPosting',
				'headline'      => mb_substr( axon_text( get_the_title( $id ) ), 0, 110 ), // Google truncates past ~110.
				'description'   => self::description_for( $post ),
				'datePublished' => get_the_date( 'c', $id ),
				'dateModified'  => get_the_modified_date( 'c', $id ),
				'author'        => array(
					'@type' => 'Person',
					'name'  => get_the_author_meta( 'display_name', (int) $post->post_author ),
				),
				'publisher'     => self::publisher(),
				'mainEntityOfPage' => array( '@type' => 'WebPage', '@id' => get_permalink( $id ) ),
			);
			$img = get_the_post_thumbnail_url( $id, 'full' );
			if ( $img ) {
				$article['image'] = $img;
			}
			$graph[]    = $article;
			$detected[] = 'BlogPosting';
		}

		// --- Breadcrumbs
		if ( ! $requested || in_array( 'BreadcrumbList', $requested, true ) ) {
			$crumbs = self::breadcrumbs( $id );
			if ( count( $crumbs ) >= 2 ) {
				$graph[]    = array( '@type' => 'BreadcrumbList', 'itemListElement' => $crumbs );
				$detected[] = 'BreadcrumbList';
			}
		}

		// --- WebPage fallback so we never return nothing useful.
		if ( ! $graph ) {
			$graph[]    = array(
				'@type'       => 'WebPage',
				'name'        => axon_text( get_the_title( $id ) ),
				'description' => self::description_for( $post ),
				'url'         => get_permalink( $id ),
			);
			$detected[] = 'WebPage (fallback — no FAQ, steps or article structure found)';
		}

		$doc = array( '@context' => 'https://schema.org', '@graph' => $graph );

		$conflict = self::existing_schema_source( $id );

		return array(
			'post_id'   => $id,
			'title'     => axon_text( get_the_title( $id ) ),
			'url'       => get_permalink( $id ),
			'detected'  => $detected,
			'schema'    => $doc,
			'schema_json' => wp_json_encode( $doc, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT ),
			'conflict'  => $conflict,
			'warning'   => $conflict
				? "This URL already has structured data from {$conflict}. Two conflicting blocks of the same type make search engines distrust both — either remove the other source, or apply only the types it is not already emitting."
				: '',
			'next_step' => 'Review the output, then call apply_schema with this schema_json.',
		);
	}

	/**
	 * Pull question/answer pairs out of rendered HTML.
	 *
	 * A heading is a question when it ends in "?" or opens with an interrogative. The
	 * answer is everything up to the next heading of the same or higher level.
	 *
	 * @param string $html
	 * @return array<int, array{q: string, a: string}>
	 */
	private static function extract_faq( $html ) {
		// Drop the footer before looking for anything. An answer runs from its heading to the
		// next heading, so the LAST question on a page absorbs everything after it — footer
		// included. That is how "…the next intake date." acquired a tail of
		// "The IIMT Institute … ⭐ 4.9 / 5.0 Google Rating (550+ Reviews)": site-wide chrome
		// submitted to Google as the answer to a specific question.
		// Cut at the LAST footer marker, and only when it genuinely sits in the back half of
		// the document. Cutting at the FIRST match was too eager: page builders use "footer"
		// in class names on inner sections, so a real FAQ midway down the fees page was
		// discarded along with the chrome. The last-and-late rule keeps the real footer and
		// leaves content alone.
		if ( preg_match_all( '/<footer\b|elementor-location-footer|class="[^"]*(?:site-footer|footer-widgets)/i', (string) $html, $fm, PREG_OFFSET_CAPTURE ) ) {
			$last = (int) end( $fm[0] )[1];
			if ( $last > (int) ( strlen( (string) $html ) * 0.5 ) ) {
				$html = substr( (string) $html, 0, $last );
			}
		}

		if ( ! preg_match_all( '/<h([2-4])[^>]*>(.*?)<\/h\1>/is', $html, $m, PREG_OFFSET_CAPTURE ) ) {
			return array();
		}

		$out   = array();
		$count = count( $m[0] );

		for ( $i = 0; $i < $count; $i++ ) {
			$heading = self::plain_text( $m[2][ $i ][0] );
			if ( '' === $heading ) {
				continue;
			}

			// Deliberately strict: the heading must actually END IN A QUESTION MARK.
			//
			// The looser "starts with how/what/why" test used for citability SCORING is
			// wrong for markup — it matches statement headings like "How IIMT Trains
			// Students", and Google treats FAQPage markup on non-questions as structured
			// data abuse, which risks a manual action. Scoring can afford to be generous;
			// markup cannot.
			if ( ! preg_match( '/\?\s*$/', $heading ) ) {
				continue;
			}

			// A question mark alone is not enough. Calls to action are frequently phrased as
			// questions — "Not sure which programme fits you?", "Want the exact fee?" — and
			// the block beneath them is a sales pitch, not an answer. Google's FAQPage
			// guidelines require genuine question-and-answer content and treat promotional
			// markup as spam, so a real informational question is required: one that OPENS
			// with an interrogative. Every genuine FAQ on the source site passes this
			// ("What is the eligibility…", "Does IIMT provide…", "Can I get placed…") and
			// every CTA fails it.
			if ( ! preg_match( '/^\s*(what|how|why|when|where|who|whom|whose|which|is|are|was|were|do|does|did|can|could|should|would|will|shall|may|might|has|have|had|am)\b/i', $heading ) ) {
				continue;
			}

			$start = $m[0][ $i ][1] + strlen( $m[0][ $i ][0] );
			$end   = ( $i + 1 < $count ) ? $m[0][ $i + 1 ][1] : strlen( $html );
			$body  = self::plain_text( substr( $html, $start, $end - $start ) );

			// Too short is not an answer; overly long gets truncated on a sentence boundary.
			if ( str_word_count( $body ) < 8 ) {
				continue;
			}
			if ( mb_strlen( $body ) > 1200 ) {
				$cut  = mb_substr( $body, 0, 1200 );
				$stop = mb_strrpos( $cut, '. ' );
				$body = $stop ? mb_substr( $cut, 0, $stop + 1 ) : $cut;
			}

			$out[] = array( 'q' => $heading, 'a' => $body );
		}

		return self::strip_shared_boilerplate( $out );
	}

	/**
	 * Remove site chrome that leaked into the answers.
	 *
	 * The answer to a heading is the text up to the next heading — and for the LAST heading
	 * on a page that means everything to the end of the document, footer included. On the
	 * source site that appended the footer blurb and star rating to the final answer:
	 * "…Get Fee Details → The IIMT Institute … ⭐ 4.9 / 5.0 Google Rating (550+ Reviews)".
	 *
	 * Rather than hunt for footer markup, which differs per theme, this uses the giveaway
	 * property of boilerplate: it REPEATS. Any long trailing run of text shared by two or
	 * more answers is chrome by definition — genuine answers to different questions do not
	 * end with the same sentence.
	 *
	 * @param array<int, array{q: string, a: string}> $pairs
	 * @return array<int, array{q: string, a: string}>
	 */
	private static function strip_shared_boilerplate( $pairs ) {
		if ( count( $pairs ) < 2 ) {
			return $pairs;
		}

		$answers = wp_list_pluck( $pairs, 'a' );
		$suffix  = '';

		// Grow a common suffix character by character from the end of the first answer,
		// keeping the longest run that at least one OTHER answer also ends with.
		$first = $answers[0];
		$max   = min( mb_strlen( $first ), 400 );

		for ( $len = 40; $len <= $max; $len++ ) {
			$candidate = mb_substr( $first, -$len );
			$shared    = 0;

			foreach ( array_slice( $answers, 1 ) as $other ) {
				if ( mb_substr( $other, -mb_strlen( $candidate ) ) === $candidate ) {
					++$shared;
				}
			}

			if ( $shared > 0 ) {
				$suffix = $candidate;
			}
		}

		if ( '' === $suffix ) {
			return $pairs;
		}

		foreach ( $pairs as $i => $pair ) {
			if ( mb_substr( $pair['a'], -mb_strlen( $suffix ) ) === $suffix ) {
				$trimmed = trim( mb_substr( $pair['a'], 0, mb_strlen( $pair['a'] ) - mb_strlen( $suffix ) ) );
				// Only accept the trim if a real answer survives it; otherwise the "answer"
				// was boilerplate end to end and the pair should go entirely.
				$pairs[ $i ]['a'] = ( str_word_count( $trimmed ) >= 8 ) ? $trimmed : '';
			}
		}

		return array_values(
			array_filter(
				$pairs,
				static function ( $p ) {
					return '' !== $p['a'];
				}
			)
		);
	}

	/**
	 * Steps from an ordered list, for HowTo.
	 *
	 * @param string $html
	 * @return array<int, array{name: string, text: string}>
	 */
	private static function extract_steps( $html ) {
		if ( ! preg_match( '/<ol[^>]*>(.*?)<\/ol>/is', $html, $ol ) ) {
			return array();
		}
		if ( ! preg_match_all( '/<li[^>]*>(.*?)<\/li>/is', $ol[1], $li ) ) {
			return array();
		}

		$steps = array();
		foreach ( $li[1] as $item ) {
			$text = self::plain_text( $item );
			if ( str_word_count( $text ) < 3 ) {
				continue;
			}
			// First sentence (or first 60 chars) becomes the step name.
			$name    = preg_split( '/(?<=[.!?])\s/', $text )[0] ?? $text;
			$steps[] = array(
				'name' => mb_substr( $name, 0, 80 ),
				'text' => mb_substr( $text, 0, 500 ),
			);
		}
		return $steps;
	}

	/**
	 * @param int $id
	 * @return array<int, array<string, mixed>>
	 */
	private static function breadcrumbs( $id ) {
		$trail = array();
		$chain = array();

		$parent = (int) wp_get_post_parent_id( $id );
		while ( $parent ) {
			array_unshift( $chain, $parent );
			$parent = (int) wp_get_post_parent_id( $parent );
		}

		$pos     = 1;
		$trail[] = array(
			'@type'    => 'ListItem',
			'position' => $pos++,
			'name'     => 'Home',
			'item'     => home_url( '/' ),
		);
		foreach ( $chain as $pid ) {
			$trail[] = array(
				'@type'    => 'ListItem',
				'position' => $pos++,
				'name'     => axon_text( get_the_title( $pid ) ),
				'item'     => get_permalink( $pid ),
			);
		}
		$trail[] = array(
			'@type'    => 'ListItem',
			'position' => $pos,
			'name'     => axon_text( get_the_title( $id ) ),
			'item'     => get_permalink( $id ),
		);

		return $trail;
	}

	/**
	 * @return array<string, mixed>
	 */
	private static function publisher() {
		$pub = array(
			'@type' => 'Organization',
			'name'  => get_bloginfo( 'name' ),
			'url'   => home_url( '/' ),
		);
		$logo_id = (int) get_theme_mod( 'custom_logo' );
		if ( $logo_id ) {
			$src = wp_get_attachment_image_src( $logo_id, 'full' );
			if ( $src ) {
				$pub['logo'] = array( '@type' => 'ImageObject', 'url' => $src[0], 'width' => $src[1], 'height' => $src[2] );
			}
		}
		return $pub;
	}

	/**
	 * @param WP_Post $post
	 * @return string
	 */
	private static function description_for( $post ) {
		// Delegate to the single shared resolver. This used to be its own implementation that
		// checked only Rank Math's meta key and did no cleaning, which put a stripped
		// navigation menu into Schema.org descriptions on page-builder sites.
		if ( class_exists( 'Axon_GEO_Tools' ) ) {
			return Axon_GEO_Tools::page_description( $post );
		}

		// Only reachable if the GEO module were ever removed from the plugin.
		return axon_text( trim( preg_replace( '/\s+/', ' ', (string) $post->post_excerpt ) ) );
	}

	/**
	 * Elementor keeps content in postmeta, so post_content alone yields nothing to parse.
	 *
	 * @param WP_Post $post
	 * @return string
	 */
	private static function rendered_content( $post ) {
		$html = (string) $post->post_content;

		if ( class_exists( '\Elementor\Plugin' ) && get_post_meta( $post->ID, '_elementor_edit_mode', true ) ) {
			try {
				$el = \Elementor\Plugin::instance();
				if ( isset( $el->frontend ) && method_exists( $el->frontend, 'get_builder_content' ) ) {
					$built = (string) $el->frontend->get_builder_content( $post->ID, true );
					if ( strlen( $built ) > strlen( $html ) ) {
						return $built;
					}
				}
			} catch ( Exception $e ) {
				// Fall back to raw content.
			}
		}

		return apply_filters( 'the_content', $html );
	}

	/**
	 * Which plugin, if any, already emits schema for this post.
	 *
	 * @param int $id
	 * @return string
	 */
	private static function existing_schema_source( $id ) {
		foreach ( get_post_meta( $id ) as $key => $v ) {
			if ( 0 === strpos( $key, 'rank_math_schema_' ) ) {
				return 'Rank Math';
			}
			if ( 0 === strpos( $key, '_yoast_wpseo_schema' ) ) {
				return 'Yoast SEO';
			}
		}
		if ( defined( 'RANK_MATH_VERSION' ) ) {
			// Rank Math emits Article/WebPage sitewide even without per-post meta.
			return 'Rank Math (site-wide defaults)';
		}
		if ( defined( 'WPSEO_VERSION' ) ) {
			return 'Yoast SEO (site-wide defaults)';
		}
		return '';
	}

	/* ===================================================================== */
	/* Apply / remove                                                         */
	/* ===================================================================== */

	/**
	 * @param array $args
	 * @return array|WP_Error
	 */
	public static function apply_schema( $args ) {
		$id = isset( $args['post_id'] ) ? absint( $args['post_id'] ) : 0;
		if ( ! $id || ! get_post( $id ) ) {
			return new WP_Error( 'invalid_post', 'A valid post_id is required.' );
		}
		if ( ! current_user_can( 'edit_post', $id ) ) {
			return new WP_Error( 'forbidden', 'You do not have permission to edit this item.' );
		}

		if ( ! empty( $args['remove'] ) ) {
			delete_post_meta( $id, self::META );
			return array( 'post_id' => $id, 'removed' => true );
		}

		if ( ! empty( $args['auto'] ) ) {
			$gen = self::generate_schema( array( 'post_id' => $id ) );
			if ( is_wp_error( $gen ) ) {
				return $gen;
			}
			$doc = $gen['schema'];
		} else {
			if ( empty( $args['schema_json'] ) ) {
				return new WP_Error( 'missing_schema', 'Provide schema_json, or set auto=true to generate it.' );
			}
			$doc = json_decode( (string) $args['schema_json'], true );
			if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $doc ) ) {
				return new WP_Error( 'invalid_json', 'schema_json is not valid JSON: ' . json_last_error_msg() );
			}
		}

		$conflict = self::existing_schema_source( $id );
		if ( $conflict && empty( $args['force'] ) ) {
			return new WP_Error(
				'schema_conflict',
				"{$conflict} already provides structured data for this URL. Adding a second block risks both being ignored. Remove the other source first, or pass force=true if you are sure the types do not overlap."
			);
		}

		update_post_meta( $id, self::META, wp_slash( wp_json_encode( $doc, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) ) );

		return array(
			'post_id'  => $id,
			'url'      => get_permalink( $id ),
			'applied'  => true,
			'types'    => self::types_in( $doc ),
			'forced'   => ! empty( $args['force'] ),
			'next_step' => 'Purge any page cache, then confirm with Google\'s Rich Results Test.',
		);
	}

	/**
	 * Output stored JSON-LD. Hooked to wp_head from the main plugin file.
	 */
	public static function output_schema() {
		if ( ! is_singular() ) {
			return;
		}
		$json = get_post_meta( get_queried_object_id(), self::META, true );
		if ( ! $json ) {
			return;
		}
		// Stored as JSON we generated ourselves; decode/re-encode to guarantee validity.
		$doc = json_decode( (string) $json, true );
		if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $doc ) ) {
			return;
		}
		echo "\n<script type=\"application/ld+json\">"
			. wp_json_encode( $doc, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE )
			. "</script>\n";
	}

	/* ===================================================================== */
	/* Validation & coverage                                                  */
	/* ===================================================================== */

	/**
	 * @param array $args
	 * @return array|WP_Error
	 */
	public static function validate_schema( $args ) {
		$id = isset( $args['post_id'] ) ? absint( $args['post_id'] ) : 0;
		if ( ! $id || ! get_post( $id ) ) {
			return new WP_Error( 'invalid_post', 'A valid post_id is required.' );
		}
		if ( ! current_user_can( 'edit_posts' ) ) {
			return new WP_Error( 'forbidden', 'You need the edit_posts capability.' );
		}

		$json = get_post_meta( $id, self::META, true );
		if ( ! $json ) {
			return array(
				'post_id' => $id,
				'has_schema' => false,
				'other_source' => self::existing_schema_source( $id ),
				'message' => 'No schema stored by this plugin for that post.',
			);
		}

		$doc    = json_decode( (string) $json, true );
		$nodes  = $doc['@graph'] ?? array( $doc );
		$issues = array();

		foreach ( $nodes as $node ) {
			$type = $node['@type'] ?? '';
			if ( ! $type || ! isset( self::REQUIREMENTS[ $type ] ) ) {
				continue;
			}
			foreach ( self::REQUIREMENTS[ $type ]['required'] as $prop ) {
				if ( empty( $node[ $prop ] ) ) {
					$issues[] = array(
						'severity' => 'critical',
						'type'     => $type,
						'message'  => "{$type} is missing the required property '{$prop}'. Search engines ignore the whole block when a required field is absent.",
					);
				}
			}
			foreach ( self::REQUIREMENTS[ $type ]['recommended'] as $prop ) {
				if ( empty( $node[ $prop ] ) ) {
					$issues[] = array(
						'severity' => 'warn',
						'type'     => $type,
						'message'  => "{$type} is missing the recommended property '{$prop}'. Valid without it, but less likely to earn a rich result.",
					);
				}
			}
		}

		return array(
			'post_id'  => $id,
			'url'      => get_permalink( $id ),
			'types'    => self::types_in( $doc ),
			'valid'    => ! array_filter( $issues, static fn( $i ) => 'critical' === $i['severity'] ),
			'issues'   => $issues,
			'note'     => 'Field-level check only. For final confirmation use Google\'s Rich Results Test against the live URL.',
		);
	}

	/**
	 * @param array $args
	 * @return array|WP_Error
	 */
	public static function audit_schema_coverage( $args ) {
		if ( ! current_user_can( 'edit_posts' ) ) {
			return new WP_Error( 'forbidden', 'You need the edit_posts capability.' );
		}

		$limit = isset( $args['limit'] ) ? min( 500, max( 1, absint( $args['limit'] ) ) ) : 100;
		$ids   = get_posts(
			array(
				'post_type'      => array( 'page', 'post' ),
				'post_status'    => 'publish',
				'posts_per_page' => $limit,
				'orderby'        => 'modified',
				'order'          => 'DESC',
				'fields'         => 'ids',
			)
		);

		$with    = array();
		$without = array();
		$types   = array();

		foreach ( $ids as $id ) {
			$id     = (int) $id;
			$ours   = get_post_meta( $id, self::META, true );
			$other  = self::existing_schema_source( $id );
			$inline = false !== strpos( (string) get_post_field( 'post_content', $id ), 'application/ld+json' );

			if ( $ours || $inline || ( $other && false === strpos( $other, 'site-wide' ) ) ) {
				$source = $ours ? 'this plugin' : ( $inline ? 'inline in content' : $other );
				$with[] = array( 'post_id' => $id, 'title' => axon_text( get_the_title( $id ) ), 'source' => $source );
				if ( $ours ) {
					foreach ( self::types_in( json_decode( (string) $ours, true ) ) as $t ) {
						$types[ $t ] = ( $types[ $t ] ?? 0 ) + 1;
					}
				}
			} else {
				$without[] = array(
					'post_id' => $id,
					'title'   => axon_text( get_the_title( $id ) ),
					'url'     => get_permalink( $id ),
					'type'    => get_post_type( $id ),
				);
			}
		}

		return array(
			'checked'      => count( $ids ),
			'with_schema'  => count( $with ),
			'without_schema' => count( $without ),
			'coverage'     => count( $ids ) ? round( count( $with ) / count( $ids ) * 100 ) . '%' : '0%',
			'types_in_use' => $types,
			'missing'      => array_slice( $without, 0, 50 ),
			'note'         => 'Pages relying only on an SEO plugin\'s site-wide defaults count as missing here — those emit generic WebPage/Article markup, not the FAQ/HowTo/Course types that actually earn rich results and AI citations.',
		);
	}

	/**
	 * Tags out, entities decoded, whitespace collapsed.
	 *
	 * Entity decoding is not cosmetic: WordPress stores "&#038;" for an ampersand, and
	 * JSON-LD is not HTML — leaving it encoded puts the literal string "Food &#038;
	 * Beverage" into the structured data a search engine reads.
	 *
	 * @param string $html
	 * @return string
	 */
	private static function plain_text( $html ) {
		$text = wp_strip_all_tags( (string) $html );
		$text = html_entity_decode( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		return trim( preg_replace( '/\s+/', ' ', $text ) );
	}

	/**
	 * @param mixed $doc
	 * @return array<int, string>
	 */
	private static function types_in( $doc ) {
		if ( ! is_array( $doc ) ) {
			return array();
		}
		$nodes = $doc['@graph'] ?? array( $doc );
		$out   = array();
		foreach ( $nodes as $n ) {
			if ( ! empty( $n['@type'] ) ) {
				$out[] = is_array( $n['@type'] ) ? implode( '/', $n['@type'] ) : (string) $n['@type'];
			}
		}
		return array_values( array_unique( $out ) );
	}
}
