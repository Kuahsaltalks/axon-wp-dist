<?php
/**
 * Media upload and whole-site control.
 *
 * Two tools that between them close almost every remaining gap.
 *
 * `upload_media` exists as its own tool because binary upload does not travel well through a
 * JSON API — it needs its own handling for URLs and base64, plus the sideload dance that
 * registers the file as a real attachment with generated thumbnail sizes. Until this existed,
 * an AI could set alt text on an image but could not put an image on the site at all.
 *
 * `wp_rest` is the deliberate escape hatch. WordPress already exposes posts, pages, media,
 * menus, settings, users, comments, plugins and themes over its REST API — and every plugin
 * that registers routes gets the same treatment for free. Wrapping each of those in a
 * hand-written tool would be dozens of near-identical files that go stale the moment a site
 * installs something new. One bridge covers all of it, permanently.
 *
 * WHY THE BRIDGE IS SAFE
 * ---------------------
 * It runs through rest_do_request(), which is WordPress's own internal dispatcher: every
 * route's permission_callback runs exactly as it would for an HTTP request. The bridge cannot
 * do anything the connected account could not already do in wp-admin. It grants reach, not
 * privilege.
 *
 * The one thing it refuses is setting user passwords — see the guard in dispatch(). Handing an
 * automated caller the ability to rewrite credentials is a different kind of power from
 * editing content, and it is not one this plugin should offer.
 *
 * @package Axon
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Media upload and a general REST bridge.
 */
class Axon_Site_Tools {

	/**
	 * @return array<int, array<string, mixed>>
	 */
	public static function tools() {
		return array(
			array(
				'name'        => 'upload_media',
				'description' => 'Add an image or file to the Media Library, from a URL or from base64 data. Returns the attachment ID, which you can pass to create_post as featured_image. Set alt_text at upload time — it is required for accessibility and is read by AI crawlers.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'url'       => array( 'type' => 'string', 'description' => 'Public URL to fetch the file from. Use this or base64.' ),
						'base64'    => array( 'type' => 'string', 'description' => 'Raw base64 file data. Use this or url. A data: prefix is accepted and stripped.' ),
						'filename'  => array( 'type' => 'string', 'description' => 'Filename with extension, e.g. "campus-kitchen.jpg". Required with base64; inferred from the URL otherwise.' ),
						'alt_text'  => array( 'type' => 'string', 'description' => 'Descriptive alt text. Describe what is in the image, not the keyword you want to rank for.' ),
						'title'     => array( 'type' => 'string', 'description' => 'Media library title.' ),
						'caption'   => array( 'type' => 'string', 'description' => 'Caption shown beneath the image.' ),
						'post_id'   => array( 'type' => 'integer', 'description' => 'Attach the file to this post.' ),
					),
					'required'   => array(),
				),
				'callback'    => array( __CLASS__, 'upload_media' ),
			),
			array(
				'name'        => 'wp_rest',
				'description' => 'Call any WordPress REST API route directly — the general-purpose way to reach anything without a dedicated tool: settings, menus, comments, users, plugins, themes, WooCommerce, ACF, and any plugin that registers routes. Runs with the connected account\'s own permissions, so it can never exceed what that user could do in wp-admin. Use list_routes=true first to discover what this site actually offers.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'route'       => array( 'type' => 'string', 'description' => 'Route path, e.g. "/wp/v2/settings", "/wp/v2/menus", "/wp/v2/comments". Leading slash required.' ),
						'method'      => array( 'type' => 'string', 'description' => 'GET, POST, PUT, PATCH or DELETE. Default GET.' ),
						'params'      => array( 'type' => 'object', 'description' => 'Parameters or body, as an object. Query string for GET, request body otherwise.' ),
						'list_routes' => array( 'type' => 'boolean', 'description' => 'Instead of calling anything, return the routes available on this site. Use a route value as a filter, e.g. "/wp/v2" to list only core routes.' ),
					),
					'required'   => array(),
				),
				'callback'    => array( __CLASS__, 'wp_rest' ),
			),
		);
	}

	/* ===================================================================== */
	/* Media                                                                  */
	/* ===================================================================== */

	/**
	 * @param array $args
	 * @return array|WP_Error
	 */
	public static function upload_media( $args ) {
		if ( ! current_user_can( 'upload_files' ) ) {
			return new WP_Error( 'forbidden', 'You need the upload_files capability.' );
		}

		// These live in admin includes and are absent on a front-end or REST request, which
		// is exactly where this tool runs.
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$url    = trim( (string) ( $args['url'] ?? '' ) );
		$base64 = (string) ( $args['base64'] ?? '' );

		if ( '' === $url && '' === $base64 ) {
			return new WP_Error( 'missing_source', 'Pass either url or base64.' );
		}

		if ( '' !== $url ) {
			$tmp = download_url( $url, 60 );
			if ( is_wp_error( $tmp ) ) {
				return new WP_Error( 'download_failed', 'Could not fetch that URL: ' . $tmp->get_error_message() );
			}
			$filename = (string) ( $args['filename'] ?? '' );
			if ( '' === $filename ) {
				$filename = basename( (string) wp_parse_url( $url, PHP_URL_PATH ) );
			}
		} else {
			$filename = (string) ( $args['filename'] ?? '' );
			if ( '' === $filename ) {
				@unlink( $tmp ?? '' ); // phpcs:ignore
				return new WP_Error( 'missing_filename', 'filename is required when uploading base64 data — WordPress needs the extension to determine the file type.' );
			}

			// Accept a full data: URI as well as bare base64; callers produce both.
			if ( false !== strpos( $base64, ',' ) && 0 === strpos( $base64, 'data:' ) ) {
				$base64 = substr( $base64, strpos( $base64, ',' ) + 1 );
			}

			$bytes = base64_decode( $base64, true );
			if ( false === $bytes || '' === $bytes ) {
				return new WP_Error( 'bad_base64', 'That base64 data could not be decoded.' );
			}

			$tmp = wp_tempnam( $filename );
			if ( ! $tmp || false === file_put_contents( $tmp, $bytes ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions
				return new WP_Error( 'temp_failed', 'Could not write a temporary file. Check the server temp directory is writable.' );
			}
		}

		$filename = sanitize_file_name( $filename );

		// Enforce WordPress's own upload rules rather than trusting the extension: an
		// arbitrary file type reaching wp-content is how a media uploader becomes a way to
		// execute code.
		$checked = wp_check_filetype( $filename );
		if ( empty( $checked['type'] ) ) {
			@unlink( $tmp ); // phpcs:ignore
			return new WP_Error( 'bad_filetype', sprintf( 'WordPress does not allow "%s" uploads on this site.', $filename ) );
		}

		$id = media_handle_sideload(
			array(
				'name'     => $filename,
				'tmp_name' => $tmp,
			),
			(int) ( $args['post_id'] ?? 0 ),
			isset( $args['title'] ) ? sanitize_text_field( (string) $args['title'] ) : null
		);

		if ( is_wp_error( $id ) ) {
			@unlink( $tmp ); // phpcs:ignore
			return $id;
		}

		if ( isset( $args['alt_text'] ) ) {
			update_post_meta( $id, '_wp_attachment_image_alt', sanitize_text_field( (string) $args['alt_text'] ) );
		}
		if ( ! empty( $args['caption'] ) ) {
			wp_update_post(
				array(
					'ID'           => $id,
					'post_excerpt' => sanitize_text_field( (string) $args['caption'] ),
				)
			);
		}

		$meta = wp_get_attachment_metadata( $id );

		return array(
			'action'        => 'uploaded',
			'attachment_id' => (int) $id,
			'url'           => wp_get_attachment_url( $id ),
			'filename'      => $filename,
			'mime'          => get_post_mime_type( $id ),
			'width'         => $meta['width'] ?? null,
			'height'        => $meta['height'] ?? null,
			'alt_text'      => (string) get_post_meta( $id, '_wp_attachment_image_alt', true ),
			'next_step'     => empty( $args['alt_text'] )
				? 'No alt text was set. Add it with set_media_alt_text — images without it are invisible to screen readers and to AI crawlers.'
				: 'Pass attachment_id ' . (int) $id . ' as featured_image on create_post or update_post to use it.',
		);
	}

	/* ===================================================================== */
	/* REST bridge                                                            */
	/* ===================================================================== */

	/**
	 * @param array $args
	 * @return array|WP_Error
	 */
	public static function wp_rest( $args ) {
		if ( ! is_user_logged_in() ) {
			return new WP_Error( 'forbidden', 'This tool acts as the connected WordPress user; no user is connected.' );
		}

		if ( ! empty( $args['list_routes'] ) ) {
			return self::list_routes( (string) ( $args['route'] ?? '' ) );
		}

		$route = trim( (string) ( $args['route'] ?? '' ) );
		if ( '' === $route ) {
			return new WP_Error( 'missing_route', 'Pass a route, e.g. "/wp/v2/settings". Call with list_routes=true to see what is available.' );
		}
		if ( '/' !== $route[0] ) {
			$route = '/' . $route;
		}

		$method = strtoupper( sanitize_key( $args['method'] ?? 'GET' ) );
		if ( ! in_array( $method, array( 'GET', 'POST', 'PUT', 'PATCH', 'DELETE' ), true ) ) {
			return new WP_Error( 'bad_method', 'method must be GET, POST, PUT, PATCH or DELETE.' );
		}

		$params = $args['params'] ?? array();
		if ( is_string( $params ) && '' !== $params ) {
			$decoded = json_decode( $params, true );
			$params  = is_array( $decoded ) ? $decoded : array();
		}
		if ( ! is_array( $params ) ) {
			$params = array();
		}

		return self::dispatch( $method, $route, $params );
	}

	/**
	 * Run the request through WordPress's own dispatcher.
	 *
	 * @param string $method
	 * @param string $route
	 * @param array  $params
	 * @return array|WP_Error
	 */
	private static function dispatch( $method, $route, $params ) {
		// The one refusal. Everything else this bridge does is bounded by the user's
		// capabilities, but rewriting a password is a credential operation, not a content
		// one, and an automated caller should not be able to do it even when the account
		// technically may.
		if ( isset( $params['password'] ) && preg_match( '#^/wp/v2/users#', $route ) ) {
			return new WP_Error(
				'refused',
				'Setting user passwords through this tool is not supported. Change passwords in wp-admin, or through your password manager.'
			);
		}

		$request = new WP_REST_Request( $method, $route );

		if ( 'GET' === $method ) {
			$request->set_query_params( $params );
		} else {
			$request->set_body_params( $params );
		}

		$response = rest_do_request( $request );

		if ( $response->is_error() ) {
			$err = $response->as_error();
			return new WP_Error(
				$err->get_error_code(),
				$err->get_error_message(),
				array(
					'status'    => $response->get_status(),
					'route'     => $route,
					'hint'      => 404 === $response->get_status()
						? 'No such route on this site. Call wp_rest with list_routes=true to see what exists.'
						: '',
				)
			);
		}

		$data = $response->get_data();

		// A full listing can be enormous — an unbounded dump helps nobody and costs the
		// caller its entire context. Report the size and let them page instead.
		$encoded = wp_json_encode( $data );
		if ( is_string( $encoded ) && strlen( $encoded ) > 100000 ) {
			return array(
				'route'     => $route,
				'status'    => $response->get_status(),
				'truncated' => true,
				'bytes'     => strlen( $encoded ),
				'note'      => 'The response was over 100 KB and has not been returned in full. Narrow it with params such as per_page, page, or _fields.',
				'sample'    => is_array( $data ) ? array_slice( $data, 0, 3 ) : null,
			);
		}

		return array(
			'route'  => $route,
			'method' => $method,
			'status' => $response->get_status(),
			'data'   => $data,
		);
	}

	/**
	 * What this particular site can actually be asked to do.
	 *
	 * @param string $filter Optional route prefix.
	 * @return array
	 */
	private static function list_routes( $filter ) {
		$all   = rest_get_server()->get_routes();
		$out   = array();
		$count = 0;

		foreach ( $all as $route => $handlers ) {
			if ( '' !== $filter && 0 !== strpos( $route, $filter ) ) {
				continue;
			}

			// Routes with path variables are noise in a discovery listing.
			if ( false !== strpos( $route, '(?P<' ) ) {
				continue;
			}

			$methods = array();
			foreach ( $handlers as $handler ) {
				foreach ( array_keys( (array) ( $handler['methods'] ?? array() ) ) as $m ) {
					$methods[ $m ] = true;
				}
			}

			$out[] = array( 'route' => $route, 'methods' => array_keys( $methods ) );
			++$count;
		}

		return array(
			'count'  => $count,
			'routes' => $out,
			'note'   => 'Anything listed here can be called with wp_rest, subject to your own WordPress permissions. Namespaces beyond /wp/v2 come from the plugins installed on this site.',
		);
	}
}
