<?php
/**
 * OAuth discovery metadata: RFC 8414 (authorization server) and RFC 9728
 * (protected resource). MCP clients (claude.ai, etc.) fetch these first
 * to learn where /authorize, /token, and /register live.
 *
 * @package MCP_OAuth_Bridge
 */

declare(strict_types=1);

namespace MCP_OAuth_Bridge;

defined( 'ABSPATH' ) || exit;

class Discovery {

	public function __construct() {
		add_action( 'init', array( $this, 'maybe_serve' ), 0 );
	}

	public function maybe_serve(): void {
		$path = parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ); // phpcs:ignore
		$path = is_string( $path ) ? untrailingslashit( $path ) : '';

		if ( '/.well-known/oauth-authorization-server' === $path ) {
			$this->send_json( $this->authorization_server_metadata() );
		}

		if ( '/.well-known/oauth-protected-resource' === $path ) {
			$this->send_json( $this->protected_resource_metadata() );
		}
	}

	private function authorization_server_metadata(): array {
		$root = home_url();
		return array(
			'issuer'                                => $root,
			'authorization_endpoint'                 => $root . '/wp-json/mcp-oauth/v1/authorize',
			'token_endpoint'                          => $root . '/wp-json/mcp-oauth/v1/token',
			'registration_endpoint'                   => $root . '/wp-json/mcp-oauth/v1/register',
			'revocation_endpoint'                     => $root . '/wp-json/mcp-oauth/v1/revoke',
			'response_types_supported'                => array( 'code' ),
			'grant_types_supported'                   => array( 'authorization_code', 'refresh_token' ),
			'code_challenge_methods_supported'        => array( 'S256' ),
			'token_endpoint_auth_methods_supported'   => array( 'none', 'client_secret_post' ),
			'scopes_supported'                        => array( 'mcp' ),
		);
	}

	private function protected_resource_metadata(): array {
		$root = home_url();
		return array(
			'resource'               => $root . '/wp-json/mcp/mcp-adapter-default-server',
			'authorization_servers'  => array( $root ),
			'bearer_methods_supported' => array( 'header' ),
		);
	}

	private function send_json( array $data ): void {
		header( 'Content-Type: application/json' );
		header( 'Access-Control-Allow-Origin: *' );
		echo wp_json_encode( $data );
		exit;
	}
}
