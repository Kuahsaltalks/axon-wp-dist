<?php
/**
 * Resource server: validates our access_* bearer tokens on incoming requests.
 *
 * Hooks THREE places so an OAuth token unlocks every MCP endpoint variant:
 *
 *   1. rest_authentication_errors  — the generic WP REST auth layer. Covers
 *      the mcp-adapter endpoint (/wp-json/mcp/...) which uses standard
 *      current_user_can() permission checks that respect wp_set_current_user().
 *
 *   2. wpmcp_authenticate_request  — wordpress-mcp's OWN auth filter. Its
 *      streamable endpoint's permission_callback returns 401 unless this
 *      filter returns non-null, so hooking rest_authentication_errors alone
 *      is not enough to reach its (full) toolset. This is the important one.
 *
 *   3. rest_post_dispatch          — adds a spec-compliant WWW-Authenticate
 *      header to 401 responses on MCP routes, so MCP clients (claude.ai etc.)
 *      can auto-discover the OAuth server per RFC 9728 / the MCP auth spec.
 *
 * @package MCP_OAuth_Bridge
 */

declare(strict_types=1);

namespace MCP_OAuth_Bridge;

use WP_Error;
use WP_HTTP_Response;
use WP_REST_Request;
use WP_REST_Response;

defined( 'ABSPATH' ) || exit;

class Resource_Server {

	public function __construct() {
		// Priority 20: after wordpress-mcp's own JwtAuth (priority 10) has passed
		// on anything it doesn't recognize as its own JWT.
		add_filter( 'rest_authentication_errors', array( $this, 'authenticate_rest' ), 20 );
		add_filter( 'wpmcp_authenticate_request', array( $this, 'authenticate_mcp' ), 20, 2 );
		add_filter( 'rest_post_dispatch', array( $this, 'add_auth_challenge_header' ), 10, 3 );
	}

	/**
	 * Resolve the current request's bearer token to a token record, or null.
	 * Sets the WordPress current user as a side effect on success.
	 */
	private function resolve_token() {
		$auth = isset( $_SERVER['HTTP_AUTHORIZATION'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_AUTHORIZATION'] ) ) : ''; // phpcs:ignore

		// Some hosts strip Authorization; wordpress-mcp / WP core also expose it via getallheaders.
		if ( empty( $auth ) && function_exists( 'getallheaders' ) ) {
			foreach ( (array) getallheaders() as $key => $value ) {
				if ( 'authorization' === strtolower( (string) $key ) ) {
					$auth = (string) $value;
					break;
				}
			}
		}

		if ( empty( $auth ) || ! preg_match( '/Bearer\s+(\S+)/i', $auth, $matches ) ) {
			return null;
		}

		$token = $matches[1];
		if ( ! str_starts_with( $token, 'access_' ) ) {
			return null; // Not one of ours.
		}

		$record = Token_Store::validate_access_token( $token );
		if ( ! $record ) {
			return false; // Ours, but invalid/expired/revoked — signal an explicit failure.
		}

		$user = get_user_by( 'id', (int) $record['user_id'] );
		if ( ! $user ) {
			return false;
		}

		wp_set_current_user( $user->ID );
		return $record;
	}

	/**
	 * Generic WP REST authentication layer.
	 */
	public function authenticate_rest( $result ) {
		if ( ! empty( $result ) ) {
			return $result;
		}

		$record = $this->resolve_token();
		if ( null === $record ) {
			return $result; // No OAuth token present — defer to other handlers.
		}
		if ( false === $record ) {
			return new WP_Error(
				'mcp_oauth_invalid_token',
				'Access token is invalid, expired, or revoked.',
				array( 'status' => 401 )
			);
		}

		return true;
	}

	/**
	 * wordpress-mcp's own authentication filter. Returning true here makes its
	 * streamable endpoint's permission_callback grant access.
	 *
	 * @param mixed                $result  Current auth result from earlier filters.
	 * @param WP_REST_Request|null $request The request (unused; token read from header).
	 */
	public function authenticate_mcp( $result, $request = null ) {
		if ( ! empty( $result ) ) {
			return $result;
		}

		$record = $this->resolve_token();
		if ( is_array( $record ) ) {
			return true;
		}

		return $result;
	}

	/**
	 * Attach WWW-Authenticate to 401s on MCP routes so clients can discover the
	 * OAuth authorization server (RFC 9728 / MCP authorization spec).
	 *
	 * @param WP_HTTP_Response $response The response object.
	 * @param array            $handler  Route handler (unused).
	 * @param WP_REST_Request  $request  The request object.
	 */
	public function add_auth_challenge_header( $response, $handler, $request ) {
		if ( ! ( $response instanceof WP_REST_Response ) && ! ( $response instanceof WP_HTTP_Response ) ) {
			return $response;
		}

		if ( 401 !== (int) $response->get_status() ) {
			return $response;
		}

		$route = $request instanceof WP_REST_Request ? (string) $request->get_route() : '';
		$is_mcp_route = ( false !== strpos( $route, '/wpmcp' ) ) || ( false !== strpos( $route, '/mcp/' ) ) || ( '/mcp' === $route );
		if ( ! $is_mcp_route ) {
			return $response;
		}

		$metadata_url = home_url( '/.well-known/oauth-protected-resource' );
		$response->header( 'WWW-Authenticate', sprintf( 'Bearer resource_metadata="%s"', $metadata_url ) );

		return $response;
	}
}
