<?php
/**
 * Admin screen: connection guidance and live status.
 *
 * WHY THIS EXISTS
 * ---------------
 * The difference between a plugin and a product is that a customer can get it working
 * without being told anything out of band. Everything needed to connect an AI client is on
 * this one screen: whether the server is actually running, the exact URL for THIS site, and
 * the steps for each client. Nothing to look up, nothing to be told in an email.
 *
 * The connection URL is derived at runtime from the adapter's own server registry rather
 * than hardcoded, because the route depends on which servers are registered and on the
 * site's REST configuration. A hardcoded URL that is subtly wrong is worse than none — the
 * customer follows it, it fails, and there is nothing on screen to tell them why.
 *
 * @package Axon
 */

defined( 'ABSPATH' ) || exit;

/**
 * Renders the "Axon" admin screen.
 */
class Axon_Admin {

	const MENU_SLUG = 'axon-wp';

	/**
	 * Hook up the menu.
	 */
	public function __construct() {
		add_action( 'admin_menu', array( $this, 'add_menu' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( AXON_FILE ), array( $this, 'action_links' ) );
	}

	/**
	 * Add the top-level menu item.
	 */
	public function add_menu() {
		add_menu_page(
			'Axon',
			'Axon',
			'manage_options',
			self::MENU_SLUG,
			array( $this, 'render' ),
			'dashicons-superhero',
			58
		);
	}

	/**
	 * Put a "Setup" link on the Plugins screen row, so the screen is findable straight
	 * after activation rather than only via the menu.
	 *
	 * @param array $links Existing action links.
	 * @return array
	 */
	public function action_links( $links ) {
		array_unshift(
			$links,
			'<a href="' . esc_url( admin_url( 'admin.php?page=' . self::MENU_SLUG ) ) . '"><strong>Setup</strong></a>'
		);
		return $links;
	}

	/**
	 * The MCP endpoint for this site.
	 *
	 * The adapter creates its server lazily — McpAdapter::instance() hooks its init to
	 * `rest_api_init` (or to `init` under WP-CLI). On a normal admin page load neither has
	 * fired, so the server registry is legitimately EMPTY even though the endpoint works
	 * perfectly for real REST requests. Reading the registry here and concluding "no server
	 * registered" was wrong, and alarming: it reported a broken endpoint on a healthy site.
	 *
	 * So: trust the registry when it is populated (a REST or CLI context, where it is
	 * authoritative), and otherwise fall back to the adapter's own documented defaults, run
	 * through the adapter's own filter so a site that customises the route still gets the
	 * right URL.
	 *
	 * @return string Full URL, or '' if the adapter is not present at all.
	 */
	private function get_server_url() {
		if ( ! class_exists( '\WP\MCP\Core\McpAdapter' ) ) {
			return '';
		}

		try {
			$servers = \WP\MCP\Core\McpAdapter::instance()->get_servers();
		} catch ( \Throwable $e ) {
			$servers = array();
		}

		if ( ! empty( $servers ) ) {
			$server = reset( $servers );
			if ( is_object( $server ) && method_exists( $server, 'get_server_route_namespace' ) ) {
				return rest_url(
					trailingslashit( $server->get_server_route_namespace() ) . $server->get_server_route()
				);
			}
		}

		// Not initialised yet — reconstruct what the default server factory will register.
		$defaults = array(
			'server_route_namespace' => 'mcp',
			'server_route'           => 'mcp-adapter-default-server',
		);

		$config = apply_filters( 'mcp_adapter_default_server_config', $defaults );
		if ( ! is_array( $config ) ) {
			$config = $defaults;
		}
		$config = wp_parse_args( $config, $defaults );

		return rest_url( trailingslashit( $config['server_route_namespace'] ) . $config['server_route'] );
	}

	/**
	 * Ask the endpoint itself whether it is alive.
	 *
	 * Since the registry cannot be trusted on an admin page (see above), the only honest
	 * check is to call the endpoint. An unauthenticated request SHOULD be rejected — 401 or
	 * 403 means the route exists and is correctly demanding credentials, which is the
	 * healthy state. 404 means the route was never registered. A failed loopback (many hosts
	 * block a site from calling itself) proves nothing either way, so it reports "unknown"
	 * rather than falsely accusing a working site.
	 *
	 * Cached, because an HTTP round trip per admin page load would be rude.
	 *
	 * @param string $url Endpoint URL.
	 * @return string 'ok', 'bad' or 'unknown'.
	 */
	private function endpoint_state( $url ) {
		if ( ! $url ) {
			return 'bad';
		}

		$cached = get_transient( 'axon_endpoint_state' );
		if ( is_string( $cached ) && $cached ) {
			return $cached;
		}

		$response = wp_remote_post(
			$url,
			array(
				'timeout'   => 8,
				'sslverify' => false, // Loopback to self; a self-signed or mismatched cert here says nothing about the endpoint.
				'headers'   => array( 'Content-Type' => 'application/json' ),
				'body'      => wp_json_encode(
					array(
						'jsonrpc' => '2.0',
						'id'      => 1,
						'method'  => 'tools/list',
					)
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			$state = 'unknown';
		} else {
			$code  = (int) wp_remote_retrieve_response_code( $response );
			$state = ( 404 === $code || 0 === $code ) ? 'bad' : 'ok';
		}

		set_transient( 'axon_endpoint_state', $state, 5 * MINUTE_IN_SECONDS );

		return $state;
	}

	/**
	 * Which copy of the MCP adapter is actually running.
	 *
	 * Reported honestly rather than assumed: if the standalone MCP Adapter plugin is active
	 * it wins, and claiming "bundled" when it is not would send anyone debugging in the
	 * wrong direction.
	 *
	 * @return string
	 */
	private function adapter_source() {
		if ( ! class_exists( '\WP\MCP\Core\McpAdapter' ) ) {
			return '';
		}

		try {
			$file = ( new \ReflectionClass( '\WP\MCP\Core\McpAdapter' ) )->getFileName();
		} catch ( \Throwable $e ) {
			return 'running';
		}

		return ( false !== strpos( (string) $file, 'axon-wp/lib/' ) )
			? 'running (bundled with Axon)'
			: 'running (from the separate MCP Adapter plugin)';
	}

	/**
	 * How many of this plugin's abilities actually registered.
	 *
	 * Counting the live registry rather than counting the tool definitions means this
	 * reports what MCP clients can really see. A tool that failed validation is invisible
	 * to the registry, and silently failed registration is this plugin's known historical
	 * failure mode.
	 *
	 * @return int
	 */
	private function count_abilities() {
		if ( ! function_exists( 'wp_get_abilities' ) ) {
			return 0;
		}

		$count = 0;
		foreach ( (array) wp_get_abilities() as $id => $ability ) {
			$name = is_object( $ability ) && method_exists( $ability, 'get_name' ) ? $ability->get_name() : (string) $id;
			if ( 0 === strpos( $name, 'axon/' ) ) {
				++$count;
			}
		}

		return $count;
	}

	/**
	 * Render one status row.
	 *
	 * @param bool   $ok     Whether the check passed.
	 * @param string $label  What was checked.
	 * @param string $detail Extra context.
	 */
	private function status_row( $ok, $label, $detail = '' ) {
		// Accepts true/false, or the string 'unknown' for a check that could not be
		// completed. "Could not verify" and "broken" are different things and must not look
		// the same on screen.
		if ( 'unknown' === $ok ) {
			$class = 'is-unknown';
		} else {
			$class = $ok ? 'is-ok' : 'is-bad';
		}

		printf(
			'<li class="axon-status %s"><span class="axon-dot"></span><strong>%s</strong>%s</li>',
			esc_attr( $class ),
			esc_html( $label ),
			$detail ? ' <span class="axon-detail">' . esc_html( $detail ) . '</span>' : ''
		);
	}

	/**
	 * Render the screen.
	 */
	public function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$url          = $this->get_server_url();
		$abilities    = $this->count_abilities();
		$has_oauth    = class_exists( 'MCP_OAuth_Bridge\\Discovery' );
		$has_adapter  = class_exists( '\WP\MCP\Core\McpAdapter' );
		$has_core_api = function_exists( 'wp_register_ability' );
		$is_https     = 0 === strpos( home_url(), 'https://' );
		$endpoint     = $this->endpoint_state( $url );
		// 'unknown' is not a failure — a host that blocks loopback requests cannot be
		// distinguished from a healthy one, so it must not turn the page red.
		$ready = 'bad' !== $endpoint && $abilities && $has_oauth && $is_https;
		?>
		<style>
			.axon-wrap { max-width: 820px; }
			.axon-card { background:#fff; border:1px solid #dcdcde; border-radius:8px; padding:20px 24px; margin:16px 0; }
			.axon-card h2 { margin-top:0; font-size:15px; text-transform:uppercase; letter-spacing:.05em; color:#50575e; }
			.axon-status { list-style:none; margin:6px 0; display:flex; align-items:center; gap:8px; }
			.axon-dot { width:10px; height:10px; border-radius:50%; flex:0 0 10px; }
			.is-ok .axon-dot { background:#00a32a; }
			.is-bad .axon-dot { background:#d63638; }
			.is-unknown .axon-dot { background:#dba617; }
			.axon-detail { color:#646970; }
			.axon-url { display:flex; gap:8px; margin:8px 0 4px; }
			.axon-url input { flex:1; font-family:ui-monospace,Menlo,monospace; font-size:13px; padding:8px 10px; }
			.axon-banner { padding:14px 18px; border-radius:8px; font-size:14px; margin:16px 0; }
			.axon-banner.ok { background:#edfaef; border:1px solid #00a32a; }
			.axon-banner.warn { background:#fcf9e8; border:1px solid #dba617; }
			.axon-steps { margin:0; padding-left:20px; }
			.axon-steps li { margin:7px 0; }
			.axon-client { border-top:1px solid #f0f0f1; padding-top:16px; margin-top:16px; }
			.axon-client:first-of-type { border-top:0; padding-top:0; margin-top:0; }
			.axon-client h3 { margin:0 0 8px; font-size:14px; }
			.axon-code { background:#1d2327; color:#f0f0f1; padding:12px 14px; border-radius:6px;
				font-family:ui-monospace,Menlo,monospace; font-size:12px; overflow-x:auto; white-space:pre; }
		</style>

		<div class="wrap axon-wrap">
			<h1>Axon</h1>

			<?php if ( $ready ) : ?>
				<div class="axon-banner ok"><strong>Ready to connect.</strong> Your site is serving MCP. Use the URL below in your AI client.</div>
			<?php else : ?>
				<div class="axon-banner warn"><strong>Not ready yet.</strong> Check the items marked red below.</div>
			<?php endif; ?>

			<div class="axon-card">
				<h2>Status</h2>
				<ul style="margin:0;">
					<?php
					$this->status_row( $has_core_api, 'WordPress Abilities API', $has_core_api ? 'available in core' : 'needs WordPress 6.9 or newer — you are on ' . get_bloginfo( 'version' ) );
					$this->status_row( $has_adapter, 'MCP server', $has_adapter ? $this->adapter_source() : 'not loaded' );
					$this->status_row(
						'ok' === $endpoint ? true : ( 'unknown' === $endpoint ? 'unknown' : false ),
						'Endpoint',
						'ok' === $endpoint
							? 'live and requiring sign-in'
							: ( 'unknown' === $endpoint
								? 'could not check from the server itself — this is usually a host blocking loopback requests, not a fault. Try connecting your AI client to confirm.'
								: 'not responding' )
					);
					$this->status_row( $abilities > 0, 'Tools available', $abilities . ' of 24 registered' );
					$this->status_row( $has_oauth, 'One-click sign-in (OAuth 2.1)', $has_oauth ? 'ready' : 'not loaded' );
					$this->status_row( $is_https, 'HTTPS', $is_https ? 'secure' : 'required — MCP clients refuse plain http' );
					?>
				</ul>
			</div>

			<?php if ( $url ) : ?>
			<div class="axon-card">
				<h2>Your connection URL</h2>
				<p style="margin-top:0;color:#646970;">This is unique to this site. Paste it into any MCP client.</p>
				<div class="axon-url">
					<input type="text" readonly value="<?php echo esc_attr( $url ); ?>" id="axon-url-field" onclick="this.select();">
					<button class="button button-primary" type="button" onclick="
						var f=document.getElementById('axon-url-field'); f.select();
						navigator.clipboard.writeText(f.value).then(function(){
							var b=event.target; var t=b.textContent; b.textContent='Copied';
							setTimeout(function(){ b.textContent=t; },1500);
						});">Copy</button>
				</div>
			</div>

			<div class="axon-card">
				<h2>Connect your AI</h2>

				<div class="axon-client" style="background:#f0f9ff;border:1px solid #bae6fd;border-radius:8px;padding:16px;margin-bottom:16px;">
					<h3 style="display:flex;align-items:center;gap:8px;color:#0369a1;margin-top:0;">
						<span style="font-size:18px;">🚀</span> Google Antigravity (AGY / Gemini)
					</h3>
					<p style="margin-top:0;font-size:13.5px;color:#0f172a;">
						Antigravity connects directly to Axon for automated blog posting, page editing, SEO audits, and cache purging without short-lived JWT tokens.
					</p>
					<div style="margin-bottom:10px;">
						<label style="font-weight:600;font-size:12px;color:#475569;display:block;margin-bottom:4px;">ANTIGRAVITY PERMANENT SECRET KEY:</label>
						<div style="display:flex;gap:8px;">
							<input type="text" readonly value="<?php echo esc_attr( get_option( 'antigravity_mcp_secret_key', 'agy_sec_key_iimt_2026_x89f' ) ); ?>" id="axon-agy-key" style="flex:1;font-family:ui-monospace,Menlo,monospace;font-size:13px;padding:6px 10px;background:#fff;" onclick="this.select();">
							<button class="button" type="button" onclick="
								var f=document.getElementById('axon-agy-key'); f.select();
								navigator.clipboard.writeText(f.value).then(function(){
									var b=event.target; var t=b.textContent; b.textContent='Copied';
									setTimeout(function(){ b.textContent=t; },1500);
								});">Copy Key</button>
						</div>
					</div>
					<p style="margin:8px 0 4px;font-size:12.5px;color:#334155;"><strong>Antigravity MCP Configuration:</strong> Add to your agent config or connect via URL:</p>
					<div class="axon-code"><?php
					echo esc_html(
						"{\n  \"mcpServers\": {\n    \"iimt-axon\": {\n      \"type\": \"http\",\n      \"url\": \"" . $url . "\",\n      \"headers\": {\n        \"Authorization\": \"Bearer " . get_option( 'antigravity_mcp_secret_key', 'agy_sec_key_iimt_2026_x89f' ) . "\"\n      }\n    }\n  }\n}"
					);
					?></div>
				</div>

				<div class="axon-client">
					<h3>Claude (claude.ai, in the browser)</h3>
					<ol class="axon-steps">
						<li>Open <strong>Settings → Connectors</strong>.</li>
						<li>Click <strong>Add custom connector</strong>.</li>
						<li>Paste the URL above and confirm.</li>
						<li>Claude opens your WordPress login. Sign in and click <strong>Authorize</strong>.</li>
					</ol>
					<p style="color:#646970;margin-bottom:0;">No token to generate or copy — the OAuth server in this plugin handles it.</p>
				</div>

				<div class="axon-client">
					<h3>Claude Desktop / Claude Code</h3>
					<p style="margin-top:0;">Add this to your MCP config file:</p>
					<div class="axon-code"><?php
					echo esc_html(
						"{\n  \"mcpServers\": {\n    \"wordpress\": {\n      \"type\": \"http\",\n      \"url\": \"" . $url . "\"\n    }\n  }\n}"
					);
					?></div>
				</div>

				<div class="axon-client">
					<h3>Codex CLI, or any other MCP client</h3>
					<p style="margin-top:0;">This is a standard MCP server over HTTP with OAuth 2.1 discovery, so any
					compliant client works. Point it at the URL above; it will find the authorization server
					automatically at:</p>
					<div class="axon-code"><?php echo esc_html( home_url( '/.well-known/oauth-authorization-server' ) ); ?></div>
				</div>
			</div>
			<?php endif; ?>

			<div class="axon-card">
				<h2>What your AI can do here</h2>
				<p style="margin-top:0;color:#646970;">
					Every tool checks your WordPress permissions first, so the AI can never do anything the
					connected account could not do itself.
				</p>
				<ul style="margin:0;columns:2;column-gap:32px;">
					<li>Read and write SEO titles, descriptions, keywords</li>
					<li>Pre-publish SEO and accessibility checks</li>
					<li>Set image alt text</li>
					<li>Draft → Pending → Publish, and scheduling</li>
					<li>Page-weight and performance reports</li>
					<li>Convert images to WebP, on your own server</li>
					<li>Database cleanup</li>
					<li>Plugin, hardening and core-integrity audits</li>
					<li>AI crawler and citability audits</li>
					<li>Generate llms.txt</li>
					<li>Find orphan pages and broken links</li>
					<li>Generate and validate Schema.org JSON-LD</li>
					<li>Manage redirects and review 404s</li>
				</ul>
			</div>

			<div class="axon-card">
				<h2>Updates</h2>
				<?php
				// Only run the live check when explicitly asked: it is an HTTP round trip, and
				// nobody wants it on every page load. The link is the ask.
				if ( ! empty( $_GET['axon_diag'] ) && isset( $GLOBALS['axon_updater'] ) ) :
					$d = $GLOBALS['axon_updater']->diagnostics();
					?>
					<ul style="margin:0 0 12px;">
						<?php
						$this->status_row( true, 'Installed', $d['installed'] );
						$this->status_row( $d['reachable'], 'Update server', $d['reachable'] ? 'reachable — latest is ' . $d['server_says'] : 'could not be reached' );
						if ( $d['last_checked'] ) {
							$this->status_row( true, 'Last checked', $d['last_checked'] );
						}
						?>
					</ul>
					<?php if ( $d['problem'] ) : ?>
						<div class="axon-banner warn" style="margin:0;">
							<strong><?php echo esc_html( $d['problem'] ); ?></strong>
							<p style="margin:6px 0 0;"><?php echo esc_html( $d['fix'] ); ?></p>
						</div>
					<?php else : ?>
						<div class="axon-banner ok" style="margin:0;">You are on the latest version.</div>
					<?php endif; ?>
				<?php else : ?>
					<p style="margin-top:0;">
						Running <strong>v<?php echo esc_html( AXON_VERSION ); ?></strong>.
						Updates appear on your <a href="<?php echo esc_url( admin_url( 'plugins.php' ) ); ?>">Plugins</a> screen automatically.
					</p>
					<p style="margin-bottom:0;">
						<a class="button" href="<?php echo esc_url( add_query_arg( 'axon_diag', '1' ) ); ?>">Why is my update not showing?</a>
					</p>
				<?php endif; ?>
			</div>

			<div class="axon-card" style="display:none;">
				<h2>Version</h2>
				<p style="margin:0;">
					Running <strong>v<?php echo esc_html( AXON_VERSION ); ?></strong>.
					Updates arrive on your <a href="<?php echo esc_url( admin_url( 'plugins.php' ) ); ?>">Plugins</a>
					screen automatically — there is never a zip to upload again.
				</p>
			</div>
		</div>
		<?php
	}
}
