<?php
/**
 * Coded page design — build pages by writing HTML and CSS, with no page builder.
 *
 * WHY THIS EXISTS
 * ---------------
 * Page builders are a GUI abstraction invented so humans could lay out pages without writing
 * code. An AI has the opposite problem: it writes HTML and CSS fluently, and to use Elementor
 * it must instead emit deeply nested widget JSON it cannot see the result of, where one
 * malformed node renders the page blank.
 *
 * So this skips the builder entirely. The AI writes the markup and styles directly, which is
 * the thing it is actually good at, and the page renders exactly as written.
 *
 * HOW A PAGE IS STORED
 * --------------------
 * - HTML lives in `post_content`, so it stays searchable, revisionable and editable in
 *   wp-admin like any other page.
 * - CSS lives in postmeta and is printed only on that page, so one page's styles can never
 *   leak into the rest of the site.
 * - A mode flag decides whether the theme's header and footer wrap the page.
 *
 * Nothing here is a proprietary format. Turn the plugin off and the HTML is still in the post.
 *
 * ON REPRODUCING ANOTHER SITE
 * ---------------------------
 * `analyze_design` reads a reference URL and reports its STRUCTURE — section rhythm, heading
 * hierarchy, colour palette, typography, layout patterns. It deliberately does not copy text,
 * images or markup. Layout conventions are ideas and free to learn from; a specific site's
 * copy, photography and markup are that owner's property. Use the analysis to inform an
 * original build, not to republish someone else's page.
 *
 * @package Axon
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Build and edit pages as code.
 */
class Axon_Design_Tools {

	/** Per-page CSS. */
	const CSS_META = '_axon_page_css';

	/** Render mode: 'full' (no theme chrome) or 'themed' (inside the theme). */
	const MODE_META = '_axon_canvas_mode';

	/** Optional per-page JS. */
	const JS_META = '_axon_page_js';

	/**
	 * @return array<int, array<string, mixed>>
	 */
	public static function tools() {
		return array(
			array(
				'name'        => 'design_page',
				'description' => 'Build or redesign a page by writing HTML and CSS directly, with no page builder involved. Creates the page if page_id is omitted. The CSS is printed only on this page so it cannot affect the rest of the site. Use mode "full" for landing pages that should fill the screen with no theme header or footer, and "themed" to sit inside the site\'s normal header and footer.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'page_id' => array( 'type' => 'integer', 'description' => 'Existing page to redesign. Omit to create a new page.' ),
						'title'   => array( 'type' => 'string', 'description' => 'Page title. Required when creating.' ),
						'slug'    => array( 'type' => 'string', 'description' => 'URL slug. Derived from the title when omitted.' ),
						'html'    => array( 'type' => 'string', 'description' => 'The page body markup. Write semantic HTML — section, h2, p, figure. Do NOT include <html>, <head>, <body> or an <h1> of the page title; the template supplies those. Do not inline a <style> block, pass CSS separately.' ),
						'css'     => array( 'type' => 'string', 'description' => 'CSS for this page. Written out only on this page. Include your own responsive media queries — nothing is added for you.' ),
						'js'      => array( 'type' => 'string', 'description' => 'Optional JavaScript for this page, without <script> tags. Requires the unfiltered_html capability.' ),
						'mode'    => array( 'type' => 'string', 'description' => '"full" for a standalone canvas with no theme header/footer, or "themed" to render inside the theme. Default "themed".' ),
						'status'  => array( 'type' => 'string', 'description' => 'draft, publish or private. Default "draft" so nothing goes live before you look at it.' ),
					),
					'required'   => array(),
				),
				'callback'    => array( __CLASS__, 'design_page' ),
			),
			array(
				'name'        => 'get_design',
				'description' => 'Read back the HTML, CSS and render mode of a page built with design_page, so an edit can be made against what is actually there rather than from memory.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'page_id' => array( 'type' => 'integer', 'description' => 'The page to read.' ),
					),
					'required'   => array( 'page_id' ),
				),
				'callback'    => array( __CLASS__, 'get_design' ),
			),
			array(
				'name'        => 'analyze_design',
				'description' => 'Study a reference URL and report how it is built: section structure, heading hierarchy, colour palette, typography, layout patterns and page weight. Returns structure and style facts to inform an original design. It does not copy text, images or markup — use it to learn the layout, then write your own.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'url' => array( 'type' => 'string', 'description' => 'Public URL of the page to study.' ),
					),
					'required'   => array( 'url' ),
				),
				'callback'    => array( __CLASS__, 'analyze_design' ),
			),
		);
	}

	/* ===================================================================== */
	/* Build                                                                  */
	/* ===================================================================== */

	/**
	 * @param array $args
	 * @return array|WP_Error
	 */
	public static function design_page( $args ) {
		$page_id = (int) ( $args['page_id'] ?? 0 );

		if ( $page_id ) {
			if ( ! current_user_can( 'edit_post', $page_id ) ) {
				return new WP_Error( 'forbidden', sprintf( 'You cannot edit page %d.', $page_id ) );
			}
			if ( ! get_post( $page_id ) ) {
				return new WP_Error( 'not_found', sprintf( 'No page with ID %d.', $page_id ) );
			}
		} elseif ( ! current_user_can( 'publish_pages' ) && ! current_user_can( 'edit_pages' ) ) {
			return new WP_Error( 'forbidden', 'You cannot create pages on this site.' );
		}

		// Design markup needs style attributes, data attributes, SVG and often inline script.
		// WordPress strips all of that from users without unfiltered_html, which would leave a
		// silently mangled page. Refuse clearly instead of half-building something.
		if ( ! current_user_can( 'unfiltered_html' ) ) {
			return new WP_Error(
				'needs_unfiltered_html',
				'Designing a page requires the unfiltered_html capability, because WordPress strips style attributes, SVG and scripts from users without it — the page would be saved visibly broken. Connect with an administrator account on a single site install.'
			);
		}

		// Resolve first, then validate. Testing `$args['mode'] ?? 'themed'` inside the
		// condition and then reading `$args['mode']` in the result is a warning waiting to
		// happen the moment the key is absent — which is the common case.
		$mode = (string) ( $args['mode'] ?? 'themed' );
		if ( ! in_array( $mode, array( 'full', 'themed' ), true ) ) {
			$mode = 'themed';
		}

		$html = (string) ( $args['html'] ?? '' );

		// A common and confusing mistake: wrapping the body in a full document, or adding an
		// h1 the template already renders. Both produce invalid output that is hard to
		// diagnose from the tool's side, so catch them here where the message can be useful.
		if ( preg_match( '/<(?:html|head|body)\b/i', $html ) ) {
			return new WP_Error( 'full_document', 'Pass only the page body markup. The template supplies <html>, <head> and <body> — including them nests one document inside another.' );
		}
		if ( preg_match( '/<h1\b/i', $html ) ) {
			return new WP_Error( 'duplicate_h1', 'Remove the <h1>. The template renders the page title as the h1; a second one is a duplicate-H1 SEO defect. Start sections at <h2>.' );
		}
		if ( preg_match( '/<style\b/i', $html ) ) {
			return new WP_Error( 'inline_style_block', 'Do not put a <style> block in the html. Pass the CSS in the css parameter so it can be managed and replaced independently.' );
		}

		$postarr = array(
			'post_type'    => 'page',
			'post_title'   => wp_strip_all_tags( (string) ( $args['title'] ?? '' ) ),
			'post_content' => $html,
			'post_status'  => sanitize_key( $args['status'] ?? 'draft' ),
		);

		if ( ! empty( $args['slug'] ) ) {
			$postarr['post_name'] = sanitize_title( (string) $args['slug'] );
		}

		if ( $page_id ) {
			$postarr['ID'] = $page_id;
			unset( $postarr['post_type'] );
			if ( empty( $args['title'] ) ) {
				unset( $postarr['post_title'] );
			}
			if ( ! array_key_exists( 'html', $args ) ) {
				unset( $postarr['post_content'] );
			}
			if ( empty( $args['status'] ) ) {
				unset( $postarr['post_status'] );
			}
			$result = wp_update_post( $postarr, true );
		} else {
			if ( '' === trim( $postarr['post_title'] ) ) {
				return new WP_Error( 'missing_title', 'A title is required when creating a page.' );
			}
			$result = wp_insert_post( $postarr, true );
		}

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$id = (int) $result;

		update_post_meta( $id, self::MODE_META, $mode );

		if ( array_key_exists( 'css', $args ) ) {
			update_post_meta( $id, self::CSS_META, wp_slash( (string) $args['css'] ) );
		}
		if ( array_key_exists( 'js', $args ) ) {
			update_post_meta( $id, self::JS_META, wp_slash( (string) $args['js'] ) );
		}

		$post = get_post( $id );

		return array(
			'action'    => $page_id ? 'redesigned' : 'created',
			'page_id'   => $id,
			'title'     => axon_text( get_the_title( $id ) ),
			'url'       => get_permalink( $id ),
			'edit_url'  => get_edit_post_link( $id, 'raw' ),
			'mode'      => $mode,
			'status'    => $post ? $post->post_status : '',
			'html_bytes'=> strlen( $html ),
			'css_bytes' => strlen( (string) ( $args['css'] ?? get_post_meta( $id, self::CSS_META, true ) ) ),
			'next_step' => ( $post && 'draft' === $post->post_status )
				? 'Saved as a draft. Open the URL to review it, then publish with update_post status=publish.'
				: 'Live. Check it on a phone as well as a desktop before moving on.',
		);
	}

	/**
	 * @param array $args
	 * @return array|WP_Error
	 */
	public static function get_design( $args ) {
		$id = (int) ( $args['page_id'] ?? 0 );

		if ( ! $id || ! get_post( $id ) ) {
			return new WP_Error( 'not_found', sprintf( 'No page with ID %d.', $id ) );
		}
		if ( ! current_user_can( 'edit_post', $id ) ) {
			return new WP_Error( 'forbidden', sprintf( 'You cannot read page %d.', $id ) );
		}

		$post = get_post( $id );
		$mode = (string) get_post_meta( $id, self::MODE_META, true );

		return array(
			'page_id'    => $id,
			'title'      => axon_text( get_the_title( $id ) ),
			'url'        => get_permalink( $id ),
			'status'     => $post->post_status,
			'mode'       => $mode ? $mode : 'not an Axon-designed page',
			'html'       => $post->post_content,
			'css'        => (string) get_post_meta( $id, self::CSS_META, true ),
			'js'         => (string) get_post_meta( $id, self::JS_META, true ),
			'is_builder' => get_post_meta( $id, '_elementor_edit_mode', true ) ? 'Elementor is also active on this page and will take precedence over this markup.' : '',
		);
	}

	/* ===================================================================== */
	/* Reference analysis                                                     */
	/* ===================================================================== */

	/**
	 * @param array $args
	 * @return array|WP_Error
	 */
	public static function analyze_design( $args ) {
		if ( ! current_user_can( 'edit_pages' ) ) {
			return new WP_Error( 'forbidden', 'You need the edit_pages capability.' );
		}

		$url = esc_url_raw( (string) ( $args['url'] ?? '' ) );
		if ( ! $url ) {
			return new WP_Error( 'bad_url', 'Pass a valid public URL.' );
		}

		$res = wp_remote_get(
			$url,
			array(
				'timeout'    => 20,
				'user-agent' => 'Axon/' . AXON_VERSION . ' (design analysis)',
			)
		);

		if ( is_wp_error( $res ) ) {
			return new WP_Error( 'fetch_failed', 'Could not fetch that page: ' . $res->get_error_message() );
		}

		$code = (int) wp_remote_retrieve_response_code( $res );
		if ( 200 !== $code ) {
			return new WP_Error( 'bad_response', sprintf( 'That URL returned HTTP %d.', $code ) );
		}

		$html = (string) wp_remote_retrieve_body( $res );

		return array(
			'url'        => $url,
			'page_bytes' => strlen( $html ),
			'structure'  => self::outline( $html ),
			'sections'   => self::count_tag( $html, 'section' ) + self::count_tag( $html, 'article' ),
			'palette'    => self::palette( $html ),
			'typography' => self::fonts( $html ),
			'layout'     => self::layout_hints( $html ),
			'images'     => self::count_tag( $html, 'img' ),
			'note'       => 'Structure and style facts only — no text, images or markup have been copied. Use these as a brief for an original build. Reproducing the reference\'s wording, photography or markup would be copying that site\'s content, which is its owner\'s property.',
		);
	}

	/**
	 * Heading outline — the fastest read on how a page is organised.
	 *
	 * @param string $html
	 * @return array<int, string>
	 */
	private static function outline( $html ) {
		if ( ! preg_match_all( '/<(h[1-3])[^>]*>(.*?)<\/\1>/is', $html, $m, PREG_SET_ORDER ) ) {
			return array();
		}

		$out = array();
		foreach ( array_slice( $m, 0, 40 ) as $hit ) {
			$text = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $hit[2] ) ) );
			if ( '' === $text ) {
				continue;
			}
			// Report the SHAPE of each heading, not its wording — length and level are what
			// inform a layout; the words belong to the other site.
			$out[] = strtoupper( $hit[1] ) . ' (' . str_word_count( $text ) . ' words)';
		}

		return $out;
	}

	/**
	 * Colours actually used, most frequent first.
	 *
	 * @param string $html
	 * @return array<int, string>
	 */
	private static function palette( $html ) {
		preg_match_all( '/#([0-9a-f]{6}|[0-9a-f]{3})\b/i', $html, $hex );
		preg_match_all( '/rgba?\([^)]+\)/i', $html, $rgb );

		$all = array_merge( (array) $hex[0], (array) $rgb[0] );
		if ( ! $all ) {
			return array();
		}

		$counts = array_count_values( array_map( 'strtolower', $all ) );
		arsort( $counts );

		$out = array();
		foreach ( array_slice( $counts, 0, 12, true ) as $colour => $n ) {
			$out[] = $colour . ' (used ' . $n . 'x)';
		}

		return $out;
	}

	/**
	 * @param string $html
	 * @return array<int, string>
	 */
	private static function fonts( $html ) {
		$fonts = array();

		if ( preg_match_all( '#fonts\.googleapis\.com/css2?\?family=([^"\'&]+)#i', $html, $m ) ) {
			foreach ( $m[1] as $fam ) {
				$fonts[] = str_replace( '+', ' ', explode( ':', $fam )[0] );
			}
		}
		if ( preg_match_all( '/font-family\s*:\s*([^;}"\']+)/i', $html, $m2 ) ) {
			foreach ( array_slice( $m2[1], 0, 8 ) as $fam ) {
				$fonts[] = trim( $fam );
			}
		}

		return array_values( array_unique( array_filter( $fonts ) ) );
	}

	/**
	 * @param string $html
	 * @return array<string, mixed>
	 */
	private static function layout_hints( $html ) {
		return array(
			'uses_css_grid'   => (bool) preg_match( '/display\s*:\s*grid/i', $html ),
			'uses_flexbox'    => (bool) preg_match( '/display\s*:\s*flex/i', $html ),
			'media_queries'   => preg_match_all( '/@media[^{]+\{/i', $html ),
			'css_variables'   => preg_match_all( '/--[a-z0-9-]+\s*:/i', $html ),
			'sticky_elements' => (bool) preg_match( '/position\s*:\s*sticky/i', $html ),
			'has_svg'         => (bool) preg_match( '/<svg\b/i', $html ),
		);
	}

	/**
	 * @param string $html
	 * @param string $tag
	 * @return int
	 */
	private static function count_tag( $html, $tag ) {
		return (int) preg_match_all( '/<' . preg_quote( $tag, '/' ) . '\b/i', $html );
	}

	/* ===================================================================== */
	/* Rendering                                                              */
	/* ===================================================================== */

	/**
	 * Print this page's CSS and JS, on this page only.
	 *
	 * Hooked from the main plugin file.
	 */
	public static function print_assets() {
		if ( ! is_singular() ) {
			return;
		}

		$id = get_queried_object_id();
		if ( ! $id ) {
			return;
		}

		$css = (string) get_post_meta( $id, self::CSS_META, true );
		if ( '' !== trim( $css ) ) {
			// wp_strip_all_tags prevents a stored "</style><script>" from breaking out of the
			// block; the CSS itself is authored by an editor-level user and is not escaped
			// further, because escaping valid CSS would destroy it.
			echo "\n<style id=\"axon-page-css\">\n" . wp_strip_all_tags( $css ) . "\n</style>\n"; // phpcs:ignore WordPress.Security.EscapeOutput
		}
	}

	/**
	 * @see print_assets()
	 */
	public static function print_js() {
		if ( ! is_singular() ) {
			return;
		}

		$id = get_queried_object_id();
		if ( ! $id ) {
			return;
		}

		$js = (string) get_post_meta( $id, self::JS_META, true );
		if ( '' !== trim( $js ) ) {
			echo "\n<script id=\"axon-page-js\">\n" . $js . "\n</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput
		}
	}

	/**
	 * Swap in the blank canvas template for pages built in "full" mode.
	 *
	 * @param string $template
	 * @return string
	 */
	public static function maybe_canvas_template( $template ) {
		if ( ! is_page() ) {
			return $template;
		}

		$id = get_queried_object_id();
		if ( ! $id || 'full' !== get_post_meta( $id, self::MODE_META, true ) ) {
			return $template;
		}

		$canvas = AXON_DIR . 'templates/template-axon-canvas.php';

		return file_exists( $canvas ) ? $canvas : $template;
	}
}
