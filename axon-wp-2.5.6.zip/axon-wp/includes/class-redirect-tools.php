<?php
/**
 * Redirects and 404 recovery.
 *
 * A 404 is a visitor who wanted something and got nothing — and for a site that has been
 * rebuilt or re-slugged, those are usually the pages with the most inbound links. Fixing
 * them recovers real traffic and link equity that is already paid for.
 *
 * Design notes:
 *  - Redirect rules live in a single non-autoloaded option, read only when a request is
 *    about to 404. A normal page load never touches them.
 *  - 404s are aggregated by path with a hit counter rather than logged per request, so
 *    the table cannot grow without bound under bot traffic.
 *  - Nothing redirects automatically. Suggestions are surfaced for a human to approve;
 *    a wrong automatic redirect is invisible and permanent in the eyes of a search engine.
 *
 * Tools:
 *   manage_redirects   - list / add / update / delete rules
 *   audit_404s         - most-hit missing URLs, with suggested destinations
 *   find_broken_links  - internal links pointing at pages that do not exist
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Axon_Redirect_Tools {

	const OPTION     = 'axon_redirects';
	const DB_VERSION = 'axon_404_db_version';
	const VERSION    = '1';

	/** Stop the log table growing forever on a heavily-scanned site. */
	const MAX_LOGGED = 5000;

	/**
	 * @return string
	 */
	private static function table() {
		global $wpdb;
		return $wpdb->prefix . 'axon_404_log';
	}

	/**
	 * @return array<int, array<string, mixed>>
	 */
	public static function tools() {
		return array(
			array(
				'name'        => 'manage_redirects',
				'description' => 'List, add, update or delete redirect rules. Supports exact-path and regex matching with 301/302/307/410 responses. Redirects are checked only when a request would otherwise 404, so they cost a normal page load nothing.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'action' => array(
							'type'        => 'string',
							'description' => 'One of: list, add, update, delete. Default list.',
						),
						'from'   => array(
							'type'        => 'string',
							'description' => 'Source path, e.g. "/old-page/". Required for add/update/delete. Treated as a regex when is_regex is true.',
						),
						'to'     => array(
							'type'        => 'string',
							'description' => 'Destination path or absolute URL. Required for add/update unless the code is 410.',
						),
						'code'   => array(
							'type'        => 'integer',
							'description' => '301 permanent (default), 302 or 307 temporary, or 410 gone (content intentionally removed).',
						),
						'is_regex' => array(
							'type'        => 'boolean',
							'description' => 'Treat "from" as a regular expression, with $1-style capture groups usable in "to". Default false.',
						),
					),
					'required'   => array(),
				),
				'callback'    => array( __CLASS__, 'manage_redirects' ),
			),
			array(
				'name'        => 'audit_404s',
				'description' => 'Report URLs that returned 404, ranked by how many times they were hit, each with a suggested destination found by matching against existing content. Nothing is redirected automatically — review the suggestions and create the rules you want.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'limit'      => array( 'type' => 'integer', 'description' => 'How many to return. Default 50.' ),
						'min_hits'   => array( 'type' => 'integer', 'description' => 'Only include URLs hit at least this many times. Default 1.' ),
						'clear'      => array( 'type' => 'boolean', 'description' => 'Clear the 404 log after reporting. Default false.' ),
					),
					'required'   => array(),
				),
				'callback'    => array( __CLASS__, 'audit_404s' ),
			),
			array(
				'name'        => 'find_broken_links',
				'description' => 'Scan published content for internal links pointing at pages that no longer exist. Reads Elementor page data as well as classic content, so it works on page-builder sites. Read-only.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'limit' => array( 'type' => 'integer', 'description' => 'How many published items to scan. Default 200.' ),
					),
					'required'   => array(),
				),
				'callback'    => array( __CLASS__, 'find_broken_links' ),
			),
		);
	}

	/* ===================================================================== */
	/* Storage                                                                */
	/* ===================================================================== */

	/**
	 * Create the 404 log table on first use.
	 */
	public static function maybe_install() {
		if ( self::VERSION === get_option( self::DB_VERSION ) ) {
			return;
		}
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table   = self::table();
		$collate = $wpdb->get_charset_collate();

		dbDelta(
			"CREATE TABLE {$table} (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				url VARCHAR(255) NOT NULL,
				hits BIGINT UNSIGNED NOT NULL DEFAULT 1,
				referrer VARCHAR(255) DEFAULT '',
				last_seen DATETIME NOT NULL,
				PRIMARY KEY (id),
				UNIQUE KEY url (url),
				KEY hits (hits)
			) {$collate};"
		);

		update_option( self::DB_VERSION, self::VERSION, false );
	}

	/**
	 * @return array<int, array<string, mixed>>
	 */
	private static function rules() {
		$r = get_option( self::OPTION, array() );
		return is_array( $r ) ? $r : array();
	}

	/**
	 * Normalise a path for comparison: leading slash, no trailing slash, no query.
	 *
	 * @param string $path
	 * @return string
	 */
	private static function normalise( $path ) {
		$path = (string) wp_parse_url( (string) $path, PHP_URL_PATH );
		$path = '/' . trim( $path, '/' );
		return ( '/' === $path ) ? '/' : rtrim( $path, '/' );
	}

	/* ===================================================================== */
	/* Runtime                                                                */
	/* ===================================================================== */

	/**
	 * Apply a matching redirect. Hooked to template_redirect from the main plugin file.
	 */
	public static function maybe_redirect() {
		if ( is_admin() || wp_doing_ajax() || wp_doing_cron() ) {
			return;
		}
		// Only step in when WordPress has nothing to serve. This keeps working URLs
		// untouched and makes a bad rule far less damaging.
		if ( ! is_404() ) {
			return;
		}

		$rules = self::rules();
		if ( ! $rules ) {
			return;
		}

		$request = self::normalise( $_SERVER['REQUEST_URI'] ?? '' );

		foreach ( $rules as $i => $rule ) {
			$target = '';

			if ( ! empty( $rule['is_regex'] ) ) {
				// Delimiters are added here, so a stored pattern can never inject flags.
				$pattern = '#' . str_replace( '#', '\#', (string) $rule['from'] ) . '#i';
				if ( @preg_match( $pattern, $request ) ) {
					$target = @preg_replace( $pattern, (string) $rule['to'], $request );
				}
			} elseif ( self::normalise( $rule['from'] ) === $request ) {
				$target = (string) $rule['to'];
			}

			if ( '' === $target ) {
				continue;
			}

			$code = (int) ( $rule['code'] ?? 301 );

			if ( 410 === $code ) {
				status_header( 410 );
				nocache_headers();
				self::bump_rule_hits( $i );
				exit;
			}

			$url = ( 0 === strpos( $target, 'http' ) ) ? $target : home_url( $target );

			// Never redirect a URL to itself: that is an infinite loop the browser
			// reports as ERR_TOO_MANY_REDIRECTS and the owner cannot easily diagnose.
			if ( self::normalise( $url ) === $request && 0 !== strpos( $target, 'http' ) ) {
				continue;
			}

			self::bump_rule_hits( $i );
			wp_redirect( $url, in_array( $code, array( 301, 302, 307 ), true ) ? $code : 301 );
			exit;
		}
	}

	/**
	 * @param int $index
	 */
	private static function bump_rule_hits( $index ) {
		$rules = self::rules();
		if ( isset( $rules[ $index ] ) ) {
			$rules[ $index ]['hits'] = (int) ( $rules[ $index ]['hits'] ?? 0 ) + 1;
			update_option( self::OPTION, $rules, false );
		}
	}

	/**
	 * Record a 404. Hooked to template_redirect after maybe_redirect().
	 */
	public static function log_404() {
		if ( ! is_404() || is_admin() || wp_doing_ajax() || wp_doing_cron() ) {
			return;
		}

		$path = self::normalise( $_SERVER['REQUEST_URI'] ?? '' );
		if ( '' === $path || '/' === $path ) {
			return;
		}
		// Missing assets are a different problem and would drown the useful signal.
		if ( preg_match( '/\.(css|js|png|jpe?g|gif|webp|svg|ico|woff2?|ttf|map|txt|xml)$/i', $path ) ) {
			return;
		}

		self::maybe_install();

		global $wpdb;
		$table = self::table();

		$count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
		if ( $count >= self::MAX_LOGGED ) {
			// Full: only keep counting URLs we already know about.
			$wpdb->query(
				$wpdb->prepare( "UPDATE {$table} SET hits = hits + 1, last_seen = %s WHERE url = %s", current_time( 'mysql' ), $path )
			);
			return;
		}

		$referrer = isset( $_SERVER['HTTP_REFERER'] ) ? esc_url_raw( wp_unslash( $_SERVER['HTTP_REFERER'] ) ) : '';

		$wpdb->query(
			$wpdb->prepare(
				"INSERT INTO {$table} (url, hits, referrer, last_seen) VALUES (%s, 1, %s, %s)
				 ON DUPLICATE KEY UPDATE hits = hits + 1, last_seen = VALUES(last_seen)",
				mb_substr( $path, 0, 255 ),
				mb_substr( $referrer, 0, 255 ),
				current_time( 'mysql' )
			)
		);
	}

	/* ===================================================================== */
	/* Tools                                                                  */
	/* ===================================================================== */

	/**
	 * @param array $args
	 * @return array|WP_Error
	 */
	public static function manage_redirects( $args ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'forbidden', 'You need the manage_options capability to manage redirects.' );
		}

		$action = isset( $args['action'] ) ? strtolower( (string) $args['action'] ) : 'list';
		$rules  = self::rules();

		if ( 'list' === $action ) {
			return array(
				'count'     => count( $rules ),
				'redirects' => $rules,
			);
		}

		$from = isset( $args['from'] ) ? trim( (string) $args['from'] ) : '';
		if ( '' === $from ) {
			return new WP_Error( 'missing_from', '"from" is required for add, update and delete.' );
		}

		$is_regex = ! empty( $args['is_regex'] );
		$key      = null;
		foreach ( $rules as $i => $r ) {
			$same = $is_regex ? ( (string) $r['from'] === $from ) : ( self::normalise( $r['from'] ) === self::normalise( $from ) );
			if ( $same ) {
				$key = $i;
				break;
			}
		}

		if ( 'delete' === $action ) {
			if ( null === $key ) {
				return new WP_Error( 'not_found', "No redirect rule found for '{$from}'." );
			}
			unset( $rules[ $key ] );
			update_option( self::OPTION, array_values( $rules ), false );
			return array( 'deleted' => $from, 'remaining' => count( $rules ) );
		}

		$code = isset( $args['code'] ) ? (int) $args['code'] : 301;
		if ( ! in_array( $code, array( 301, 302, 307, 410 ), true ) ) {
			return new WP_Error( 'invalid_code', 'code must be one of 301, 302, 307 or 410.' );
		}

		$to = isset( $args['to'] ) ? trim( (string) $args['to'] ) : '';
		if ( 410 !== $code && '' === $to ) {
			return new WP_Error( 'missing_to', '"to" is required unless code is 410.' );
		}

		if ( $is_regex && false === @preg_match( '#' . str_replace( '#', '\#', $from ) . '#', '' ) ) {
			return new WP_Error( 'invalid_regex', 'The "from" value is not a valid regular expression.' );
		}

		// A rule pointing at itself would loop forever.
		if ( ! $is_regex && 410 !== $code && self::normalise( $from ) === self::normalise( $to ) ) {
			return new WP_Error( 'redirect_loop', 'Source and destination are the same path — that is an infinite redirect loop.' );
		}

		$rule = array(
			'from'     => $is_regex ? $from : self::normalise( $from ),
			'to'       => $to,
			'code'     => $code,
			'is_regex' => $is_regex,
			'hits'     => null !== $key ? (int) ( $rules[ $key ]['hits'] ?? 0 ) : 0,
			'created'  => null !== $key ? ( $rules[ $key ]['created'] ?? current_time( 'mysql' ) ) : current_time( 'mysql' ),
		);

		if ( 'add' === $action && null !== $key ) {
			return new WP_Error( 'already_exists', "A redirect for '{$from}' already exists. Use action=update to change it." );
		}
		if ( 'update' === $action && null === $key ) {
			return new WP_Error( 'not_found', "No redirect rule found for '{$from}'. Use action=add to create it." );
		}

		if ( null !== $key ) {
			$rules[ $key ] = $rule;
		} else {
			$rules[] = $rule;
		}
		update_option( self::OPTION, array_values( $rules ), false );

		return array(
			'action' => $action,
			'rule'   => $rule,
			'count'  => count( $rules ),
			'note'   => 'Redirects apply only to URLs that would otherwise 404, so existing pages are unaffected. Purge any page cache.',
		);
	}

	/**
	 * @param array $args
	 * @return array|WP_Error
	 */
	public static function audit_404s( $args ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'forbidden', 'You need the manage_options capability.' );
		}

		self::maybe_install();

		global $wpdb;
		$table = self::table();
		$limit = isset( $args['limit'] ) ? min( 500, max( 1, absint( $args['limit'] ) ) ) : 50;
		$min   = isset( $args['min_hits'] ) ? max( 1, absint( $args['min_hits'] ) ) : 1;

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT url, hits, referrer, last_seen FROM {$table} WHERE hits >= %d ORDER BY hits DESC, last_seen DESC LIMIT %d",
				$min,
				$limit
			),
			ARRAY_A
		);

		if ( null === $rows ) {
			return array(
				'logged'  => 0,
				'entries' => array(),
				'note'    => 'The 404 log table does not exist yet, or nothing has 404ed since the plugin was activated.',
			);
		}

		$out = array();
		foreach ( (array) $rows as $r ) {
			$suggestion = self::suggest_target( (string) $r['url'] );
			$out[]      = array(
				'url'        => $r['url'],
				'hits'       => (int) $r['hits'],
				'referrer'   => $r['referrer'],
				'last_seen'  => $r['last_seen'],
				'suggestion' => $suggestion['url'],
				'confidence' => $suggestion['confidence'],
				'matched'    => $suggestion['title'],
			);
		}

		if ( ! empty( $args['clear'] ) ) {
			$wpdb->query( "TRUNCATE TABLE {$table}" );
		}

		$total = (int) $wpdb->get_var( "SELECT SUM(hits) FROM {$table}" );

		return array(
			'logged'      => count( $out ),
			'total_hits'  => $total,
			'cleared'     => ! empty( $args['clear'] ),
			'entries'     => $out,
			'next_step'   => 'Create rules for the high-confidence suggestions with manage_redirects (action=add).',
			'note'        => 'Suggestions come from slug similarity against published content. Nothing is redirected automatically — a wrong 301 is invisible and hard to undo once search engines have followed it.',
		);
	}

	/**
	 * Best-guess destination for a missing path.
	 *
	 * @param string $path
	 * @return array{url: string, title: string, confidence: string}
	 */
	private static function suggest_target( $path ) {
		$slug = sanitize_title( basename( rtrim( $path, '/' ) ) );
		if ( '' === $slug ) {
			return array( 'url' => '', 'title' => '', 'confidence' => 'none' );
		}

		global $wpdb;

		// Exact slug that exists but at a different URL (the usual reorganisation case).
		$exact = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT ID, post_title FROM {$wpdb->posts}
				 WHERE post_name = %s AND post_status = 'publish' AND post_type IN ('post','page') LIMIT 1",
				$slug
			)
		);
		if ( $exact ) {
			return array(
				'url'        => get_permalink( (int) $exact->ID ),
				'title'      => $exact->post_title,
				'confidence' => 'high',
			);
		}

		$candidates = $wpdb->get_results(
			"SELECT ID, post_name, post_title FROM {$wpdb->posts}
			 WHERE post_status = 'publish' AND post_type IN ('post','page') LIMIT 2000"
		);

		// Token-prefix match, checked before raw similarity.
		//
		// Theme demos leave behind paths like /team-details/ and /service-details/ whose
		// obvious target is /team/ and /services/. Character similarity scores those
		// below any useful threshold ("team-details" vs "team" is ~50%), so they would be
		// reported as "no suggestion" despite being unambiguous. Longest match wins, so
		// "hotel-management-course-fees" prefers "hotel-management-course" over "hotel".
		$prefix     = null;
		$prefix_len = 0;
		foreach ( (array) $candidates as $c ) {
			$name = (string) $c->post_name;
			if ( '' === $name ) {
				continue;
			}
			if ( 0 === strpos( $slug, $name . '-' ) || 0 === strpos( $name, $slug . '-' ) ) {
				if ( strlen( $name ) > $prefix_len ) {
					$prefix_len = strlen( $name );
					$prefix     = $c;
				}
			}
		}
		if ( $prefix ) {
			return array(
				'url'        => get_permalink( (int) $prefix->ID ),
				'title'      => $prefix->post_title,
				'confidence' => 'medium',
			);
		}

		// Otherwise score every published slug for similarity.
		$best   = null;
		$best_p = 0.0;
		foreach ( (array) $candidates as $c ) {
			similar_text( $slug, (string) $c->post_name, $percent );
			if ( $percent > $best_p ) {
				$best_p = $percent;
				$best   = $c;
			}
		}

		if ( ! $best || $best_p < 55 ) {
			return array( 'url' => '', 'title' => '', 'confidence' => 'none' );
		}

		return array(
			'url'        => get_permalink( (int) $best->ID ),
			'title'      => $best->post_title,
			'confidence' => $best_p >= 80 ? 'high' : ( $best_p >= 65 ? 'medium' : 'low' ),
		);
	}

	/**
	 * @param array $args
	 * @return array|WP_Error
	 */
	public static function find_broken_links( $args ) {
		if ( ! current_user_can( 'edit_posts' ) ) {
			return new WP_Error( 'forbidden', 'You need the edit_posts capability.' );
		}

		$limit = isset( $args['limit'] ) ? min( 1000, max( 1, absint( $args['limit'] ) ) ) : 200;

		$ids = get_posts(
			array(
				'post_type'      => array( 'page', 'post' ),
				'post_status'    => 'publish',
				'posts_per_page' => $limit,
				'fields'         => 'ids',
			)
		);

		$host   = wp_parse_url( home_url(), PHP_URL_HOST );
		$broken = array();
		$seen   = array();
		$checked = 0;

		foreach ( $ids as $id ) {
			$id      = (int) $id;
			$content = (string) get_post_field( 'post_content', $id );
			$el      = get_post_meta( $id, '_elementor_data', true );
			if ( $el ) {
				// Elementor stores JSON with escaped slashes.
				$content .= str_replace( '\\/', '/', is_string( $el ) ? $el : wp_json_encode( $el ) );
			}

			if ( ! preg_match_all( '#https?://' . preg_quote( (string) $host, '#' ) . '([^"\'\s<>\\\\]*)#i', $content, $m ) ) {
				continue;
			}

			foreach ( $m[0] as $url ) {
				$url = rtrim( $url, '.,);' );
				if ( isset( $seen[ $url ] ) ) {
					continue;
				}
				$seen[ $url ] = true;

				$path = (string) wp_parse_url( $url, PHP_URL_PATH );
				if ( '' === $path || '/' === $path ) {
					continue;
				}
				// Uploads and other real files are not post URLs; skip them.
				if ( preg_match( '#/wp-content/|/wp-admin/|/wp-json/#i', $path ) ) {
					continue;
				}

				++$checked;
				if ( url_to_postid( $url ) ) {
					continue; // Resolves to real content.
				}

				// url_to_postid() returns 0 for categories, tags and date archives too,
				// so confirm with a real request before calling it broken.
				$res  = wp_remote_head( $url, array( 'timeout' => 8, 'redirection' => 2, 'sslverify' => false ) );
				$code = is_wp_error( $res ) ? 0 : (int) wp_remote_retrieve_response_code( $res );
				if ( 404 !== $code ) {
					continue;
				}

				$broken[] = array(
					'url'        => $url,
					'found_in'   => array( 'post_id' => $id, 'title' => axon_text( get_the_title( $id ) ), 'edit' => get_edit_post_link( $id, 'raw' ) ),
					'suggestion' => self::suggest_target( $path )['url'],
				);

				if ( count( $broken ) >= 100 ) {
					break 2; // Enough to act on; keep the request bounded.
				}
			}
		}

		return array(
			'posts_scanned' => count( $ids ),
			'links_checked' => $checked,
			'broken'        => $broken,
			'severity'      => $broken ? 'warn' : 'ok',
			'message'       => $broken
				? sprintf( '%d internal link(s) point at pages that return 404.', count( $broken ) )
				: 'No broken internal links found.',
			'note'          => 'Only internal links are checked. Fix the link in the source page where you can — a redirect is a patch, an edited link is a repair.',
		);
	}
}
