<?php
/**
 * Speed tools: audit page weight and WordPress bloat, convert the Media Library to
 * WebP locally (no QUIC.cloud / no external service), and clean up database cruft.
 *
 * WebP conversion uses the GD or Imagick extension that ships with virtually every
 * PHP install. Each converted file is written *alongside* the original as
 * "<original>.webp" — originals are never modified or deleted, so the whole thing
 * is reversible by deleting the .webp files.
 *
 * Delivery is handled by an .htaccess content-negotiation rule (see webp_delivery()),
 * which swaps in the .webp only for browsers that send "Accept: image/webp". Doing it
 * at the web-server layer means it costs nothing at runtime and cannot poison a page
 * cache, because images are not part of the page cache.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Axon_Speed_Tools {

	/** Marker used to fence our block inside .htaccess so we can rewrite it safely. */
	const HTACCESS_MARKER = 'Axon WebP';

	/** Formats worth converting. GIF is excluded: animated GIFs would lose animation. */
	const CONVERTIBLE = array( 'image/jpeg', 'image/png' );

	/**
	 * @return array<int, array<string, mixed>>
	 */
	public static function tools() {
		return array(
			array(
				'name'        => 'get_performance_report',
				'description' => 'Audit this site for speed problems: image payload and formats, WebP coverage, database bloat (autoloaded options, revisions, expired transients), active plugin count and PHP/server config. Returns findings scored by impact with the estimated saving of each. Read-only.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'scan_limit' => array(
							'type'        => 'integer',
							'description' => 'Maximum number of image attachments to measure on disk. Default 500. Raise for a full audit of a large library.',
						),
					),
					'required'   => array(),
				),
				'callback'    => array( __CLASS__, 'get_performance_report' ),
			),
			array(
				'name'        => 'convert_media_to_webp',
				'description' => 'Convert JPEG/PNG images in the Media Library to WebP locally using PHP GD/Imagick. Originals are kept untouched; a "<file>.webp" is written beside each one. Runs in batches — call repeatedly until remaining is 0. Requires enable_webp_delivery to actually serve them.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'batch_size' => array(
							'type'        => 'integer',
							'description' => 'How many attachments to convert in this call. Default 25, max 200. Keep it modest to avoid PHP timeouts on shared hosting.',
						),
						'quality'    => array(
							'type'        => 'integer',
							'description' => 'WebP quality 1-100. Default 82, which is visually lossless for photographs.',
						),
						'include_thumbnails' => array(
							'type'        => 'boolean',
							'description' => 'Also convert the generated thumbnail sizes, not just the full-size file. Default true.',
						),
						'dry_run'    => array(
							'type'        => 'boolean',
							'description' => 'Report what would be converted and the projected saving, without writing any files.',
						),
					),
					'required'   => array(),
				),
				'callback'    => array( __CLASS__, 'convert_media_to_webp' ),
			),
			array(
				'name'        => 'enable_webp_delivery',
				'description' => 'Add (or remove) the .htaccess rule that serves the generated .webp files to browsers which support WebP. Apache and LiteSpeed servers only. Reversible — pass enabled=false to strip the rule.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'enabled' => array(
							'type'        => 'boolean',
							'description' => 'True to install the rule, false to remove it. Default true.',
						),
					),
					'required'   => array(),
				),
				'callback'    => array( __CLASS__, 'enable_webp_delivery' ),
			),
			array(
				'name'        => 'cleanup_database',
				'description' => 'Remove database bloat that slows every page load: post revisions, expired transients, trashed posts and orphaned postmeta. Always preview with dry_run first — deletions cannot be undone without a backup.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'dry_run'            => array(
							'type'        => 'boolean',
							'description' => 'Count what would be removed without deleting anything. Default TRUE — you must pass false explicitly to delete.',
						),
						'keep_revisions'     => array(
							'type'        => 'integer',
							'description' => 'How many of the most recent revisions to keep per post. Default 3.',
						),
						'expired_transients' => array(
							'type'        => 'boolean',
							'description' => 'Delete transients whose expiry has passed. Default true. Safe — they are a cache.',
						),
						'trashed_posts'      => array(
							'type'        => 'boolean',
							'description' => 'Permanently delete posts already in the Trash. Default FALSE, since this is real content loss.',
						),
					),
					'required'   => array(),
				),
				'callback'    => array( __CLASS__, 'cleanup_database' ),
			),
		);
	}

	/* --------------------------------------------------------------------- */
	/* Audit                                                                  */
	/* --------------------------------------------------------------------- */

	/**
	 * @param array $args
	 * @return array|WP_Error
	 */
	public static function get_performance_report( $args ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'forbidden', 'You need the manage_options capability to read the performance report.' );
		}

		global $wpdb;
		$limit    = isset( $args['scan_limit'] ) ? max( 1, absint( $args['scan_limit'] ) ) : 500;
		$findings = array();

		// --- Images -------------------------------------------------------
		$images = self::scan_images( $limit );

		if ( $images['convertible_bytes'] > 0 ) {
			// WebP at q82 lands around 70% smaller than PNG photos, ~30% smaller than JPEG.
			$projected = (int) round( $images['png_bytes'] * 0.28 + $images['jpeg_bytes'] * 0.70 );
			$saving    = $images['convertible_bytes'] - $projected;
			if ( $saving > 0 ) {
				$findings[] = self::finding(
					'images_not_webp',
					$images['without_webp'] > 0 ? 'critical' : 'ok',
					sprintf(
						'%d of %d images have no WebP version. Converting saves about %s of the %s image payload.',
						$images['without_webp'],
						$images['counted'],
						size_format( $saving ),
						size_format( $images['convertible_bytes'] )
					),
					'convert_media_to_webp',
					$saving
				);
			}
		}

		if ( $images['png_photos'] > 0 ) {
			$findings[] = self::finding(
				'photos_stored_as_png',
				'critical',
				sprintf(
					'%d PNG files are larger than 150 KB, which almost always means a photograph was saved as PNG. PNG is lossless and roughly 4-8x bigger than JPEG/WebP for photos.',
					$images['png_photos']
				),
				'convert_media_to_webp',
				0
			);
		}

		// --- Database -----------------------------------------------------
		$autoload = (int) $wpdb->get_var( "SELECT SUM(LENGTH(option_value)) FROM {$wpdb->options} WHERE autoload IN ('yes','on','auto','auto-on')" );
		$findings[] = self::finding(
			'autoload_size',
			$autoload > 1048576 ? 'critical' : ( $autoload > 819200 ? 'warn' : 'ok' ),
			sprintf( 'Autoloaded options are %s. This is read from the database on EVERY page load. Target: under 800 KB.', size_format( $autoload ) ),
			$autoload > 819200 ? 'Inspect the largest autoloaded options; stale plugin data is the usual culprit.' : '',
			0
		);

		$revisions = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'revision'" );
		$findings[] = self::finding(
			'post_revisions',
			$revisions > 1000 ? 'warn' : 'ok',
			sprintf( '%d post revisions stored.', $revisions ),
			$revisions > 1000 ? 'cleanup_database' : '',
			0
		);

		$expired = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE %s AND option_value < %d",
				$wpdb->esc_like( '_transient_timeout_' ) . '%',
				time()
			)
		);
		$findings[] = self::finding(
			'expired_transients',
			$expired > 200 ? 'warn' : 'ok',
			sprintf( '%d expired transients still in the options table.', $expired ),
			$expired > 200 ? 'cleanup_database' : '',
			0
		);

		// --- Server / WordPress config ------------------------------------
		$active = count( (array) get_option( 'active_plugins', array() ) );
		$findings[] = self::finding(
			'active_plugins',
			$active > 25 ? 'warn' : 'ok',
			sprintf( '%d active plugins. Each one adds PHP work to every request.', $active ),
			$active > 25 ? 'Audit for plugins that are unused or duplicate each other.' : '',
			0
		);

		$php_ok     = version_compare( PHP_VERSION, '8.1', '>=' );
		$findings[] = self::finding(
			'php_version',
			$php_ok ? 'ok' : 'warn',
			sprintf( 'PHP %s.%s', PHP_VERSION, $php_ok ? '' : ' Upgrade to 8.1+ for a substantial free speed gain.' ),
			'',
			0
		);

		$findings[] = self::finding(
			'object_cache',
			wp_using_ext_object_cache() ? 'ok' : 'warn',
			wp_using_ext_object_cache()
				? 'A persistent object cache is active.'
				: 'No persistent object cache (Redis/Memcached). Repeated database queries are not being reused between requests.',
			'',
			0
		);

		$findings[] = self::finding(
			'webp_delivery',
			self::htaccess_has_rule() ? 'ok' : 'warn',
			self::htaccess_has_rule()
				? 'WebP delivery rule is installed in .htaccess.'
				: 'No WebP delivery rule. Even after converting, browsers will keep downloading the originals.',
			self::htaccess_has_rule() ? '' : 'enable_webp_delivery',
			0
		);

		// Rank by severity, worst first.
		$rank = array( 'critical' => 0, 'warn' => 1, 'ok' => 2 );
		usort(
			$findings,
			static function ( $a, $b ) use ( $rank ) {
				$cmp = $rank[ $a['severity'] ] <=> $rank[ $b['severity'] ];
				return 0 !== $cmp ? $cmp : ( $b['estimated_saving_bytes'] <=> $a['estimated_saving_bytes'] );
			}
		);

		return array(
			'site'     => home_url(),
			'summary'  => array(
				'critical'                => count( array_filter( $findings, static fn( $f ) => 'critical' === $f['severity'] ) ),
				'warnings'                => count( array_filter( $findings, static fn( $f ) => 'warn' === $f['severity'] ) ),
				'total_saving_estimate'   => size_format( (int) array_sum( wp_list_pluck( $findings, 'estimated_saving_bytes' ) ) ),
			),
			'images'   => array(
				'attachments_scanned' => $images['counted'],
				'total_size'          => size_format( $images['total_bytes'] ),
				'convertible_size'    => size_format( $images['convertible_bytes'] ),
				'already_webp'        => $images['with_webp'],
				'missing_webp'        => $images['without_webp'],
				'oversized_pngs'      => $images['png_photos'],
				'truncated'           => $images['truncated'],
			),
			'findings' => $findings,
		);
	}

	/**
	 * Walk image attachments and total their on-disk size.
	 *
	 * @param int $limit
	 * @return array<string, int|bool>
	 */
	private static function scan_images( $limit ) {
		global $wpdb;

		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts}
				 WHERE post_type = 'attachment' AND post_mime_type IN ('image/jpeg','image/png')
				 ORDER BY ID DESC LIMIT %d",
				$limit + 1
			)
		);

		$truncated = count( $ids ) > $limit;
		$ids       = array_slice( $ids, 0, $limit );

		$out = array(
			'counted'           => 0,
			'total_bytes'       => 0,
			'convertible_bytes' => 0,
			'png_bytes'         => 0,
			'jpeg_bytes'        => 0,
			'with_webp'         => 0,
			'without_webp'      => 0,
			'png_photos'        => 0,
			'truncated'         => $truncated,
		);

		foreach ( $ids as $id ) {
			$file = get_attached_file( (int) $id );
			if ( ! $file || ! is_readable( $file ) ) {
				continue;
			}
			$size = (int) @filesize( $file );
			if ( $size <= 0 ) {
				continue;
			}

			++$out['counted'];
			$out['total_bytes']       += $size;
			$out['convertible_bytes'] += $size;

			if ( 'image/png' === get_post_mime_type( (int) $id ) ) {
				$out['png_bytes'] += $size;
				// A PNG over 150 KB is nearly always a photo in the wrong format.
				if ( $size > 153600 ) {
					++$out['png_photos'];
				}
			} else {
				$out['jpeg_bytes'] += $size;
			}

			if ( file_exists( $file . '.webp' ) ) {
				++$out['with_webp'];
			} else {
				++$out['without_webp'];
			}
		}

		return $out;
	}

	/**
	 * @param string $id
	 * @param string $severity  critical|warn|ok
	 * @param string $message
	 * @param string $fix
	 * @param int    $saving
	 * @return array<string, mixed>
	 */
	private static function finding( $id, $severity, $message, $fix = '', $saving = 0 ) {
		return array(
			'id'                     => $id,
			'severity'               => $severity,
			'message'                => $message,
			'fix'                    => $fix,
			'estimated_saving_bytes' => (int) $saving,
		);
	}

	/* --------------------------------------------------------------------- */
	/* WebP conversion                                                        */
	/* --------------------------------------------------------------------- */

	/**
	 * @param array $args
	 * @return array|WP_Error
	 */
	public static function convert_media_to_webp( $args ) {
		if ( ! current_user_can( 'upload_files' ) ) {
			return new WP_Error( 'forbidden', 'You need the upload_files capability to convert media.' );
		}

		$engine = self::webp_engine();
		if ( ! $engine ) {
			return new WP_Error(
				'no_webp_support',
				'Neither GD (with WebP support) nor Imagick is available on this server, so WebP cannot be generated locally. Ask your host to enable the GD extension with WebP.'
			);
		}

		$batch   = isset( $args['batch_size'] ) ? min( 200, max( 1, absint( $args['batch_size'] ) ) ) : 25;
		$quality = isset( $args['quality'] ) ? min( 100, max( 1, absint( $args['quality'] ) ) ) : 82;
		$thumbs  = ! isset( $args['include_thumbnails'] ) || (bool) $args['include_thumbnails'];
		$dry     = ! empty( $args['dry_run'] );

		global $wpdb;
		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts}
				 WHERE post_type = 'attachment' AND post_mime_type IN ('image/jpeg','image/png')
				 ORDER BY ID ASC LIMIT %d",
				// Over-fetch: many will already be done and get skipped.
				$batch * 20
			)
		);

		$converted   = 0;
		$skipped     = 0;
		$failed      = 0;
		$before      = 0;
		$after       = 0;
		$errors      = array();
		$remaining   = 0;

		foreach ( $ids as $id ) {
			$main = get_attached_file( (int) $id );
			if ( ! $main || ! is_readable( $main ) ) {
				continue;
			}

			$targets = array( $main );
			if ( $thumbs ) {
				$targets = array_merge( $targets, self::thumbnail_paths( (int) $id, $main ) );
			}

			foreach ( $targets as $path ) {
				if ( ! is_readable( $path ) ) {
					continue;
				}
				$webp = $path . '.webp';
				if ( file_exists( $webp ) ) {
					++$skipped;
					continue;
				}

				// Budget reached — count what is left so the caller knows to call again.
				if ( $converted >= $batch ) {
					++$remaining;
					continue;
				}

				$src = (int) @filesize( $path );
				if ( $dry ) {
					++$converted;
					$before += $src;
					$after  += (int) round( $src * 0.35 );
					continue;
				}

				$ok = self::write_webp( $path, $webp, $quality, $engine );
				if ( is_wp_error( $ok ) ) {
					++$failed;
					if ( count( $errors ) < 5 ) {
						$errors[] = basename( $path ) . ': ' . $ok->get_error_message();
					}
					continue;
				}

				++$converted;
				$before += $src;
				$after  += (int) @filesize( $webp );
			}
		}

		$saved = max( 0, $before - $after );

		return array(
			'engine'          => $engine,
			'dry_run'         => $dry,
			'quality'         => $quality,
			'files_converted' => $converted,
			'files_skipped'   => $skipped,
			'files_failed'    => $failed,
			'remaining'       => $remaining,
			'bytes_before'    => size_format( $before ),
			'bytes_after'     => size_format( $after ),
			'bytes_saved'     => size_format( $saved ),
			'percent_saved'   => $before > 0 ? round( $saved / $before * 100 ) . '%' : '0%',
			'errors'          => $errors,
			'next_step'       => $remaining > 0
				? 'Call convert_media_to_webp again to continue.'
				: ( self::htaccess_has_rule() ? 'Done. WebP delivery is already active.' : 'Done. Now call enable_webp_delivery so browsers actually receive the .webp files.' ),
		);
	}

	/**
	 * Absolute paths of every generated thumbnail for an attachment.
	 *
	 * @param int    $id
	 * @param string $main
	 * @return array<int, string>
	 */
	private static function thumbnail_paths( $id, $main ) {
		$meta = wp_get_attachment_metadata( $id );
		if ( empty( $meta['sizes'] ) || ! is_array( $meta['sizes'] ) ) {
			return array();
		}
		$dir  = trailingslashit( dirname( $main ) );
		$out  = array();
		foreach ( $meta['sizes'] as $size ) {
			if ( ! empty( $size['file'] ) ) {
				$out[] = $dir . $size['file'];
			}
		}
		return $out;
	}

	/**
	 * @return string '' | 'imagick' | 'gd'
	 */
	private static function webp_engine() {
		if ( class_exists( 'Imagick' ) && in_array( 'WEBP', array_map( 'strtoupper', (array) Imagick::queryFormats() ), true ) ) {
			return 'imagick';
		}
		if ( function_exists( 'imagewebp' ) ) {
			return 'gd';
		}
		return '';
	}

	/**
	 * @param string $src
	 * @param string $dest
	 * @param int    $quality
	 * @param string $engine
	 * @return true|WP_Error
	 */
	private static function write_webp( $src, $dest, $quality, $engine ) {
		if ( 'imagick' === $engine ) {
			try {
				$im = new Imagick( $src );
				$im->setImageFormat( 'webp' );
				$im->setImageCompressionQuality( $quality );
				// Flatten alpha only when there is none, so transparent PNGs stay transparent.
				$im->stripImage();
				$ok = $im->writeImage( $dest );
				$im->clear();
				// Imagick::destroy() is deprecated in newer builds; clear() already frees it.
				if ( PHP_VERSION_ID < 80000 && method_exists( $im, 'destroy' ) ) {
					$im->destroy();
				}
				return $ok ? true : new WP_Error( 'imagick_write_failed', 'Imagick could not write the WebP file.' );
			} catch ( Exception $e ) {
				return new WP_Error( 'imagick_error', $e->getMessage() );
			}
		}

		$type = @getimagesize( $src );
		$mime = is_array( $type ) ? ( $type['mime'] ?? '' ) : '';

		switch ( $mime ) {
			case 'image/jpeg':
				$img = @imagecreatefromjpeg( $src );
				break;
			case 'image/png':
				$img = @imagecreatefrompng( $src );
				if ( $img ) {
					// Without these, transparency is written as black.
					imagepalettetotruecolor( $img );
					imagealphablending( $img, false );
					imagesavealpha( $img, true );
				}
				break;
			default:
				return new WP_Error( 'unsupported_mime', "Cannot convert mime type '{$mime}'." );
		}

		if ( ! $img ) {
			return new WP_Error( 'decode_failed', 'GD could not read the source image (it may be corrupt or truncated).' );
		}

		$ok = @imagewebp( $img, $dest, $quality );
		// imagedestroy() is a no-op from PHP 8.0 and raises a deprecation from 8.5.
		if ( PHP_VERSION_ID < 80000 ) {
			imagedestroy( $img );
		}
		unset( $img );

		if ( ! $ok ) {
			return new WP_Error( 'encode_failed', 'GD could not write the WebP file. Check directory permissions.' );
		}

		// GD writes a 0-byte file on some builds when the image is very large.
		if ( (int) @filesize( $dest ) <= 0 ) {
			@unlink( $dest );
			return new WP_Error( 'empty_output', 'WebP output was empty and has been discarded.' );
		}

		return true;
	}

	/* --------------------------------------------------------------------- */
	/* Delivery                                                               */
	/* --------------------------------------------------------------------- */

	/**
	 * @param array $args
	 * @return array|WP_Error
	 */
	public static function enable_webp_delivery( $args ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'forbidden', 'You need the manage_options capability to edit .htaccess.' );
		}

		$enabled = ! isset( $args['enabled'] ) || (bool) $args['enabled'];
		$file    = self::htaccess_path();

		if ( ! $file ) {
			return new WP_Error( 'no_htaccess', 'Could not locate the site .htaccess file. On nginx this rule does not apply — ask your host to add WebP content negotiation.' );
		}
		if ( file_exists( $file ) && ! is_writable( $file ) ) {
			return new WP_Error( 'htaccess_not_writable', "The .htaccess file at {$file} is not writable." );
		}

		require_once ABSPATH . 'wp-admin/includes/misc.php';

		$rules = $enabled ? array(
			'<IfModule mod_rewrite.c>',
			'RewriteEngine On',
			'RewriteCond %{HTTP_ACCEPT} image/webp',
			'RewriteCond %{DOCUMENT_ROOT}%{REQUEST_URI}.webp -f',
			'RewriteRule ^(.+)\.(jpe?g|png)$ $1.$2.webp [NC,T=image/webp,L]',
			'</IfModule>',
			'<IfModule mod_headers.c>',
			'<FilesMatch "\.(jpe?g|png)$">',
			'Header append Vary Accept',
			'</FilesMatch>',
			'</IfModule>',
		) : array();

		$ok = insert_with_markers( $file, self::HTACCESS_MARKER, $rules );

		if ( ! $ok ) {
			return new WP_Error( 'htaccess_write_failed', 'WordPress could not update the .htaccess file.' );
		}

		return array(
			'enabled'  => $enabled,
			'htaccess' => $file,
			'note'     => $enabled
				? 'WebP is now served to supporting browsers. Originals remain available for older browsers. Purge any page/CDN cache to see it take effect.'
				: 'The WebP delivery rule has been removed. Originals are served to everyone again; the .webp files are still on disk.',
		);
	}

	/**
	 * @return string
	 */
	private static function htaccess_path() {
		$home  = get_home_path();
		$file  = $home ? $home . '.htaccess' : '';
		return $file && ( file_exists( $file ) || is_writable( dirname( $file ) ) ) ? $file : '';
	}

	/**
	 * @return bool
	 */
	private static function htaccess_has_rule() {
		$file = self::htaccess_path();
		if ( ! $file || ! is_readable( $file ) ) {
			return false;
		}
		return false !== strpos( (string) file_get_contents( $file ), self::HTACCESS_MARKER );
	}

	/* --------------------------------------------------------------------- */
	/* Database cleanup                                                       */
	/* --------------------------------------------------------------------- */

	/**
	 * @param array $args
	 * @return array|WP_Error
	 */
	public static function cleanup_database( $args ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'forbidden', 'You need the manage_options capability to clean the database.' );
		}

		global $wpdb;

		// Destructive by nature, so default to preview and require an explicit false.
		$dry     = ! isset( $args['dry_run'] ) || (bool) $args['dry_run'];
		$keep    = isset( $args['keep_revisions'] ) ? max( 0, absint( $args['keep_revisions'] ) ) : 3;
		$do_tran = ! isset( $args['expired_transients'] ) || (bool) $args['expired_transients'];
		$do_tras = ! empty( $args['trashed_posts'] );

		$report = array( 'dry_run' => $dry );

		// --- Revisions beyond the keep-most-recent-N window ----------------
		$stale = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT r.ID FROM {$wpdb->posts} r
				 WHERE r.post_type = 'revision'
				   AND ( SELECT COUNT(*) FROM {$wpdb->posts} n
				         WHERE n.post_type='revision' AND n.post_parent=r.post_parent AND n.ID > r.ID ) >= %d",
				$keep
			)
		);
		$report['revisions_removable'] = count( $stale );
		if ( ! $dry ) {
			$done = 0;
			foreach ( $stale as $rid ) {
				if ( wp_delete_post_revision( (int) $rid ) ) {
					++$done;
				}
			}
			$report['revisions_deleted'] = $done;
		}

		// --- Expired transients -------------------------------------------
		if ( $do_tran ) {
			$names = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT option_name FROM {$wpdb->options}
					 WHERE option_name LIKE %s AND option_value < %d",
					$wpdb->esc_like( '_transient_timeout_' ) . '%',
					time()
				)
			);
			$report['expired_transients_removable'] = count( $names );
			if ( ! $dry ) {
				$done = 0;
				foreach ( $names as $n ) {
					// Strip the timeout prefix to get the transient's real key.
					if ( delete_transient( substr( $n, strlen( '_transient_timeout_' ) ) ) ) {
						++$done;
					}
				}
				$report['expired_transients_deleted'] = $done;
			}
		}

		// --- Trashed posts -------------------------------------------------
		if ( $do_tras ) {
			$trashed = $wpdb->get_col( "SELECT ID FROM {$wpdb->posts} WHERE post_status = 'trash'" );
			$report['trashed_posts_removable'] = count( $trashed );
			if ( ! $dry ) {
				$done = 0;
				foreach ( $trashed as $tid ) {
					if ( wp_delete_post( (int) $tid, true ) ) {
						++$done;
					}
				}
				$report['trashed_posts_deleted'] = $done;
			}
		}

		// --- Orphaned postmeta ---------------------------------------------
		$orphans = (int) $wpdb->get_var(
			"SELECT COUNT(*) FROM {$wpdb->postmeta} pm
			 LEFT JOIN {$wpdb->posts} p ON p.ID = pm.post_id
			 WHERE p.ID IS NULL"
		);
		$report['orphaned_postmeta_removable'] = $orphans;
		if ( ! $dry && $orphans > 0 ) {
			$report['orphaned_postmeta_deleted'] = (int) $wpdb->query(
				"DELETE pm FROM {$wpdb->postmeta} pm
				 LEFT JOIN {$wpdb->posts} p ON p.ID = pm.post_id
				 WHERE p.ID IS NULL"
			);
		}

		$report['autoload_size_after'] = size_format(
			(int) $wpdb->get_var( "SELECT SUM(LENGTH(option_value)) FROM {$wpdb->options} WHERE autoload IN ('yes','on','auto','auto-on')" )
		);
		$report['note'] = $dry
			? 'Nothing was deleted. Re-run with dry_run=false to apply.'
			: 'Cleanup applied. Take a backup before running this on a site you cannot restore.';

		return $report;
	}
}
