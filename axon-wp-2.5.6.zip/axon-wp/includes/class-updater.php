<?php
/**
 * Self-hosted plugin updater.
 *
 * WHY THIS EXISTS
 * ---------------
 * WordPress only ever asks api.wordpress.org whether a plugin has a new version. A plugin
 * distributed outside the .org directory is invisible to that check, so every change means
 * re-zipping and re-uploading by hand on every site it is installed on.
 *
 * WordPress does, however, let a plugin answer the update question itself. Core builds the
 * "update available" notice from the `update_plugins` site transient; anything that filters
 * that transient and injects a row for its own basename gets the normal blue "Update now"
 * link, the normal one-click download-and-replace, and the normal auto-update toggle. This
 * is exactly how Elementor Pro, WP Rocket and Rank Math Pro update themselves. Nothing here
 * is a hack or a private API — `site_transient_update_plugins` and `plugins_api` are both
 * documented, stable filters.
 *
 * HOW IT WORKS
 * ------------
 * 1. A JSON manifest lives at a URL we control (AXON_UPDATE_MANIFEST). It states the
 *    newest version and where to download that version's zip.
 * 2. This class fetches the manifest (cached 6h in a transient, so a normal admin page load
 *    costs nothing) and compares its `version` against the running plugin's version.
 * 3. If the manifest is newer, it injects a response row into the update transient. Core
 *    does the rest — the download, the unpack, the replace, the reactivation.
 *
 * WHY THE MANIFEST IS A STATIC FILE, NOT AN API CALL
 * --------------------------------------------------
 * An earlier design hit api.github.com/repos/.../releases/latest. That works, but
 * unauthenticated GitHub API calls are rate-limited to 60/hour *per IP* — and shared hosts
 * put hundreds of sites behind one IP, so the check fails intermittently and unpredictably
 * on exactly the cheap hosting most WordPress sites run on. raw.githubusercontent.com serves
 * static files from a CDN with no such limit, so the manifest is a plain file and the
 * download URL points at a GitHub Release asset (also unmetered, also permanent).
 *
 * PRIVATE REPOSITORIES
 * --------------------
 * Distribution is public by default — anyone with the plugin gets updates, no credentials.
 * If the manifest is ever moved into a private repo, defining AXON_UPDATE_TOKEN in
 * wp-config.php makes every request authenticate with it. Note the tradeoff honestly: a
 * token shipped inside a downloadable zip is readable by anyone who downloads that zip, so
 * a token only makes sense for sites you control, never for a publicly distributed build.
 *
 * @package Axon
 */

defined( 'ABSPATH' ) || exit;

/**
 * Checks a remote JSON manifest and feeds results into WordPress's own update system.
 */
class Axon_Updater {

	/**
	 * Absolute path to the main plugin file.
	 *
	 * @var string
	 */
	private $file;

	/**
	 * "axon-wp/axon-wp.php" — how core identifies this plugin everywhere.
	 *
	 * @var string
	 */
	private $basename;

	/**
	 * Directory name of the plugin, used as its slug.
	 *
	 * @var string
	 */
	private $slug;

	/**
	 * Currently installed version.
	 *
	 * @var string
	 */
	private $version;

	/**
	 * URL of the remote JSON manifest.
	 *
	 * @var string
	 */
	private $manifest_url;

	/**
	 * Transient key holding the cached manifest.
	 *
	 * @var string
	 */
	private $cache_key;

	/**
	 * How long a fetched manifest stays cached.
	 */
	/**
	 * How long a fetched manifest stays cached.
	 *
	 * This was 6 hours and it was too long. The manifest is a small static file on a CDN, so
	 * the saving is negligible, while the cost is real: a site that checked shortly before a
	 * release kept reporting "up to date" for hours afterwards with no way for the operator
	 * to tell why. An hour bounds that window to something a person will sit through.
	 */
	const CACHE_TTL = HOUR_IN_SECONDS;

	/**
	 * How long a FAILED lookup is remembered.
	 *
	 * Short, deliberately. A failure cache exists only to stop a site with no outbound
	 * network making an HTTP request on every admin page load; remembering a transient blip
	 * for an hour would strand a working site for no reason.
	 */
	const FAIL_TTL = 5 * MINUTE_IN_SECONDS;

	/**
	 * Constructor.
	 *
	 * @param string $file         Absolute path to the main plugin file.
	 * @param string $version      Installed version.
	 * @param string $manifest_url URL of the JSON manifest.
	 */
	public function __construct( $file, $version, $manifest_url ) {
		$this->file         = $file;
		$this->basename     = plugin_basename( $file );
		$this->slug         = dirname( $this->basename );
		$this->version      = $version;
		$this->manifest_url = $manifest_url;
		// Version is part of the key so upgrading always re-checks against fresh data
		// instead of trusting a manifest cached by the version we just replaced.
		$this->cache_key = 'axon_update_' . md5( $manifest_url . '|' . $version );

		add_filter( 'site_transient_update_plugins', array( $this, 'inject_update' ) );
		add_filter( 'plugins_api', array( $this, 'plugin_details' ), 20, 3 );
		add_filter( 'upgrader_source_selection', array( $this, 'fix_folder_name' ), 10, 4 );
		add_filter( 'plugin_row_meta', array( $this, 'row_meta' ), 10, 2 );
		add_action( 'admin_init', array( $this, 'handle_manual_check' ) );
	}

	/**
	 * Fetch the manifest, using the cached copy unless it has expired.
	 *
	 * Returns null on any failure — a missing manifest, an unreachable host, a 404, or
	 * malformed JSON. Every caller treats null as "no update known", which means a broken
	 * or offline update server can never break the site: the plugin simply keeps running
	 * the version it already has.
	 *
	 * @param bool $force Skip the cache and re-fetch.
	 * @return array|null Decoded manifest, or null.
	 */
	public function get_manifest( $force = false ) {
		if ( ! $force ) {
			$cached = get_transient( $this->cache_key );
			if ( is_array( $cached ) ) {
				return $cached;
			}
			// A previous failure is cached as the string 'none' for a shorter period, so a
			// site with no network access does not re-attempt an HTTP request on every
			// single admin page load.
			if ( 'none' === $cached ) {
				return null;
			}
		}

		$args = array(
			'timeout'    => 10,
			'user-agent' => 'Axon/' . $this->version . '; ' . home_url( '/' ),
			'headers'    => array( 'Accept' => 'application/json' ),
		);

		// Only used when the manifest is hosted in a private repository. See the file
		// header for why this is not the default.
		if ( defined( 'AXON_UPDATE_TOKEN' ) && AXON_UPDATE_TOKEN ) {
			$args['headers']['Authorization'] = 'token ' . AXON_UPDATE_TOKEN;
		}

		// Cache-buster: raw.githubusercontent.com caches aggressively at the edge, and
		// without this a freshly pushed manifest can take several minutes to become
		// visible — which reads to the user as "the update did not publish".
		$url = add_query_arg( 'ts', time(), $this->manifest_url );

		$response = wp_remote_get( $url, $args );

		if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			set_transient( $this->cache_key, 'none', self::FAIL_TTL );
			return null;
		}

		$data = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( ! is_array( $data ) || empty( $data['version'] ) || empty( $data['download_url'] ) ) {
			set_transient( $this->cache_key, 'none', self::FAIL_TTL );
			return null;
		}

		set_transient( $this->cache_key, $data, self::CACHE_TTL );
		// Remember WHEN, so a later core update check can tell whether our copy predates it.
		set_transient( $this->cache_key . '_at', time(), self::CACHE_TTL );

		return $data;
	}

	/**
	 * Add this plugin to the update transient when the manifest advertises a newer version.
	 *
	 * @param mixed $transient The update_plugins site transient.
	 * @return mixed
	 */
	public function inject_update( $transient ) {
		// Core passes an empty string/false here on the very first call of a request
		// lifecycle, before it has built the object. Bailing out rather than creating our
		// own object avoids clobbering the checked/last_checked data core fills in later.
		if ( ! is_object( $transient ) ) {
			return $transient;
		}

		// Honour WordPress's own forced check. Dashboard → Updates → "Check again" and the
		// Plugins screen's "Check again" both set force-check, and core clears its own
		// transient — but not ours. Without this, a user doing exactly what WordPress tells
		// them to do gets our cached answer for up to 6 hours and reasonably concludes that
		// updates are broken. That is precisely how a released fix failed to reach a live
		// site while the update system reported everything as current.
		$forced = ! empty( $_GET['force-check'] ) && current_user_can( 'update_plugins' ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only cache-freshness hint, no state change.

		// Tie our freshness to WordPress's own. Core stamps last_checked every time it
		// genuinely re-runs an update check; if that happened after we cached, our answer is
		// older than the site's own idea of "just checked" and must not be trusted.
		//
		// Without this, our cache was an independent timer nobody could see: the operator
		// clicks the button WordPress gives them, core dutifully re-checks, and we reply from
		// a stale copy. That is what kept a published release from reaching a live site while
		// the UI insisted everything was current.
		if ( ! $forced && ! empty( $transient->last_checked ) ) {
			$fetched_at = (int) get_transient( $this->cache_key . '_at' );
			if ( $fetched_at && (int) $transient->last_checked > $fetched_at ) {
				$forced = true;
			}
		}

		$manifest = $this->get_manifest( $forced );
		if ( null === $manifest ) {
			return $transient;
		}

		$item = $this->manifest_to_response( $manifest );

		if ( version_compare( $manifest['version'], $this->version, '>' ) ) {
			$transient->response[ $this->basename ] = $item;
			unset( $transient->no_update[ $this->basename ] );
		} else {
			// Listing the plugin under no_update is what makes the per-plugin
			// "Enable auto-updates" link appear on the Plugins screen. Without it the
			// plugin looks unmanaged and auto-updates cannot be switched on at all.
			$transient->no_update[ $this->basename ] = $item;
			unset( $transient->response[ $this->basename ] );
		}

		return $transient;
	}

	/**
	 * Build the object core expects in the update transient.
	 *
	 * @param array $manifest Decoded manifest.
	 * @return object
	 */
	private function manifest_to_response( $manifest ) {
		return (object) array(
			'id'            => $this->slug,
			'slug'          => $this->slug,
			'plugin'        => $this->basename,
			'new_version'   => $manifest['version'],
			'url'           => $manifest['homepage'] ?? '',
			'package'       => $manifest['download_url'],
			'icons'         => $manifest['icons'] ?? array(),
			'banners'       => $manifest['banners'] ?? array(),
			'banners_rtl'   => array(),
			'tested'        => $manifest['tested'] ?? '',
			'requires_php'  => $manifest['requires_php'] ?? '',
			'compatibility' => new stdClass(),
		);
	}

	/**
	 * Supply the "View version x.y.z details" modal.
	 *
	 * Without this, clicking the details link on a plugin that is not in the .org directory
	 * shows an error, because core asks api.wordpress.org for a slug it has never heard of.
	 *
	 * @param mixed  $result Value being filtered.
	 * @param string $action The plugins_api action being performed.
	 * @param object $args   Request arguments.
	 * @return mixed
	 */
	public function plugin_details( $result, $action, $args ) {
		if ( 'plugin_information' !== $action ) {
			return $result;
		}
		if ( empty( $args->slug ) || $args->slug !== $this->slug ) {
			return $result;
		}

		$manifest = $this->get_manifest();
		if ( null === $manifest ) {
			return $result;
		}

		return (object) array(
			'name'           => $manifest['name'] ?? 'Axon',
			'slug'           => $this->slug,
			'version'        => $manifest['version'],
			'author'         => $manifest['author'] ?? '',
			'homepage'       => $manifest['homepage'] ?? '',
			'requires'       => $manifest['requires'] ?? '',
			'tested'         => $manifest['tested'] ?? '',
			'requires_php'   => $manifest['requires_php'] ?? '',
			'last_updated'   => $manifest['last_updated'] ?? '',
			'download_link'  => $manifest['download_url'],
			'trunk'          => $manifest['download_url'],
			'sections'       => $manifest['sections'] ?? array(),
			'banners'        => $manifest['banners'] ?? array(),
			'icons'          => $manifest['icons'] ?? array(),
			'external'       => true,
			'active_installs' => false,
		);
	}

	/**
	 * Force the unpacked folder to match the plugin slug.
	 *
	 * WordPress activates a plugin by path. If an update unpacks to a differently named
	 * folder — which happens with any zip built by GitHub's "Source code" link, since those
	 * are named repo-tag — core installs it as a *separate* plugin and silently deactivates
	 * the original. The release script here always builds a correctly named folder, so this
	 * is a safety net rather than the primary mechanism, but the failure it prevents is bad
	 * enough (site loses its MCP server after a routine update) to be worth the few lines.
	 *
	 * @param string $source        Path the update was unpacked to.
	 * @param string $remote_source Parent temp directory.
	 * @param object $upgrader      Upgrader instance.
	 * @param array  $args          Extra args, includes the plugin basename.
	 * @return string|WP_Error
	 */
	public function fix_folder_name( $source, $remote_source, $upgrader, $args = array() ) {
		global $wp_filesystem;

		if ( empty( $args['plugin'] ) || $args['plugin'] !== $this->basename ) {
			return $source;
		}
		if ( ! $wp_filesystem ) {
			return $source;
		}

		$desired = trailingslashit( $remote_source ) . $this->slug;

		if ( untrailingslashit( $source ) === $desired ) {
			return $source;
		}

		if ( $wp_filesystem->move( $source, $desired, true ) ) {
			return trailingslashit( $desired );
		}

		return new WP_Error(
			'axon_rename_failed',
			'Could not rename the downloaded update folder to "' . $this->slug . '". The update was not applied, and the installed version is unchanged.'
		);
	}

	/**
	 * Add a "Check for updates" link to the plugin's row on the Plugins screen.
	 *
	 * Core only re-checks for updates every 12 hours. This gives a way to see a
	 * just-published release immediately, without waiting or clearing anything by hand.
	 *
	 * @param array  $links Existing row meta links.
	 * @param string $file  Plugin basename for the row being rendered.
	 * @return array
	 */
	public function row_meta( $links, $file ) {
		if ( $file !== $this->basename || ! current_user_can( 'update_plugins' ) ) {
			return $links;
		}

		$url = wp_nonce_url(
			add_query_arg( 'axon_check_update', '1', admin_url( 'plugins.php' ) ),
			'axon_check_update'
		);

		$links[] = '<a href="' . esc_url( $url ) . '">Check for updates</a>';

		return $links;
	}

	/**
	 * Handle the manual "Check for updates" click.
	 */
	public function handle_manual_check() {
		if ( empty( $_GET['axon_check_update'] ) ) {
			return;
		}
		if ( ! current_user_can( 'update_plugins' ) ) {
			return;
		}
		if ( ! check_admin_referer( 'axon_check_update' ) ) {
			return;
		}

		delete_transient( $this->cache_key );
		$manifest = $this->get_manifest( true );

		// Dropping the update transient makes core rebuild it on the next screen, which
		// re-runs inject_update() against the manifest we just re-fetched.
		delete_site_transient( 'update_plugins' );

		$notice = null === $manifest
			? 'axon-update-failed'
			: ( version_compare( $manifest['version'], $this->version, '>' ) ? 'axon-update-found' : 'axon-update-current' );

		wp_safe_redirect( add_query_arg( 'axon_notice', $notice, admin_url( 'plugins.php' ) ) );
		exit;
	}

	/**
	 * Version string this updater considers installed.
	 *
	 * @return string
	 */
	public function get_version() {
		return $this->version;
	}

	/**
	 * Everything needed to answer "why isn't my update showing?".
	 *
	 * Until this existed, a failed update check was completely invisible: the Plugins screen
	 * simply said nothing, and there was no way to tell a genuinely current install from a
	 * site that could not reach the update server at all. That is a bad experience for an
	 * operator and an unanswerable support ticket for whoever sells the plugin.
	 *
	 * This deliberately performs a LIVE fetch, bypassing the cache, and reports the real HTTP
	 * result including the error message. It is only ever called from the admin screen, on
	 * demand, so the cost is paid by the person asking the question.
	 *
	 * @return array<string, mixed>
	 */
	public function diagnostics() {
		$out = array(
			'installed'    => $this->version,
			'manifest_url' => $this->manifest_url,
			'last_checked' => '',
			'reachable'    => false,
			'server_says'  => '',
			'update_ready' => false,
			'problem'      => '',
			'fix'          => '',
		);

		$fetched_at = (int) get_transient( $this->cache_key . '_at' );
		if ( $fetched_at ) {
			$out['last_checked'] = human_time_diff( $fetched_at ) . ' ago';
		}

		$args = array(
			'timeout'    => 15,
			'user-agent' => 'Axon/' . $this->version . '; ' . home_url( '/' ),
			'headers'    => array( 'Accept' => 'application/json' ),
		);

		$response = wp_remote_get( add_query_arg( 'ts', time(), $this->manifest_url ), $args );

		if ( is_wp_error( $response ) ) {
			$out['problem'] = 'This server could not reach the update server: ' . $response->get_error_message();
			$out['fix']     = 'Outbound HTTPS to raw.githubusercontent.com is being blocked, usually by a host firewall or a security plugin. Ask your host to allow it. Updates by manual upload keep working in the meantime.';

			return $out;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );

		if ( 200 !== $code ) {
			$out['problem'] = sprintf( 'The update server answered with HTTP %d instead of 200.', $code );
			$out['fix']     = 'If this persists, the release channel may have moved. Re-download the plugin manually.';

			return $out;
		}

		$data = json_decode( (string) wp_remote_retrieve_body( $response ), true );

		if ( ! is_array( $data ) || empty( $data['version'] ) ) {
			$out['problem'] = 'The update server replied, but not with a valid manifest.';
			$out['fix']     = 'Something is intercepting the request — a proxy or a captive portal returning an HTML error page. Check with your host.';

			return $out;
		}

		$out['reachable']   = true;
		$out['server_says'] = (string) $data['version'];
		$out['update_ready'] = version_compare( $data['version'], $this->version, '>' );

		if ( ! $out['update_ready'] ) {
			return $out;
		}

		// A newer version exists and this site can see it — so anything still hiding the
		// update is WordPress's own cached answer, not a connectivity problem.
		$out['problem'] = sprintf( 'Version %s is available but WordPress has not picked it up yet.', $data['version'] );
		$out['fix']     = 'Use the "Check for updates" link on the Plugins screen, which clears both caches. If it still does not appear, install the download below manually.';

		return $out;
	}
}
