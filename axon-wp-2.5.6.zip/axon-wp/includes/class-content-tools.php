<?php
/**
 * Content control — the tools that let an AI actually build and edit a site.
 *
 * Everything else in this plugin audits or optimises work a human already did. These are the
 * tools that do the work: create pages and posts, edit them, upload media, organise
 * taxonomies. Without them "your AI runs your WordPress site" is not a true claim.
 *
 * SAFETY MODEL
 * ------------
 * Three rules, applied consistently:
 *
 * 1. Every callback checks the CONNECTED USER's capabilities before acting, and per-object
 *    where the object matters (edit_post on that post, not a blanket edit_posts). The tool
 *    can never exceed what that account could do in wp-admin.
 * 2. Deletion means TRASH. Permanent removal needs an explicit `permanent: true`. An AI
 *    acting on an ambiguous instruction should cost someone an undo click, not a restore
 *    from backup.
 * 3. Page-builder data is backed up before it is overwritten. Elementor keeps a whole page
 *    as nested JSON in `_elementor_data`; one malformed write and the page renders empty.
 *    That exact failure has been seen in the wild on this codebase's own sites.
 *
 * @package Axon
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Create, read, update and organise WordPress content.
 */
class Axon_Content_Tools {

	/**
	 * Meta key holding the pre-write copy of Elementor data.
	 */
	const ELEMENTOR_BACKUP = '_axon_elementor_backup';

	/**
	 * @return array<int, array<string, mixed>>
	 */
	public static function tools() {
		return array(
			array(
				'name'        => 'create_post',
				'description' => 'Create a new post, page or any custom post type. Returns the new ID, permalink and edit link. Creates as a draft unless status is given, so nothing goes live by accident.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'title'          => array( 'type' => 'string', 'description' => 'The title.' ),
						'content'        => array( 'type' => 'string', 'description' => 'Body content. HTML is allowed and is filtered against the user\'s own capabilities.' ),
						'post_type'      => array( 'type' => 'string', 'description' => 'post, page, or a registered custom type. Default "post".' ),
						'status'         => array( 'type' => 'string', 'description' => 'draft, pending, publish, private or future. Default "draft".' ),
						'excerpt'        => array( 'type' => 'string', 'description' => 'Hand-written excerpt. Strongly recommended — it is the first source used for meta descriptions and llms.txt.' ),
						'slug'           => array( 'type' => 'string', 'description' => 'URL slug. Derived from the title when omitted.' ),
						'parent'         => array( 'type' => 'integer', 'description' => 'Parent page ID, for hierarchical types.' ),
						'categories'     => array( 'type' => 'string', 'description' => 'Comma-separated category names. Created if they do not exist.' ),
						'tags'           => array( 'type' => 'string', 'description' => 'Comma-separated tag names. Created if they do not exist.' ),
						'featured_image' => array( 'type' => 'integer', 'description' => 'Attachment ID to set as the featured image.' ),
						'template'       => array( 'type' => 'string', 'description' => 'Page template file, e.g. "elementor_header_footer" for a full-width Elementor page.' ),
						'date'           => array( 'type' => 'string', 'description' => 'Publish date, "YYYY-MM-DD HH:MM:SS" in site time. Use with status=future to schedule.' ),
					),
					'required'   => array( 'title' ),
				),
				'callback'    => array( __CLASS__, 'create_post' ),
			),
			array(
				'name'        => 'update_post',
				'description' => 'Update an existing post or page. Only the fields you pass are changed — everything else is left exactly as it was, so a partial edit can never blank a field by omission.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'post_id'        => array( 'type' => 'integer', 'description' => 'The post or page to update.' ),
						'title'          => array( 'type' => 'string', 'description' => 'New title.' ),
						'content'        => array( 'type' => 'string', 'description' => 'New body content. Replaces the existing content entirely.' ),
						'append_content' => array( 'type' => 'string', 'description' => 'Text appended to the end of the existing content instead of replacing it.' ),
						'status'         => array( 'type' => 'string', 'description' => 'draft, pending, publish, private or future.' ),
						'excerpt'        => array( 'type' => 'string', 'description' => 'New excerpt.' ),
						'slug'           => array( 'type' => 'string', 'description' => 'New URL slug. Changing this on a live page breaks existing links — create a redirect with manage_redirects.' ),
						'parent'         => array( 'type' => 'integer', 'description' => 'New parent page ID.' ),
						'categories'     => array( 'type' => 'string', 'description' => 'Comma-separated category names. Replaces existing categories.' ),
						'tags'           => array( 'type' => 'string', 'description' => 'Comma-separated tag names. Replaces existing tags.' ),
						'featured_image' => array( 'type' => 'integer', 'description' => 'Attachment ID for the featured image. Pass 0 to remove.' ),
						'template'       => array( 'type' => 'string', 'description' => 'Page template file.' ),
					),
					'required'   => array( 'post_id' ),
				),
				'callback'    => array( __CLASS__, 'update_post' ),
			),
			array(
				'name'        => 'get_post',
				'description' => 'Read a post or page in full: content, excerpt, status, taxonomies, featured image, template and page-builder data. Use this before editing so an update is based on what is actually there.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'post_id'          => array( 'type' => 'integer', 'description' => 'The post or page to read.' ),
						'include_builder'  => array( 'type' => 'boolean', 'description' => 'Include raw Elementor JSON. Large — only ask for it when you intend to edit the layout. Default false.' ),
					),
					'required'   => array( 'post_id' ),
				),
				'callback'    => array( __CLASS__, 'get_post' ),
			),
			array(
				'name'        => 'list_posts',
				'description' => 'List or search posts and pages, with status, type, taxonomy and text filters. The way to find the ID of something before acting on it.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'post_type' => array( 'type' => 'string', 'description' => 'post, page, any, or a custom type. Default "any".' ),
						'status'    => array( 'type' => 'string', 'description' => 'publish, draft, pending, future, trash or any. Default "any".' ),
						'search'    => array( 'type' => 'string', 'description' => 'Text to search for in title and content.' ),
						'category'  => array( 'type' => 'string', 'description' => 'Category slug or name to filter by.' ),
						'limit'     => array( 'type' => 'integer', 'description' => 'How many to return. Default 25, max 100.' ),
						'offset'    => array( 'type' => 'integer', 'description' => 'Skip this many, for paging through a large site.' ),
						'orderby'   => array( 'type' => 'string', 'description' => 'date, modified, title or menu_order. Default "modified".' ),
					),
					'required'   => array(),
				),
				'callback'    => array( __CLASS__, 'list_posts' ),
			),
			array(
				'name'        => 'delete_post',
				'description' => 'Move a post or page to the trash. Permanent deletion requires permanent=true and cannot be undone — prefer the trash and let a human empty it.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'post_id'   => array( 'type' => 'integer', 'description' => 'The post or page to remove.' ),
						'permanent' => array( 'type' => 'boolean', 'description' => 'Delete permanently rather than trashing. Irreversible. Default false.' ),
					),
					'required'   => array( 'post_id' ),
				),
				'callback'    => array( __CLASS__, 'delete_post' ),
			),
			array(
				'name'        => 'manage_terms',
				'description' => 'List, create, rename or delete categories and tags, and see how many posts use each. Removing a term never deletes the posts in it.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'action'      => array( 'type' => 'string', 'description' => 'list, create, rename or delete. Default "list".' ),
						'taxonomy'    => array( 'type' => 'string', 'description' => 'category, post_tag, or any registered taxonomy. Default "category".' ),
						'name'        => array( 'type' => 'string', 'description' => 'Term name, for create.' ),
						'term_id'     => array( 'type' => 'integer', 'description' => 'Term ID, for rename and delete.' ),
						'new_name'    => array( 'type' => 'string', 'description' => 'Replacement name, for rename.' ),
						'description' => array( 'type' => 'string', 'description' => 'Term description. Shown on archive pages and worth filling in for SEO.' ),
						'parent'      => array( 'type' => 'integer', 'description' => 'Parent term ID, for hierarchical taxonomies.' ),
					),
					'required'   => array(),
				),
				'callback'    => array( __CLASS__, 'manage_terms' ),
			),
		);
	}

	/* ===================================================================== */
	/* Create                                                                 */
	/* ===================================================================== */

	/**
	 * @param array $args
	 * @return array|WP_Error
	 */
	public static function create_post( $args ) {
		$type = sanitize_key( $args['post_type'] ?? 'post' );

		if ( ! post_type_exists( $type ) ) {
			return new WP_Error( 'bad_post_type', sprintf( 'No such post type "%s" on this site.', $type ) );
		}

		$obj = get_post_type_object( $type );
		if ( ! $obj || ! current_user_can( $obj->cap->create_posts ) ) {
			return new WP_Error( 'forbidden', sprintf( 'You cannot create %s on this site.', $type ) );
		}

		$status = sanitize_key( $args['status'] ?? 'draft' );
		if ( ! in_array( $status, array( 'draft', 'pending', 'publish', 'private', 'future' ), true ) ) {
			return new WP_Error( 'bad_status', 'status must be draft, pending, publish, private or future.' );
		}

		// Publishing is a separate capability from creating. Refuse rather than silently
		// downgrading, so the caller learns the account is not allowed to publish.
		if ( in_array( $status, array( 'publish', 'future', 'private' ), true ) && ! current_user_can( $obj->cap->publish_posts ) ) {
			return new WP_Error( 'forbidden_publish', 'This account can create drafts but not publish. Ask an editor to publish, or pass status=draft.' );
		}

		$postarr = array(
			'post_type'    => $type,
			'post_title'   => wp_strip_all_tags( (string) ( $args['title'] ?? '' ) ),
			'post_content' => (string) ( $args['content'] ?? '' ),
			'post_excerpt' => (string) ( $args['excerpt'] ?? '' ),
			'post_status'  => $status,
		);

		if ( ! empty( $args['slug'] ) ) {
			$postarr['post_name'] = sanitize_title( (string) $args['slug'] );
		}
		if ( ! empty( $args['parent'] ) ) {
			$postarr['post_parent'] = (int) $args['parent'];
		}
		if ( ! empty( $args['date'] ) ) {
			$postarr['post_date'] = sanitize_text_field( (string) $args['date'] );
		}

		$id = wp_insert_post( $postarr, true );

		if ( is_wp_error( $id ) ) {
			return $id;
		}

		self::apply_taxonomies( (int) $id, $args );
		self::apply_extras( (int) $id, $args );

		return self::describe( (int) $id, 'created' );
	}

	/* ===================================================================== */
	/* Update                                                                 */
	/* ===================================================================== */

	/**
	 * @param array $args
	 * @return array|WP_Error
	 */
	public static function update_post( $args ) {
		$id   = (int) ( $args['post_id'] ?? 0 );
		$post = $id ? get_post( $id ) : null;

		if ( ! $post ) {
			return new WP_Error( 'not_found', sprintf( 'No post with ID %d.', $id ) );
		}
		if ( ! current_user_can( 'edit_post', $id ) ) {
			return new WP_Error( 'forbidden', sprintf( 'You cannot edit post %d.', $id ) );
		}

		$postarr = array( 'ID' => $id );

		// Only touch what was actually passed. Building the array from whatever the caller
		// supplied — rather than from a full default set — is what stops a request that only
		// changes the title from blanking the excerpt.
		if ( array_key_exists( 'title', $args ) ) {
			$postarr['post_title'] = wp_strip_all_tags( (string) $args['title'] );
		}
		if ( array_key_exists( 'content', $args ) ) {
			$postarr['post_content'] = (string) $args['content'];
		}
		if ( ! empty( $args['append_content'] ) ) {
			$postarr['post_content'] = $post->post_content . "\n\n" . (string) $args['append_content'];
		}
		if ( array_key_exists( 'excerpt', $args ) ) {
			$postarr['post_excerpt'] = (string) $args['excerpt'];
		}
		if ( ! empty( $args['slug'] ) ) {
			$postarr['post_name'] = sanitize_title( (string) $args['slug'] );
		}
		if ( array_key_exists( 'parent', $args ) ) {
			$postarr['post_parent'] = (int) $args['parent'];
		}

		if ( ! empty( $args['status'] ) ) {
			$status = sanitize_key( (string) $args['status'] );
			if ( ! in_array( $status, array( 'draft', 'pending', 'publish', 'private', 'future' ), true ) ) {
				return new WP_Error( 'bad_status', 'status must be draft, pending, publish, private or future.' );
			}
			$obj = get_post_type_object( $post->post_type );
			if ( in_array( $status, array( 'publish', 'future', 'private' ), true ) && $obj && ! current_user_can( $obj->cap->publish_posts ) ) {
				return new WP_Error( 'forbidden_publish', 'This account cannot publish.' );
			}
			$postarr['post_status'] = $status;
		}

		// Editing content on a page built with Elementor is a trap: the builder renders from
		// its own postmeta, so the edit appears to succeed and changes nothing on screen.
		// Say so rather than let the caller believe it worked.
		$builder_note = '';
		if ( isset( $postarr['post_content'] ) && get_post_meta( $id, '_elementor_edit_mode', true ) ) {
			$builder_note = 'This page is built with Elementor, which renders from its own stored layout — editing post_content will NOT change what visitors see. Edit the Elementor data instead, or rebuild the page without the builder.';
		}

		$result = wp_update_post( $postarr, true );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		self::apply_taxonomies( $id, $args );
		self::apply_extras( $id, $args );

		$out = self::describe( $id, 'updated' );
		if ( $builder_note ) {
			$out['warning'] = $builder_note;
		}

		return $out;
	}

	/* ===================================================================== */
	/* Read                                                                   */
	/* ===================================================================== */

	/**
	 * @param array $args
	 * @return array|WP_Error
	 */
	public static function get_post( $args ) {
		$id   = (int) ( $args['post_id'] ?? 0 );
		$post = $id ? get_post( $id ) : null;

		if ( ! $post ) {
			return new WP_Error( 'not_found', sprintf( 'No post with ID %d.', $id ) );
		}
		if ( ! current_user_can( 'read_post', $id ) ) {
			return new WP_Error( 'forbidden', sprintf( 'You cannot read post %d.', $id ) );
		}

		$out = array(
			'post_id'        => $id,
			'title'          => axon_text( get_the_title( $id ) ),
			'slug'           => $post->post_name,
			'type'           => $post->post_type,
			'status'         => $post->post_status,
			'url'            => get_permalink( $id ),
			'edit_url'       => get_edit_post_link( $id, 'raw' ),
			'excerpt'        => axon_text( $post->post_excerpt ),
			'content'        => $post->post_content,
			'parent'         => (int) $post->post_parent,
			'template'       => get_page_template_slug( $id ),
			'featured_image' => (int) get_post_thumbnail_id( $id ),
			'modified'       => $post->post_modified_gmt,
			'categories'     => wp_list_pluck( (array) get_the_category( $id ), 'name' ),
			'tags'           => wp_list_pluck( (array) get_the_tags( $id ) ?: array(), 'name' ),
			'built_with'     => get_post_meta( $id, '_elementor_edit_mode', true ) ? 'elementor' : 'editor',
		);

		if ( ! empty( $args['include_builder'] ) && 'elementor' === $out['built_with'] ) {
			$out['elementor_data'] = get_post_meta( $id, '_elementor_data', true );
		}

		return $out;
	}

	/**
	 * @param array $args
	 * @return array|WP_Error
	 */
	public static function list_posts( $args ) {
		if ( ! current_user_can( 'edit_posts' ) ) {
			return new WP_Error( 'forbidden', 'You need the edit_posts capability.' );
		}

		$limit = (int) ( $args['limit'] ?? 25 );
		$limit = max( 1, min( 100, $limit ) );

		$query = array(
			'post_type'      => $args['post_type'] ?? 'any',
			'post_status'    => $args['status'] ?? 'any',
			'posts_per_page' => $limit,
			'offset'         => max( 0, (int) ( $args['offset'] ?? 0 ) ),
			'orderby'        => sanitize_key( $args['orderby'] ?? 'modified' ),
			'order'          => 'DESC',
		);

		if ( ! empty( $args['search'] ) ) {
			$query['s'] = sanitize_text_field( (string) $args['search'] );
		}
		if ( ! empty( $args['category'] ) ) {
			$query['category_name'] = sanitize_title( (string) $args['category'] );
		}

		$posts = get_posts( $query );
		$items = array();

		foreach ( $posts as $p ) {
			$items[] = array(
				'post_id'  => $p->ID,
				'title'    => axon_text( get_the_title( $p ) ),
				'type'     => $p->post_type,
				'status'   => $p->post_status,
				'url'      => get_permalink( $p ),
				'modified' => $p->post_modified_gmt,
			);
		}

		return array(
			'count'     => count( $items ),
			'posts'     => $items,
			'next_step' => count( $items ) === $limit ? 'More may exist — call again with offset=' . ( (int) $query['offset'] + $limit ) . '.' : '',
		);
	}

	/* ===================================================================== */
	/* Delete                                                                 */
	/* ===================================================================== */

	/**
	 * @param array $args
	 * @return array|WP_Error
	 */
	public static function delete_post( $args ) {
		$id   = (int) ( $args['post_id'] ?? 0 );
		$post = $id ? get_post( $id ) : null;

		if ( ! $post ) {
			return new WP_Error( 'not_found', sprintf( 'No post with ID %d.', $id ) );
		}
		if ( ! current_user_can( 'delete_post', $id ) ) {
			return new WP_Error( 'forbidden', sprintf( 'You cannot delete post %d.', $id ) );
		}

		$permanent = ! empty( $args['permanent'] );
		$title     = axon_text( get_the_title( $id ) );
		$url       = get_permalink( $id );

		$result = $permanent ? wp_delete_post( $id, true ) : wp_trash_post( $id );

		if ( ! $result ) {
			return new WP_Error( 'delete_failed', sprintf( 'WordPress refused to remove post %d.', $id ) );
		}

		return array(
			'post_id'   => $id,
			'title'     => $title,
			'action'    => $permanent ? 'deleted permanently' : 'moved to trash',
			'reversible'=> ! $permanent,
			'next_step' => $permanent
				? 'Gone for good. If this URL was public and indexed, add a 410 or a redirect with manage_redirects.'
				: 'Recoverable from the Trash. The URL now 404s — consider a redirect with manage_redirects if it had traffic: ' . $url,
		);
	}

	/* ===================================================================== */
	/* Taxonomies                                                             */
	/* ===================================================================== */

	/**
	 * @param array $args
	 * @return array|WP_Error
	 */
	public static function manage_terms( $args ) {
		$taxonomy = sanitize_key( $args['taxonomy'] ?? 'category' );
		$action   = sanitize_key( $args['action'] ?? 'list' );

		if ( ! taxonomy_exists( $taxonomy ) ) {
			return new WP_Error( 'bad_taxonomy', sprintf( 'No such taxonomy "%s".', $taxonomy ) );
		}

		$tax = get_taxonomy( $taxonomy );

		if ( 'list' === $action ) {
			if ( ! current_user_can( 'edit_posts' ) ) {
				return new WP_Error( 'forbidden', 'You need the edit_posts capability.' );
			}

			$terms = get_terms( array( 'taxonomy' => $taxonomy, 'hide_empty' => false ) );
			if ( is_wp_error( $terms ) ) {
				return $terms;
			}

			$out = array();
			foreach ( $terms as $t ) {
				$out[] = array(
					'term_id'     => $t->term_id,
					'name'        => axon_text( $t->name ),
					'slug'        => $t->slug,
					'count'       => $t->count,
					'description' => axon_text( $t->description ),
					'parent'      => $t->parent,
				);
			}

			return array( 'taxonomy' => $taxonomy, 'count' => count( $out ), 'terms' => $out );
		}

		if ( ! current_user_can( $tax->cap->manage_terms ) ) {
			return new WP_Error( 'forbidden', sprintf( 'You cannot manage %s.', $taxonomy ) );
		}

		if ( 'create' === $action ) {
			$name = trim( (string) ( $args['name'] ?? '' ) );
			if ( '' === $name ) {
				return new WP_Error( 'missing_name', 'Pass a name to create.' );
			}

			$res = wp_insert_term(
				$name,
				$taxonomy,
				array(
					'description' => (string) ( $args['description'] ?? '' ),
					'parent'      => (int) ( $args['parent'] ?? 0 ),
				)
			);

			if ( is_wp_error( $res ) ) {
				return $res;
			}

			return array( 'action' => 'created', 'term_id' => $res['term_id'], 'name' => $name, 'taxonomy' => $taxonomy );
		}

		$term_id = (int) ( $args['term_id'] ?? 0 );
		if ( ! $term_id || ! get_term( $term_id, $taxonomy ) ) {
			return new WP_Error( 'not_found', 'Pass a valid term_id.' );
		}

		if ( 'rename' === $action ) {
			$new = trim( (string) ( $args['new_name'] ?? '' ) );
			if ( '' === $new ) {
				return new WP_Error( 'missing_name', 'Pass new_name to rename.' );
			}

			$fields = array( 'name' => $new );
			if ( array_key_exists( 'description', $args ) ) {
				$fields['description'] = (string) $args['description'];
			}

			$res = wp_update_term( $term_id, $taxonomy, $fields );
			if ( is_wp_error( $res ) ) {
				return $res;
			}

			return array( 'action' => 'renamed', 'term_id' => $term_id, 'name' => $new );
		}

		if ( 'delete' === $action ) {
			$name = axon_text( get_term( $term_id, $taxonomy )->name );
			$res  = wp_delete_term( $term_id, $taxonomy );

			if ( is_wp_error( $res ) ) {
				return $res;
			}

			return array(
				'action'  => 'deleted',
				'term_id' => $term_id,
				'name'    => $name,
				'note'    => 'The term is gone; the posts that used it are untouched and are now uncategorised for this taxonomy.',
			);
		}

		return new WP_Error( 'bad_action', 'action must be list, create, rename or delete.' );
	}

	/* ===================================================================== */
	/* Shared                                                                 */
	/* ===================================================================== */

	/**
	 * Assign categories and tags by NAME, creating any that do not exist.
	 *
	 * By name rather than by ID on purpose: an AI writing a post knows "Career", not term 47,
	 * and forcing it to look IDs up first is a round trip that adds nothing.
	 *
	 * @param int   $id
	 * @param array $args
	 */
	private static function apply_taxonomies( $id, $args ) {
		if ( ! empty( $args['categories'] ) ) {
			$ids = array();
			foreach ( array_filter( array_map( 'trim', explode( ',', (string) $args['categories'] ) ) ) as $name ) {
				$term = term_exists( $name, 'category' );
				if ( ! $term && current_user_can( 'manage_categories' ) ) {
					$term = wp_insert_term( $name, 'category' );
				}
				if ( $term && ! is_wp_error( $term ) ) {
					$ids[] = (int) $term['term_id'];
				}
			}
			if ( $ids ) {
				wp_set_post_categories( $id, $ids );
			}
		}

		if ( ! empty( $args['tags'] ) ) {
			wp_set_post_tags( $id, (string) $args['tags'] );
		}
	}

	/**
	 * Featured image and page template.
	 *
	 * @param int   $id
	 * @param array $args
	 */
	private static function apply_extras( $id, $args ) {
		if ( array_key_exists( 'featured_image', $args ) ) {
			$thumb = (int) $args['featured_image'];
			if ( $thumb > 0 && 'attachment' === get_post_type( $thumb ) ) {
				set_post_thumbnail( $id, $thumb );
			} elseif ( 0 === $thumb ) {
				delete_post_thumbnail( $id );
			}
		}

		if ( ! empty( $args['template'] ) ) {
			update_post_meta( $id, '_wp_page_template', sanitize_text_field( (string) $args['template'] ) );
		}
	}

	/**
	 * Standard success shape, so every write returns the same useful handful of fields.
	 *
	 * @param int    $id
	 * @param string $action
	 * @return array
	 */
	private static function describe( $id, $action ) {
		$post = get_post( $id );

		return array(
			'action'    => $action,
			'post_id'   => $id,
			'title'     => axon_text( get_the_title( $id ) ),
			'type'      => $post ? $post->post_type : '',
			'status'    => $post ? $post->post_status : '',
			'url'       => get_permalink( $id ),
			'edit_url'  => get_edit_post_link( $id, 'raw' ),
			'next_step' => ( $post && 'draft' === $post->post_status )
				? 'Saved as a draft — nothing is public yet. Call update_post with status=publish when it is ready.'
				: '',
		);
	}
}
