<?php
/**
 * GEO / AEO — Generative Engine & Answer Engine Optimisation.
 *
 * Classic SEO asks "will this rank?". This asks "will ChatGPT, Perplexity, Google AI
 * Overviews and Claude quote this page, and will they attribute it to us?". The answers
 * turn on different things: whether AI crawlers are allowed in at all, whether the page
 * states answers in extractable passages rather than burying them, whether structured
 * data explains what the page is, and whether an /llms.txt exists to orient a model.
 *
 * Tools:
 *   audit_ai_crawlers   - which AI bots robots.txt lets in (the silent killer)
 *   audit_ai_readiness  - per-page citability scoring
 *   generate_llms_txt   - build and serve /llms.txt
 *   find_orphan_pages   - pages nothing links to (Elementor-aware)
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Axon_GEO_Tools {

	const LLMS_OPTION = 'axon_llms_txt';

	/**
	 * The crawlers that actually matter for AI visibility, and what blocking each costs.
	 *
	 * Google-Extended is the one people get wrong most often: blocking it does NOT affect
	 * normal Google Search ranking, but it does remove you from AI Overviews and Gemini.
	 *
	 * @var array<string, string>
	 */
	const AI_CRAWLERS = array(
		'GPTBot'             => 'OpenAI training crawler — feeds ChatGPT’s model knowledge.',
		'OAI-SearchBot'      => 'OpenAI search index — powers ChatGPT Search results and citations.',
		'ChatGPT-User'       => 'Fetches your page live when a ChatGPT user asks about it. Blocking this stops real-time citation.',
		'ClaudeBot'          => 'Anthropic crawler for Claude.',
		'Claude-User'        => 'Live fetch when a Claude user follows a link to your site.',
		'PerplexityBot'      => 'Perplexity index — Perplexity cites sources heavily, so this is high value.',
		'Google-Extended'    => 'Controls Gemini and Google AI Overviews ONLY. Blocking it does not affect normal Google Search ranking.',
		'CCBot'              => 'Common Crawl — the base dataset behind many open models.',
		'Applebot-Extended'  => 'Apple Intelligence.',
		'meta-externalagent' => 'Meta AI.',
		'Bytespider'         => 'ByteDance/TikTok. Aggressive crawler — blocking this one is often reasonable.',
	);

	/**
	 * @return array<int, array<string, mixed>>
	 */
	public static function tools() {
		return array(
			array(
				'name'        => 'audit_ai_crawlers',
				'description' => 'Check robots.txt to see which AI crawlers (GPTBot, ClaudeBot, PerplexityBot, Google-Extended, etc.) can reach this site. Blocking these is the most common reason a site never gets cited in ChatGPT, Perplexity or Google AI Overviews — and it is usually accidental. Read-only.',
				'inputSchema' => array( 'type' => 'object', 'properties' => new stdClass(), 'required' => array() ),
				'callback'    => array( __CLASS__, 'audit_ai_crawlers' ),
			),
			array(
				'name'        => 'audit_ai_readiness',
				'description' => 'Score how quotable a page is for AI answer engines: passage extractability, question-shaped headings, direct answers, lists and tables, structured data, author and date signals, and outbound citations. Returns a 0-100 score with specific fixes. Read-only.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'post_id' => array(
							'type'        => 'integer',
							'description' => 'Post or page ID to score. Omit to score the most recently modified published content.',
						),
						'limit'   => array(
							'type'        => 'integer',
							'description' => 'When post_id is omitted, how many recent items to score. Default 10, max 50.',
						),
					),
					'required'   => array(),
				),
				'callback'    => array( __CLASS__, 'audit_ai_readiness' ),
			),
			array(
				'name'        => 'generate_llms_txt',
				'description' => 'Build an /llms.txt file — the emerging standard that tells AI models what a site is about and which pages matter. Generates from real site structure. Pass save=true to store and serve it at /llms.txt.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'save'        => array(
							'type'        => 'boolean',
							'description' => 'Store the generated file and serve it at /llms.txt. Default false (preview only).',
						),
						'description' => array(
							'type'        => 'string',
							'description' => 'One-line description of the organisation. Falls back to the site tagline.',
						),
						'max_pages'   => array(
							'type'        => 'integer',
							'description' => 'How many pages to list. Default 40.',
						),
					),
					'required'   => array(),
				),
				'callback'    => array( __CLASS__, 'generate_llms_txt' ),
			),
			array(
				'name'        => 'find_orphan_pages',
				'description' => 'Find published pages and posts that no other content links to. Orphans are hard for crawlers to discover and read as low-importance to both search and AI engines. Understands Elementor page data, not just the classic editor. Read-only.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'post_types' => array(
							'type'        => 'string',
							'description' => 'Comma-separated post types to check. Default "page,post".',
						),
					),
					'required'   => array(),
				),
				'callback'    => array( __CLASS__, 'find_orphan_pages' ),
			),
		);
	}

	/* ===================================================================== */
	/* AI crawlers                                                            */
	/* ===================================================================== */

	/**
	 * @return array|WP_Error
	 */
	public static function audit_ai_crawlers() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'forbidden', 'You need the manage_options capability.' );
		}

		$res = wp_remote_get( home_url( '/robots.txt' ), array( 'timeout' => 10, 'sslverify' => false ) );
		if ( is_wp_error( $res ) ) {
			return new WP_Error( 'robots_unreachable', 'Could not fetch robots.txt: ' . $res->get_error_message() );
		}
		$robots = (string) wp_remote_retrieve_body( $res );

		$rules   = self::parse_robots( $robots );
		$blocked = array();
		$allowed = array();

		foreach ( self::AI_CRAWLERS as $bot => $why ) {
			$disallowed = self::is_blocked( $rules, $bot );
			$entry      = array( 'crawler' => $bot, 'purpose' => $why );
			if ( $disallowed ) {
				$blocked[] = $entry;
			} else {
				$allowed[] = $entry;
			}
		}

		$discourage = ! get_option( 'blog_public' );
		$findings   = array();

		if ( $discourage ) {
			$findings[] = array(
				'severity' => 'critical',
				'message'  => 'WordPress is set to discourage search engines (Settings > Reading). This blocks every crawler, AI included. Nothing else here matters until it is switched off.',
			);
		}
		if ( $blocked ) {
			$findings[] = array(
				'severity' => 'critical',
				'message'  => sprintf(
					'%d AI crawler(s) are blocked by robots.txt: %s. These sources cannot cite you.',
					count( $blocked ),
					implode( ', ', wp_list_pluck( $blocked, 'crawler' ) )
				),
			);
		} else {
			$findings[] = array( 'severity' => 'ok', 'message' => 'All major AI crawlers are permitted.' );
		}

		$has_llms = self::llms_txt_live();
		$findings[] = array(
			'severity' => $has_llms ? 'ok' : 'warn',
			'message'  => $has_llms
				? '/llms.txt is present.'
				: 'No /llms.txt. This file tells models what the site is and which pages matter. Run generate_llms_txt.',
		);

		return array(
			'site'            => home_url(),
			'robots_txt_size' => strlen( $robots ),
			'blocked'         => $blocked,
			'allowed'         => $allowed,
			'findings'        => $findings,
			'note'            => 'Blocking Google-Extended removes you from Gemini and AI Overviews but does NOT harm normal Google Search rankings — the two are frequently confused.',
		);
	}

	/**
	 * Minimal robots.txt parser: user-agent group => list of Disallow paths.
	 *
	 * @param string $txt
	 * @return array<string, array<int, string>>
	 */
	private static function parse_robots( $txt ) {
		$rules   = array();
		$current = array();
		foreach ( preg_split( '/\R/', $txt ) as $line ) {
			$line = trim( preg_replace( '/#.*$/', '', $line ) );
			if ( '' === $line ) {
				continue;
			}
			if ( preg_match( '/^user-agent\s*:\s*(.+)$/i', $line, $m ) ) {
				$agent = strtolower( trim( $m[1] ) );
				// Consecutive User-agent lines share one rule block.
				$current                = isset( $pending ) && $pending ? array_merge( $current, array( $agent ) ) : array( $agent );
				$pending                = true;
				$rules[ $agent ]        = $rules[ $agent ] ?? array();
				continue;
			}
			$pending = false;
			if ( preg_match( '/^disallow\s*:\s*(.*)$/i', $line, $m ) ) {
				foreach ( $current as $agent ) {
					$rules[ $agent ][] = trim( $m[1] );
				}
			}
		}
		return $rules;
	}

	/**
	 * Is this bot disallowed from the site root?
	 *
	 * @param array  $rules
	 * @param string $bot
	 * @return bool
	 */
	private static function is_blocked( $rules, $bot ) {
		$bot = strtolower( $bot );
		// A named rule always wins over the wildcard group.
		$paths = $rules[ $bot ] ?? $rules['*'] ?? array();
		foreach ( $paths as $p ) {
			if ( '/' === $p ) {
				return true;
			}
		}
		return false;
	}

	/* ===================================================================== */
	/* Citability scoring                                                     */
	/* ===================================================================== */

	/**
	 * @param array $args
	 * @return array|WP_Error
	 */
	public static function audit_ai_readiness( $args ) {
		if ( ! current_user_can( 'edit_posts' ) ) {
			return new WP_Error( 'forbidden', 'You need the edit_posts capability.' );
		}

		if ( ! empty( $args['post_id'] ) ) {
			$ids = array( absint( $args['post_id'] ) );
		} else {
			$limit = isset( $args['limit'] ) ? min( 50, max( 1, absint( $args['limit'] ) ) ) : 10;
			$ids   = get_posts(
				array(
					'post_type'      => array( 'page', 'post' ),
					'post_status'    => 'publish',
					'posts_per_page' => $limit,
					'orderby'        => 'modified',
					'order'          => 'DESC',
					'fields'         => 'ids',
				)
			);
		}

		$out = array();
		foreach ( $ids as $id ) {
			$scored = self::score_post( (int) $id );
			if ( ! is_wp_error( $scored ) ) {
				$out[] = $scored;
			}
		}

		usort( $out, static fn( $a, $b ) => $a['score'] <=> $b['score'] );

		return array(
			'scored'  => count( $out ),
			'average' => $out ? (int) round( array_sum( wp_list_pluck( $out, 'score' ) ) / count( $out ) ) : 0,
			'pages'   => $out,
			'note'    => 'Score reflects how easy it is for a model to lift a correct, attributable answer from the page. It is not a ranking prediction.',
		);
	}

	/**
	 * @param int $id
	 * @return array|WP_Error
	 */
	private static function score_post( $id ) {
		$post = get_post( $id );
		if ( ! $post || 'publish' !== $post->post_status ) {
			return new WP_Error( 'not_found', "Post {$id} is not a published item." );
		}

		$html = self::rendered_content( $post );
		$text = trim( wp_strip_all_tags( $html ) );
		$words = str_word_count( $text );

		$score  = 0;
		$wins   = array();
		$fixes  = array();

		// --- Substance (20)
		if ( $words >= 600 ) {
			$score += 20;
			$wins[] = "Substantial content ({$words} words).";
		} elseif ( $words >= 300 ) {
			$score += 12;
			$fixes[] = "Only {$words} words. Answer engines prefer pages that cover a topic completely; aim for 600+.";
		} else {
			$fixes[] = "Very thin ({$words} words). Unlikely to be treated as a credible source.";
		}

		// --- Headings, and specifically question-shaped ones (20)
		preg_match_all( '/<h([2-4])[^>]*>(.*?)<\/h\1>/is', $html, $hm );
		$headings  = array_map( 'wp_strip_all_tags', $hm[2] ?? array() );
		$questions = array_filter(
			$headings,
			static fn( $h ) => (bool) preg_match( '/\?\s*$|^(how|what|why|when|where|who|which|can|do|does|is|are|should)\b/i', trim( $h ) )
		);
		if ( count( $headings ) >= 3 ) {
			$score += 10;
			$wins[] = count( $headings ) . ' subheadings give the page clear structure.';
		} else {
			$fixes[] = 'Add H2/H3 subheadings. Models extract answers by section; an unbroken wall of text has no seams to cut along.';
		}
		if ( count( $questions ) >= 2 ) {
			$score += 10;
			$wins[] = count( $questions ) . ' heading(s) are phrased as questions, which maps directly onto how people prompt.';
		} else {
			$fixes[] = 'Phrase some headings as the exact questions people ask ("What is the fee for a hotel management course?"). This is the single highest-leverage AEO change.';
		}

		// --- Passage extractability (20)
		preg_match_all( '/<p[^>]*>(.*?)<\/p>/is', $html, $pm );
		$paras = array_filter( array_map( static fn( $p ) => trim( wp_strip_all_tags( $p ) ), $pm[1] ?? array() ) );
		$lens  = array_map( 'str_word_count', $paras );
		$avg   = $lens ? array_sum( $lens ) / count( $lens ) : 0;
		if ( $paras && $avg <= 80 ) {
			$score += 20;
			$wins[] = sprintf( 'Average paragraph is %d words — short enough to quote as a standalone passage.', $avg );
		} elseif ( $avg <= 120 ) {
			$score += 10;
			$fixes[] = sprintf( 'Paragraphs average %d words. Break them up; 40-80 words is the sweet spot for a liftable passage.', $avg );
		} else {
			$fixes[] = sprintf( 'Paragraphs average %d words — too long to quote cleanly. Split them.', $avg );
		}

		// --- Lists and tables (10)
		$lists  = preg_match_all( '/<(ul|ol|table)[^>]*>/i', $html );
		if ( $lists > 0 ) {
			$score += 10;
			$wins[] = "{$lists} list/table block(s) — highly extractable formats.";
		} else {
			$fixes[] = 'No lists or tables. Steps, comparisons and specifications get quoted far more when structured.';
		}

		// --- Structured data (15)
		$schema = self::detect_schema( $id );
		if ( $schema ) {
			$score += 15;
			$wins[] = 'Structured data present: ' . implode( ', ', $schema ) . '.';
		} else {
			$fixes[] = 'No JSON-LD structured data detected. FAQPage and Article schema tell a model what the page IS, not just what it says.';
		}

		// --- Trust signals (15)
		$author = get_the_author_meta( 'display_name', (int) $post->post_author );
		$bio    = get_the_author_meta( 'description', (int) $post->post_author );
		$t      = 0;
		if ( $author ) {
			$t += 5;
		}
		if ( $bio ) {
			$t += 5;
			$wins[] = 'Author bio present — a real E-E-A-T signal.';
		} else {
			$fixes[] = 'Author has no bio. Answer engines weight identifiable expertise heavily.';
		}
		if ( preg_match( '/<a[^>]+href=["\']https?:\/\/(?!' . preg_quote( wp_parse_url( home_url(), PHP_URL_HOST ), '/' ) . ')/i', $html ) ) {
			$t += 5;
			$wins[] = 'Cites external sources.';
		} else {
			$fixes[] = 'No outbound citations. Referencing authoritative sources raises perceived reliability.';
		}
		$score += $t;

		$age_days = (int) floor( ( time() - strtotime( $post->post_modified_gmt . ' GMT' ) ) / DAY_IN_SECONDS );
		if ( $age_days > 540 ) {
			$fixes[] = "Last updated {$age_days} days ago. Freshness matters disproportionately for AI answers.";
		}

		return array(
			'post_id'       => $id,
			'title'         => axon_text( get_the_title( $id ) ),
			'url'           => get_permalink( $id ),
			'score'         => min( 100, $score ),
			'grade'         => $score >= 80 ? 'A' : ( $score >= 65 ? 'B' : ( $score >= 45 ? 'C' : 'D' ) ),
			'words'         => $words,
			'headings'      => count( $headings ),
			'question_headings' => count( $questions ),
			'schema'        => $schema,
			'days_since_update' => $age_days,
			'strengths'     => $wins,
			'fixes'         => array_values( $fixes ),
		);
	}

	/**
	 * Page HTML including Elementor output.
	 *
	 * Elementor keeps its content in postmeta, so post_content is often empty or a
	 * stub — scoring that alone would report every Elementor page as thin.
	 *
	 * @param WP_Post $post
	 * @return string
	 */
	private static function rendered_content( $post ) {
		$html = (string) $post->post_content;

		if ( class_exists( '\Elementor\Plugin' ) && get_post_meta( $post->ID, '_elementor_edit_mode', true ) ) {
			try {
				$el = \Elementor\Plugin::instance();
				if ( isset( $el->frontend ) && method_exists( $el->frontend, 'get_builder_content' ) ) {
					$built = (string) $el->frontend->get_builder_content( $post->ID, true );
					if ( strlen( $built ) > strlen( $html ) ) {
						return $built;
					}
				}
			} catch ( Exception $e ) {
				// Fall through to whatever we already have.
			}
		}

		return apply_filters( 'the_content', $html );
	}

	/**
	 * Schema types declared for a post, from Rank Math/Yoast meta or inline JSON-LD.
	 *
	 * @param int $id
	 * @return array<int, string>
	 */
	private static function detect_schema( $id ) {
		$types = array();

		foreach ( get_post_meta( $id ) as $key => $vals ) {
			if ( 0 === strpos( $key, 'rank_math_schema_' ) ) {
				$types[] = str_replace( 'rank_math_schema_', '', $key );
			}
		}

		$content = (string) get_post_field( 'post_content', $id );
		if ( preg_match_all( '/"@type"\s*:\s*"([A-Za-z]+)"/', $content, $m ) ) {
			$types = array_merge( $types, $m[1] );
		}

		return array_values( array_unique( array_filter( $types ) ) );
	}

	/* ===================================================================== */
	/* llms.txt                                                               */
	/* ===================================================================== */

	/**
	 * @param array $args
	 * @return array|WP_Error
	 */
	public static function generate_llms_txt( $args ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'forbidden', 'You need the manage_options capability.' );
		}

		$save  = ! empty( $args['save'] );
		$max   = isset( $args['max_pages'] ) ? min( 200, max( 5, absint( $args['max_pages'] ) ) ) : 40;
		$desc  = ! empty( $args['description'] )
			? sanitize_text_field( (string) $args['description'] )
			: (string) get_bloginfo( 'description' );

		$lines   = array();
		$lines[] = '# ' . get_bloginfo( 'name' );
		$lines[] = '';
		if ( $desc ) {
			$lines[] = '> ' . $desc;
			$lines[] = '';
		}
		$lines[] = 'Canonical site: ' . home_url( '/' );
		$lines[] = '';

		$pages = get_posts(
			array(
				'post_type'      => 'page',
				'post_status'    => 'publish',
				'posts_per_page' => $max,
				'orderby'        => 'menu_order title',
				'order'          => 'ASC',
			)
		);
		// A page the owner has hidden from search engines should not be advertised to AI
		// models either.
		$pages = array_values(
			array_filter(
				$pages,
				static function ( $p ) {
					return ! self::is_noindexed( $p->ID );
				}
			)
		);

		if ( $pages ) {
			$lines[] = '## Key pages';
			$lines[] = '';
			foreach ( $pages as $p ) {
				$lines[] = sprintf( '- [%s](%s)%s', self::clean_title( $p ), get_permalink( $p ), self::summary_for( $p ) );
			}
			$lines[] = '';
		}

		$posts = get_posts(
			array(
				'post_type'      => 'post',
				'post_status'    => 'publish',
				'posts_per_page' => 20,
				'orderby'        => 'date',
				'order'          => 'DESC',
			)
		);
		$posts = array_values(
			array_filter(
				$posts,
				static function ( $p ) {
					return ! self::is_noindexed( $p->ID );
				}
			)
		);

		if ( $posts ) {
			$lines[] = '## Recent articles';
			$lines[] = '';
			foreach ( $posts as $p ) {
				$lines[] = sprintf( '- [%s](%s)%s', self::clean_title( $p ), get_permalink( $p ), self::summary_for( $p ) );
			}
			$lines[] = '';
		}

		$lines[] = '## Optional';
		$lines[] = '';
		$lines[] = '- [Sitemap](' . home_url( '/sitemap_index.xml' ) . ')';
		$lines[] = '';

		$content = implode( "\n", $lines );

		if ( $save ) {
			update_option( self::LLMS_OPTION, $content, false );
		}

		return array(
			'saved'      => $save,
			'url'        => $save ? home_url( '/llms.txt' ) : null,
			'bytes'      => strlen( $content ),
			'pages_listed' => count( $pages ) + count( $posts ),
			'content'    => $content,
			'next_step'  => $save
				? 'Serving at /llms.txt. If you use a page cache, purge it.'
				: 'Preview only — re-run with save=true to publish it.',
		);
	}

	/**
	 * Short, clean summary for a listing line.
	 *
	 * @param WP_Post $p
	 * @return string
	 */
	private static function summary_for( $p ) {
		$desc = self::page_description( $p );

		return ( '' === $desc ) ? '' : ': ' . $desc;
	}

	/**
	 * The best available plain-text description of a page.
	 *
	 * PUBLIC and shared on purpose. The schema generator had its own near-copy of this that
	 * checked only Rank Math's meta key, so a page whose description lives in Yoast's key
	 * fell through to raw content and produced "HOMEWHY IIMTCOURSESHotel Management…" as a
	 * Schema.org description — while llms.txt, built from the improved copy, was perfect for
	 * the same page. Two implementations of one idea drift, and the one you are not looking
	 * at is the one that is wrong. There is now a single implementation.
	 *
	 * @param WP_Post $p
	 * @return string Clean description, or '' when nothing trustworthy exists.
	 */
	public static function page_description( $p ) {
		if ( ! $p instanceof WP_Post ) {
			return '';
		}

		// 1. A curated meta description is the one place a human has actually written what
		// this page is about. Rank Math and Yoast both store one. Guessing from content when
		// a real description exists is strictly worse, so this comes first.
		foreach ( array( 'rank_math_description', '_yoast_wpseo_metadesc' ) as $key ) {
			$meta = trim( (string) get_post_meta( $p->ID, $key, true ) );
			if ( '' !== $meta ) {
				return self::clean_text( $meta );
			}
		}

		// 2. A hand-written excerpt is the next most deliberate signal.
		if ( '' !== trim( (string) $p->post_excerpt ) ) {
			return self::clean_text( $p->post_excerpt );
		}

		// 3. Last resort: the content itself. On page-builder sites post_content often holds
		// the WHOLE rendered page — nav menu, breadcrumbs and all — so this needs cleaning
		// and then sanity-checking before it can be trusted.
		$raw = trim( wp_strip_all_tags( strip_shortcodes( (string) $p->post_content ) ) );
		// Decode BEFORE stripping chrome. Breadcrumb separators are stored as `&#8250;`
		// entities, so a pattern looking for the literal `›` silently matches nothing and
		// every breadcrumb survives — which is exactly what shipped in 2.0.2.
		$raw = html_entity_decode( $raw, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		$raw = self::strip_chrome( $raw, $p );

		if ( '' === $raw || self::looks_like_navigation( $raw ) ) {
			// Better to say nothing than to tell an AI model this page is about a menu.
			return '';
		}

		return self::clean_text( $raw );
	}

	/**
	 * Post title with HTML entities decoded.
	 *
	 * get_the_title() returns entity-encoded text destined for HTML. llms.txt is plain text,
	 * so "1 &#038; 2 Year Courses" has to become "1 & 2 Year Courses" or the file reads as
	 * broken output to the very models it is meant to inform.
	 *
	 * @param WP_Post $p
	 * @return string
	 */
	private static function clean_title( $p ) {
		return axon_text( get_the_title( $p ) );
	}

	/**
	 * Normalise and clip a summary for a listing line.
	 *
	 * Entities are decoded because llms.txt is plain text read by a model, not HTML — a raw
	 * `&#8217;` is noise that makes the file look machine-generated and degrades the very
	 * comprehension the file exists to improve.
	 *
	 * @param string $text
	 * @return string
	 */
	private static function trim_summary( $text ) {
		$clean = self::clean_text( $text );

		return ( '' === $clean ) ? '' : ': ' . $clean;
	}

	/**
	 * Normalise and clip text for plain-text or JSON output.
	 *
	 * @param string $text
	 * @return string
	 */
	private static function clean_text( $text ) {
		$text = html_entity_decode( (string) $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		$text = preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $text ) );
		$text = trim( (string) $text );

		if ( '' === $text ) {
			return '';
		}

		// Bare text — the ": " separator belongs to the llms.txt line format and is added by
		// trim_summary(), so callers building JSON get a clean value.
		return rtrim( mb_substr( $text, 0, 160 ), ' .,;:-' );
	}

	/**
	 * Strip leading breadcrumb trails from extracted page text.
	 *
	 * Themes render breadcrumbs before the content, so stripping tags leaves trails like
	 * "Latest Articles Home>Career>Real title starts here". Cutting to the LAST separator
	 * near the start removes the trail without touching prose that merely contains an arrow
	 * later on.
	 *
	 * Expects text with entities already decoded — see the note in summary_for().
	 *
	 * @param string       $text
	 * @param WP_Post|null $p    Post, used to recognise its own title and category.
	 * @return string
	 */
	private static function strip_chrome( $text, $p = null ) {
		$text = preg_replace( '/\s+/u', ' ', (string) $text );

		// Breadcrumb trail: cut to the last separator near the start, so "Home›Career›Real
		// text" loses the trail without touching prose that uses a chevron further along.
		//
		// Only the typographic chevrons count. A bare ">" was tried and had to be removed:
		// it silently mangled legitimate prose like "a range like 5 > 3", turning it into
		// "3 and keeps going". Breadcrumbs render as › or », never as a lone ASCII ">"
		// once tags are stripped, so nothing is lost by being strict here.
		$text = preg_replace( '/^.{0,150}(?:›|»)\s*/u', '', (string) $text );
		$text = trim( (string) $text );

		// Themes print the post title above the body, usually truncated with an ellipsis, so
		// the extracted text tends to open by repeating the title that is already this
		// line's link label. Drop it — but only when it really is the title, and only within
		// the first stretch, so prose that legitimately contains "…" survives.
		if ( $p instanceof WP_Post ) {
			$title = trim( html_entity_decode( axon_text( get_the_title( $p ) ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
			$probe = mb_substr( $title, 0, 25 );

			if ( '' !== $probe && 0 === mb_stripos( $text, $probe ) ) {
				// Themes print the title either truncated ("Long Title…") or in full, so
				// handle both: cut at an early ellipsis if there is one, otherwise remove
				// the exact title prefix.
				$cut = preg_replace( '/^.{0,120}?…\s*/u', '', $text );

				if ( $cut !== $text && '' !== trim( (string) $cut ) ) {
					$text = trim( (string) $cut );
				} elseif ( 0 === mb_stripos( $text, $title ) ) {
					$rest = trim( mb_substr( $text, mb_strlen( $title ) ) );
					if ( '' !== $rest ) {
						$text = $rest;
					}
				}
			}

			// A category label often sits between the title and the body.
			foreach ( (array) get_the_category( $p->ID ) as $cat ) {
				$name = trim( (string) $cat->name );
				if ( '' !== $name && 0 === mb_stripos( $text, $name . ' ' ) ) {
					$text = trim( mb_substr( $text, mb_strlen( $name ) ) );
					break;
				}
			}
		}

		// Post-meta tail. Themes close the excerpt and then print a byline, date and reading
		// time — "…By Jane Doe•19 Jul 2026•5 min read" — immediately followed by the nav
		// menu. Everything from that byline on is chrome, so cut at the first marker.
		$text = preg_replace( '/…\s*By\s.*$/us', '', (string) $text );

		// Bullet-separated meta ("Author•date•5 min read") does not occur in prose, so the
		// first bullet is a reliable end-of-content marker on its own.
		$text = preg_replace( '/\s*•.*$/us', '', (string) $text );

		// A trailing "5 min read" can survive when the theme omits the byline.
		$text = preg_replace( '/\s*\b\d+\s*min read\b.*$/ius', '', (string) $text );

		return trim( rtrim( trim( (string) $text ), '…' ) );
	}

	/**
	 * Detect a run-together navigation menu rather than real content.
	 *
	 * When a page builder stores the whole page in post_content, stripping tags welds menu
	 * items into unbroken tokens: "HOMEWHY IIMTCOURSESHotel ManagementCORPORATEBLOGONLINE".
	 * Two signals give that away and essentially never occur in prose — a long unbroken run
	 * of capitals (menu labels concatenated), and lowercase running straight into uppercase
	 * (one item's end fused to the next item's start).
	 *
	 * Only ever applied to content-derived text, never to a meta description or excerpt, so
	 * a false positive costs at most one missing summary — never a wrong one.
	 *
	 * @param string $text
	 * @return bool
	 */
	private static function looks_like_navigation( $text ) {
		$sample = mb_substr( (string) $text, 0, 160 );

		if ( '' === trim( $sample ) ) {
			return true;
		}

		// 8+ consecutive capitals: real words and acronyms essentially never reach this.
		if ( preg_match( '/[A-Z]{8,}/', $sample ) ) {
			return true;
		}

		// Two or more lower-to-upper collisions means repeated fused menu items, not a
		// stray CamelCase brand name.
		return preg_match_all( '/[a-z]{2}[A-Z]/', $sample ) >= 2;
	}

	/**
	 * Whether a post is marked noindex.
	 *
	 * A page the owner has told search engines to ignore has no business being advertised to
	 * AI models in llms.txt — that is the same instruction, just a different audience. This
	 * is what keeps drafts-in-disguise, test pages and staging previews out of the file.
	 *
	 * @param int $id
	 * @return bool
	 */
	private static function is_noindexed( $id ) {
		if ( '1' === (string) get_post_meta( $id, '_yoast_wpseo_meta-robots-noindex', true ) ) {
			return true;
		}

		$rm = get_post_meta( $id, 'rank_math_robots', true );
		if ( is_array( $rm ) && in_array( 'noindex', $rm, true ) ) {
			return true;
		}

		return false;
	}

	/**
	 * @return bool
	 */
	private static function llms_txt_live() {
		if ( get_option( self::LLMS_OPTION ) ) {
			return true;
		}
		$res = wp_remote_get( home_url( '/llms.txt' ), array( 'timeout' => 8, 'sslverify' => false ) );
		return ! is_wp_error( $res ) && 200 === (int) wp_remote_retrieve_response_code( $res );
	}

	/**
	 * Serve /llms.txt. Hooked from the main plugin file.
	 */
	public static function maybe_serve_llms_txt() {
		$path = trim( (string) wp_parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ), '/' );
		if ( 'llms.txt' !== $path ) {
			return;
		}
		$content = get_option( self::LLMS_OPTION );
		if ( ! $content ) {
			return; // Nothing stored — let WordPress 404 as normal.
		}

		// By the time template_redirect runs, WordPress has already resolved /llms.txt to a
		// 404 — no post matches that path — and set the response status accordingly. Echoing
		// the body without correcting the status serves the right bytes under a "this does
		// not exist" status line. Crawlers obey the status, not the body, so the file was
		// live, correct, and silently discarded by every agent it was written for.
		status_header( 200 );

		// No X-Robots-Tag: noindex here. It was in an earlier version, and it is the wrong
		// instruction for this file: llms.txt exists precisely to be fetched and read by the
		// AI crawlers that honour that header. Keeping a .txt out of search results is not
		// worth risking the agents skipping it.
		header( 'Content-Type: text/plain; charset=utf-8' );
		header( 'Content-Length: ' . strlen( $content ) );
		header( 'Cache-Control: public, max-age=3600' );

		// A HEAD request wants the headers only; sending a body is a protocol violation and
		// confuses strict clients.
		if ( isset( $_SERVER['REQUEST_METHOD'] ) && 'HEAD' === strtoupper( (string) $_SERVER['REQUEST_METHOD'] ) ) {
			exit;
		}

		echo $content; // phpcs:ignore WordPress.Security.EscapeOutput -- plain text, generated server-side.
		exit;
	}

	/* ===================================================================== */
	/* Orphans                                                                */
	/* ===================================================================== */

	/**
	 * @param array $args
	 * @return array|WP_Error
	 */
	public static function find_orphan_pages( $args ) {
		if ( ! current_user_can( 'edit_posts' ) ) {
			return new WP_Error( 'forbidden', 'You need the edit_posts capability.' );
		}

		$types = ! empty( $args['post_types'] )
			? array_map( 'trim', explode( ',', (string) $args['post_types'] ) )
			: array( 'page', 'post' );

		$all = get_posts(
			array(
				'post_type'      => $types,
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'fields'         => 'ids',
			)
		);
		if ( ! $all ) {
			return array( 'checked' => 0, 'orphans' => array() );
		}

		// Build one haystack of every link on the site, including Elementor's meta blob.
		global $wpdb;
		$haystack = '';
		foreach ( $all as $id ) {
			$haystack .= (string) get_post_field( 'post_content', $id );
			$el        = get_post_meta( (int) $id, '_elementor_data', true );
			if ( $el ) {
				$haystack .= is_string( $el ) ? $el : wp_json_encode( $el );
			}
		}
		// Menus are a legitimate discovery path, so count them as inbound links.
		$menu_ids = $wpdb->get_col(
			"SELECT meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_menu_item_object_id'"
		);
		$menu_ids = array_map( 'intval', (array) $menu_ids );

		$front = (int) get_option( 'page_on_front' );
		$blog  = (int) get_option( 'page_for_posts' );

		$orphans = array();
		foreach ( $all as $id ) {
			$id = (int) $id;
			if ( $id === $front || $id === $blog || in_array( $id, $menu_ids, true ) ) {
				continue;
			}

			$permalink = get_permalink( $id );
			$slug      = get_post_field( 'post_name', $id );

			// Match the full URL, the escaped-slash form Elementor stores, or ?p=ID.
			$linked = false !== strpos( $haystack, $permalink )
				|| false !== strpos( $haystack, str_replace( '/', '\\/', $permalink ) )
				|| ( $slug && preg_match( '#/' . preg_quote( $slug, '#' ) . '/?["\'\\\\]#', $haystack ) )
				|| false !== strpos( $haystack, '?p=' . $id );

			if ( ! $linked ) {
				$orphans[] = array(
					'post_id'   => $id,
					'title'     => axon_text( get_the_title( $id ) ),
					'url'       => $permalink,
					'type'      => get_post_type( $id ),
					'modified'  => get_post_modified_time( 'c', true, $id ),
				);
			}
		}

		return array(
			'checked'  => count( $all ),
			'orphans'  => $orphans,
			'severity' => count( $orphans ) > 0 ? 'warn' : 'ok',
			'message'  => $orphans
				? sprintf( '%d published item(s) have no internal links and are not in a menu. Crawlers reach them only via the sitemap, and both search and AI engines read that as low importance.', count( $orphans ) )
				: 'Every published item is linked from somewhere.',
			'note'     => 'Menu items and the front/blog pages are excluded. Link detection covers classic content and Elementor data.',
		);
	}
}
