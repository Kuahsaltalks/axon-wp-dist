<?php
/**
 * Class Axon_Antigravity_MCP
 *
 * Dedicated Google Antigravity (AGY) Model Context Protocol Integration for AXON.
 * Provides a permanent, secure REST MCP server endpoint for Antigravity to post, update,
 * audit, and manage content on theiimt.com without requiring short-lived JWT tokens.
 *
 * REST Endpoints:
 *   GET  /wp-json/antigravity/v1/status    - Antigravity MCP Manifest & System Health
 *   POST /wp-json/antigravity/v1/post      - Create/Publish Blog Posts directly
 *   POST /wp-json/antigravity/v1/page      - Update Landing Pages & Templates directly
 *   POST /wp-json/antigravity/v1/media     - Upload & Optimize Media Assets
 *   POST /wp-json/antigravity/v1/purge-cache - Instant LiteSpeed & WP Cache Purge
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

class Axon_Antigravity_MCP {

    const OPTION_KEY_SECRET = 'antigravity_mcp_secret_key';
    const OPTION_KEY_ENABLED = 'antigravity_mcp_enabled';
    const OPTION_KEY_ACTIVE_ENGINE = 'antigravity_mcp_active_engine';

    public static function init() {
        // Register REST API endpoints for Antigravity
        add_action( 'rest_api_init', array( __CLASS__, 'register_rest_routes' ) );

        // Ensure default secret key exists
        if ( ! get_option( self::OPTION_KEY_SECRET ) ) {
            update_option( self::OPTION_KEY_SECRET, 'agy_sec_key_' . ( function_exists('wp_generate_password') ? wp_generate_password( 24, false ) : md5(uniqid()) ) );
            update_option( self::OPTION_KEY_ENABLED, '1' );
            update_option( self::OPTION_KEY_ACTIVE_ENGINE, 'antigravity' );
        }
    }

    /**
     * Register REST API endpoints for Antigravity MCP.
     */
    public static function register_rest_routes() {
        register_rest_route( 'antigravity/v1', '/status', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_status' ),
            'permission_callback' => '__return_true',
        ) );

        register_rest_route( 'antigravity/v1', '/post', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_publish_post' ),
            'permission_callback' => array( __CLASS__, 'authenticate_antigravity' ),
        ) );

        register_rest_route( 'antigravity/v1', '/page', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_update_page' ),
            'permission_callback' => array( __CLASS__, 'authenticate_antigravity' ),
        ) );

        register_rest_route( 'antigravity/v1', '/media', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_upload_media' ),
            'permission_callback' => array( __CLASS__, 'authenticate_antigravity' ),
        ) );

        register_rest_route( 'antigravity/v1', '/purge-cache', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_purge_cache' ),
            'permission_callback' => array( __CLASS__, 'authenticate_antigravity' ),
        ) );

        register_rest_route( 'antigravity/v1', '/delete-post', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_delete_post' ),
            'permission_callback' => array( __CLASS__, 'authenticate_antigravity' ),
        ) );
    }

    /**
     * Validate Antigravity Secret Key via Bearer or Query parameter.
     */
    public static function authenticate_antigravity( $request ) {
        $secret = get_option( self::OPTION_KEY_SECRET );
        if ( empty( $secret ) ) {
            return false;
        }

        $auth_header = $request->get_header( 'authorization' );
        if ( $auth_header && strpos( strtolower( $auth_header ), 'bearer ' ) === 0 ) {
            $token = trim( substr( $auth_header, 7 ) );
            if ( hash_equals( $secret, $token ) ) {
                return true;
            }
        }

        $param_key = $request->get_param( 'api_key' );
        if ( $param_key && hash_equals( $secret, $param_key ) ) {
            return true;
        }

        return new WP_Error( 'antigravity_unauthorized', 'Invalid Antigravity MCP API Key.', array( 'status' => 401 ) );
    }

    /**
     * Return Antigravity MCP status and capabilities.
     */
    public static function handle_status() {
        return rest_ensure_response( array(
            'status'         => 'online',
            'agent'          => 'Google Antigravity (AGY)',
            'plugin'         => 'Axon',
            'version'        => defined('AXON_VERSION') ? AXON_VERSION : '2.5.3',
            'site'           => get_bloginfo( 'name' ),
            'url'            => home_url(),
            'endpoints'      => array(
                'publish_post' => rest_url( 'antigravity/v1/post' ),
                'update_page'  => rest_url( 'antigravity/v1/page' ),
                'upload_media' => rest_url( 'antigravity/v1/media' ),
                'purge_cache'  => rest_url( 'antigravity/v1/purge-cache' ),
            ),
        ) );
    }

    /**
     * Create or update a blog post directly.
     */
    public static function handle_publish_post( $request ) {
        $params = $request->get_json_params();
        if ( empty( $params ) ) {
            $params = $request->get_body_params();
        }

        $title   = sanitize_text_field( $params['title'] ?? '' );
        $content = $params['content'] ?? '';
        $slug    = sanitize_title( $params['slug'] ?? '' );
        $status  = sanitize_text_field( $params['status'] ?? 'publish' );

        if ( empty( $title ) || empty( $content ) ) {
            return new WP_Error( 'missing_fields', 'Title and Content are required.', array( 'status' => 400 ) );
        }

        $post_data = array(
            'post_title'   => $title,
            'post_content' => $content,
            'post_status'  => $status,
            'post_type'    => 'post',
        );

        if ( ! empty( $slug ) ) {
            $post_data['post_name'] = $slug;
        }

        $existing_id = intval( $params['post_id'] ?? $params['id'] ?? 0 );
        if ( ! $existing_id && ! empty( $slug ) ) {
            $found = get_page_by_path( $slug, OBJECT, 'post' );
            if ( $found ) {
                $existing_id = $found->ID;
            }
        }
        if ( $existing_id ) {
            $post_data['ID'] = $existing_id;
        }

        // Unfilter post content so custom HTML/CSS/JS is preserved intact without KSES stripping
        kses_remove_filters();
        $admin_user = get_user_by( 'id', 1 );
        if ( $admin_user ) {
            wp_set_current_user( 1 );
            $post_data['post_author'] = 1;
        }

        $post_id = wp_insert_post( $post_data );

        kses_init_filters();

        if ( is_wp_error( $post_id ) ) {
            return $post_id;
        }

        self::purge_litespeed();

        return rest_ensure_response( array(
            'success'   => true,
            'post_id'   => $post_id,
            'link'      => get_permalink( $post_id ),
            'published' => true,
        ) );
    }

    /**
     * Delete a post or page by ID.
     */
    public static function handle_delete_post( $request ) {
        $params = $request->get_json_params();
        if ( empty( $params ) ) {
            $params = $request->get_body_params();
        }

        $post_id = intval( $params['post_id'] ?? $params['id'] ?? 0 );
        if ( ! $post_id ) {
            return new WP_Error( 'missing_id', 'Post ID is required.', array( 'status' => 400 ) );
        }

        $force = ! empty( $params['force'] );
        $deleted = wp_delete_post( $post_id, $force );
        self::purge_litespeed();
        return rest_ensure_response( array(
            'success' => (bool) $deleted,
            'post_id' => $post_id,
            'deleted' => true,
        ) );
    }

    /**
     * Update a page content or template directly.
     */
    public static function handle_update_page( $request ) {
        $params = $request->get_json_params();
        if ( empty( $params ) ) {
            $params = $request->get_body_params();
        }

        $page_id = intval( $params['page_id'] ?? $params['id'] ?? 0 );
        $content = $params['content'] ?? null;
        $template = sanitize_text_field( $params['template'] ?? '' );

        if ( ! $page_id ) {
            return new WP_Error( 'missing_id', 'Page ID is required.', array( 'status' => 400 ) );
        }

        $page_data = array(
            'ID' => $page_id,
        );

        if ( null !== $content ) {
            $page_data['post_content'] = $content;
        }
        if ( ! empty( $params['title'] ) ) {
            $page_data['post_title'] = sanitize_text_field( $params['title'] );
        }
        if ( ! empty( $params['status'] ) ) {
            $page_data['post_status'] = sanitize_text_field( $params['status'] );
        }
        if ( ! empty( $params['slug'] ) ) {
            $page_data['post_name'] = sanitize_title( $params['slug'] );
        }

        // Unfilter post content so custom HTML/CSS/JS is preserved intact without KSES stripping
        kses_remove_filters();
        $admin_user = get_user_by( 'id', 1 );
        if ( $admin_user ) {
            wp_set_current_user( 1 );
        }

        $updated = wp_update_post( $page_data );

        kses_init_filters();

        if ( is_wp_error( $updated ) ) {
            return $updated;
        }

        if ( ! empty( $template ) ) {
            update_post_meta( $page_id, '_wp_page_template', $template );
        }

        self::purge_litespeed();

        return rest_ensure_response( array(
            'success' => true,
            'page_id' => $page_id,
            'link'    => get_permalink( $page_id ),
            'updated' => true,
        ) );
    }

    /**
     * Upload Media Attachment directly.
     */
    public static function handle_upload_media( $request ) {
        require_once ABSPATH . 'wp-admin/includes/image.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';

        $files = $request->get_file_params();
        if ( empty( $files['file'] ) ) {
            return new WP_Error( 'no_file', 'No file provided.', array( 'status' => 400 ) );
        }

        $attachment_id = media_handle_upload( 'file', 0 );

        if ( is_wp_error( $attachment_id ) ) {
            return $attachment_id;
        }

        return rest_ensure_response( array(
            'success'       => true,
            'attachment_id' => $attachment_id,
            'url'           => wp_get_attachment_url( $attachment_id ),
        ) );
    }

    /**
     * Purge LiteSpeed & WP Cache.
     */
    public static function handle_purge_cache() {
        self::purge_litespeed();
        return rest_ensure_response( array(
            'success' => true,
            'message' => 'LiteSpeed & WordPress cache purged successfully.',
        ) );
    }

    private static function purge_litespeed() {
        if ( class_exists( 'LiteSpeed\Purge' ) ) {
            \LiteSpeed\Purge::purge_all();
        } elseif ( function_exists( 'do_action' ) ) {
            do_action( 'litespeed_purge_all' );
        }
    }
}

Axon_Antigravity_MCP::init();
