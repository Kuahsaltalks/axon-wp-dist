<?php
/**
 * Storage layer for OAuth clients, authorization codes, and tokens.
 *
 * Uses dedicated DB tables (not wp_options) since these rows are
 * high-churn and benefit from indexed lookups/expiry cleanup.
 *
 * @package MCP_OAuth_Bridge
 */

declare(strict_types=1);

namespace MCP_OAuth_Bridge;

defined( 'ABSPATH' ) || exit;

class Token_Store {

	public static function table( string $name ): string {
		global $wpdb;
		return $wpdb->prefix . 'mcp_oauth_' . $name;
	}

	public static function install(): void {
		global $wpdb;
		$charset_collate = $wpdb->get_charset_collate();
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$clients = self::table( 'clients' );
		dbDelta(
			"CREATE TABLE {$clients} (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				client_id VARCHAR(64) NOT NULL,
				client_name VARCHAR(255) NOT NULL DEFAULT '',
				redirect_uris LONGTEXT NOT NULL,
				token_endpoint_auth_method VARCHAR(32) NOT NULL DEFAULT 'none',
				created_at BIGINT UNSIGNED NOT NULL,
				PRIMARY KEY (id),
				UNIQUE KEY client_id (client_id)
			) {$charset_collate};"
		);

		$codes = self::table( 'auth_codes' );
		dbDelta(
			"CREATE TABLE {$codes} (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				code_hash CHAR(64) NOT NULL,
				client_id VARCHAR(64) NOT NULL,
				user_id BIGINT UNSIGNED NOT NULL,
				redirect_uri TEXT NOT NULL,
				code_challenge VARCHAR(255) NOT NULL,
				code_challenge_method VARCHAR(16) NOT NULL DEFAULT 'S256',
				scope VARCHAR(255) NOT NULL DEFAULT '',
				expires_at BIGINT UNSIGNED NOT NULL,
				used TINYINT(1) NOT NULL DEFAULT 0,
				PRIMARY KEY (id),
				UNIQUE KEY code_hash (code_hash)
			) {$charset_collate};"
		);

		$tokens = self::table( 'tokens' );
		dbDelta(
			"CREATE TABLE {$tokens} (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				access_token_hash CHAR(64) NOT NULL,
				refresh_token_hash CHAR(64) DEFAULT NULL,
				client_id VARCHAR(64) NOT NULL,
				user_id BIGINT UNSIGNED NOT NULL,
				scope VARCHAR(255) NOT NULL DEFAULT '',
				issued_at BIGINT UNSIGNED NOT NULL,
				access_expires_at BIGINT UNSIGNED NOT NULL,
				refresh_expires_at BIGINT UNSIGNED DEFAULT NULL,
				revoked TINYINT(1) NOT NULL DEFAULT 0,
				PRIMARY KEY (id),
				UNIQUE KEY access_token_hash (access_token_hash),
				KEY refresh_token_hash (refresh_token_hash)
			) {$charset_collate};"
		);
	}

	public static function hash( string $value ): string {
		return hash( 'sha256', $value );
	}

	// ---- Clients -------------------------------------------------------

	public static function create_client( string $client_name, array $redirect_uris, string $auth_method = 'none' ): array {
		global $wpdb;
		$client_id = 'mcp_' . wp_generate_password( 24, false );
		$wpdb->insert(
			self::table( 'clients' ),
			array(
				'client_id'                  => $client_id,
				'client_name'                => $client_name,
				'redirect_uris'               => wp_json_encode( array_values( $redirect_uris ) ),
				'token_endpoint_auth_method'  => $auth_method,
				'created_at'                  => time(),
			),
			array( '%s', '%s', '%s', '%s', '%d' )
		);
		return array(
			'client_id'    => $client_id,
			'redirect_uris' => array_values( $redirect_uris ),
		);
	}

	public static function get_client( string $client_id ): ?array {
		global $wpdb;
		$row = $wpdb->get_row(
			$wpdb->prepare( 'SELECT * FROM ' . self::table( 'clients' ) . ' WHERE client_id = %s', $client_id ),
			ARRAY_A
		);
		if ( ! $row ) {
			return null;
		}
		$row['redirect_uris'] = json_decode( $row['redirect_uris'], true );
		return $row;
	}

	// ---- Authorization codes --------------------------------------------

	public static function create_auth_code( string $client_id, int $user_id, string $redirect_uri, string $code_challenge, string $code_challenge_method, string $scope ): string {
		global $wpdb;
		$code = wp_generate_password( 48, false );
		$wpdb->insert(
			self::table( 'auth_codes' ),
			array(
				'code_hash'             => self::hash( $code ),
				'client_id'             => $client_id,
				'user_id'               => $user_id,
				'redirect_uri'          => $redirect_uri,
				'code_challenge'        => $code_challenge,
				'code_challenge_method' => $code_challenge_method,
				'scope'                 => $scope,
				'expires_at'            => time() + 600, // 10 minutes.
				'used'                  => 0,
			),
			array( '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%d', '%d' )
		);
		return $code;
	}

	public static function consume_auth_code( string $code ): ?array {
		global $wpdb;
		$hash  = self::hash( $code );
		$table = self::table( 'auth_codes' );
		$row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE code_hash = %s", $hash ), ARRAY_A );

		if ( ! $row || (int) $row['used'] === 1 || (int) $row['expires_at'] < time() ) {
			return null;
		}

		// Single-use: mark consumed immediately (even if later steps fail, code must not be reusable).
		$wpdb->update( $table, array( 'used' => 1 ), array( 'id' => $row['id'] ), array( '%d' ), array( '%d' ) );

		return $row;
	}

	// ---- Access / refresh tokens -----------------------------------------

	public static function issue_tokens( string $client_id, int $user_id, string $scope ): array {
		global $wpdb;
		$access_token       = 'access_' . wp_generate_password( 48, false );
		$refresh_token      = 'refresh_' . wp_generate_password( 48, false );
		$issued_at          = time();
		$access_expires_at  = $issued_at + 3600;       // 1 hour.
		$refresh_expires_at = $issued_at + ( 30 * DAY_IN_SECONDS );

		$wpdb->insert(
			self::table( 'tokens' ),
			array(
				'access_token_hash'  => self::hash( $access_token ),
				'refresh_token_hash' => self::hash( $refresh_token ),
				'client_id'          => $client_id,
				'user_id'            => $user_id,
				'scope'              => $scope,
				'issued_at'          => $issued_at,
				'access_expires_at'  => $access_expires_at,
				'refresh_expires_at' => $refresh_expires_at,
				'revoked'            => 0,
			),
			array( '%s', '%s', '%s', '%d', '%s', '%d', '%d', '%d', '%d' )
		);

		return array(
			'access_token'  => $access_token,
			'refresh_token' => $refresh_token,
			'expires_in'    => 3600,
			'token_type'    => 'Bearer',
			'scope'         => $scope,
		);
	}

	public static function validate_access_token( string $token ): ?array {
		global $wpdb;
		$table = self::table( 'tokens' );
		$row   = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE access_token_hash = %s", self::hash( $token ) ),
			ARRAY_A
		);
		if ( ! $row || (int) $row['revoked'] === 1 || (int) $row['access_expires_at'] < time() ) {
			return null;
		}
		return $row;
	}

	public static function rotate_refresh_token( string $refresh_token, string $client_id ): ?array {
		global $wpdb;
		$table = self::table( 'tokens' );
		$row   = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE refresh_token_hash = %s AND client_id = %s", self::hash( $refresh_token ), $client_id ),
			ARRAY_A
		);
		if ( ! $row || (int) $row['revoked'] === 1 || (int) $row['refresh_expires_at'] < time() ) {
			return null;
		}

		// Revoke old token record, issue a fresh pair (refresh token rotation).
		$wpdb->update( $table, array( 'revoked' => 1 ), array( 'id' => $row['id'] ), array( '%d' ), array( '%d' ) );

		return self::issue_tokens( $row['client_id'], (int) $row['user_id'], $row['scope'] );
	}

	public static function revoke_token( string $token ): bool {
		global $wpdb;
		$table = self::table( 'tokens' );
		$hash  = self::hash( $token );
		$updated = $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table} SET revoked = 1 WHERE access_token_hash = %s OR refresh_token_hash = %s",
				$hash,
				$hash
			)
		);
		return (bool) $updated;
	}
}
