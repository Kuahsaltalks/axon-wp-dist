<?php
/**
 * Token endpoint: exchanges authorization codes (+ PKCE verifier) for
 * access/refresh tokens, and handles refresh_token grant + revocation.
 *
 * @package MCP_OAuth_Bridge
 */

declare(strict_types=1);

namespace MCP_OAuth_Bridge;

use WP_REST_Request;
use WP_REST_Response;
use WP_Error;

defined( 'ABSPATH' ) || exit;

class Token_Endpoint {

	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	public function register_routes(): void {
		register_rest_route(
			'mcp-oauth/v1',
			'/token',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle_token' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			'mcp-oauth/v1',
			'/revoke',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle_revoke' ),
				'permission_callback' => '__return_true',
			)
		);
	}

	public function handle_token( WP_REST_Request $request ) {
		// Token requests are form-encoded per RFC 6749, not JSON.
		$params     = $request->get_body_params();
		$grant_type = $params['grant_type'] ?? '';

		if ( 'authorization_code' === $grant_type ) {
			return $this->handle_authorization_code_grant( $params );
		}

		if ( 'refresh_token' === $grant_type ) {
			return $this->handle_refresh_token_grant( $params );
		}

		return new WP_Error( 'unsupported_grant_type', 'Only authorization_code and refresh_token grants are supported.', array( 'status' => 400 ) );
	}

	private function handle_authorization_code_grant( array $params ) {
		$code          = $params['code'] ?? '';
		$redirect_uri  = $params['redirect_uri'] ?? '';
		$client_id     = $params['client_id'] ?? '';
		$code_verifier = $params['code_verifier'] ?? '';

		if ( empty( $code ) || empty( $code_verifier ) || empty( $client_id ) ) {
			return new WP_Error( 'invalid_request', 'code, code_verifier, and client_id are required.', array( 'status' => 400 ) );
		}

		$record = Token_Store::consume_auth_code( $code );
		if ( ! $record ) {
			return new WP_Error( 'invalid_grant', 'Authorization code is invalid, expired, or already used.', array( 'status' => 400 ) );
		}

		// Bind the token exchange to the exact same client + redirect_uri used at /authorize.
		if ( ! hash_equals( $record['client_id'], $client_id ) || ! hash_equals( $record['redirect_uri'], $redirect_uri ) ) {
			return new WP_Error( 'invalid_grant', 'client_id or redirect_uri does not match the authorization request.', array( 'status' => 400 ) );
		}

		if ( ! PKCE::verify( $code_verifier, $record['code_challenge'], $record['code_challenge_method'] ) ) {
			return new WP_Error( 'invalid_grant', 'PKCE verification failed.', array( 'status' => 400 ) );
		}

		$tokens = Token_Store::issue_tokens( $client_id, (int) $record['user_id'], $record['scope'] );

		return new WP_REST_Response( $tokens, 200 );
	}

	private function handle_refresh_token_grant( array $params ) {
		$refresh_token = $params['refresh_token'] ?? '';
		$client_id     = $params['client_id'] ?? '';

		if ( empty( $refresh_token ) || empty( $client_id ) ) {
			return new WP_Error( 'invalid_request', 'refresh_token and client_id are required.', array( 'status' => 400 ) );
		}

		$tokens = Token_Store::rotate_refresh_token( $refresh_token, $client_id );
		if ( ! $tokens ) {
			return new WP_Error( 'invalid_grant', 'Refresh token is invalid, expired, or revoked.', array( 'status' => 400 ) );
		}

		return new WP_REST_Response( $tokens, 200 );
	}

	public function handle_revoke( WP_REST_Request $request ) {
		$params = $request->get_body_params();
		$token  = $params['token'] ?? '';

		if ( empty( $token ) ) {
			return new WP_Error( 'invalid_request', 'token is required.', array( 'status' => 400 ) );
		}

		Token_Store::revoke_token( $token );

		// RFC 7009: revocation endpoint returns 200 even if the token was already invalid/unknown.
		return new WP_REST_Response( null, 200 );
	}
}
