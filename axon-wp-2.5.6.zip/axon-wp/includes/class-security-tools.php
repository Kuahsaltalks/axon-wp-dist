<?php
/**
 * Security & risk auditing.
 *
 * Deliberately READ-ONLY. This module reports and explains; it never blocks a request,
 * bans an IP or quarantines a file. A firewall that gets it wrong locks the owner out of
 * their own site, and a false positive at 11pm is a support call you cannot answer. The
 * value AI adds here is triage and explanation, not enforcement.
 *
 * Three tools:
 *   audit_plugins        - abandoned/closed/incompatible/duplicated plugins + risky code
 *   audit_site_hardening - configuration and exposure checks
 *   check_core_integrity - WordPress core files vs the official checksums
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Axon_Security_Tools {

	/** Cache wordpress.org lookups for a day; the API is rate-limited and slow. */
	const REPO_CACHE_TTL = DAY_IN_SECONDS;

	/** A plugin untouched for this long is effectively abandoned. */
	const ABANDONED_DAYS = 730;

	/**
	 * Slugs grouped by what they do, so we can spot three form plugins fighting
	 * for the same job. Only the common ones — unknown slugs are simply not grouped.
	 *
	 * @var array<string, array<int, string>>
	 */
	const CATEGORIES = array(
		'contact forms'  => array( 'wpforms-lite', 'wpforms', 'fluentform', 'metform', 'contact-form-7', 'gravityforms', 'ninja-forms', 'formidable', 'happyforms' ),
		'SEO'            => array( 'seo-by-rank-math', 'wordpress-seo', 'all-in-one-seo-pack', 'seopress', 'wp-seo-structured-data-schema', 'squirrly-seo' ),
		'caching/speed'  => array( 'litespeed-cache', 'wp-rocket', 'w3-total-cache', 'wp-super-cache', 'nitropack', 'autoptimize', 'wp-fastest-cache', 'sg-cachepress', 'breeze' ),
		'security'       => array( 'wordfence', 'sucuri-scanner', 'better-wp-security', 'all-in-one-wp-security-and-firewall', 'wp-cerber' ),
		'backup'         => array( 'updraftplus', 'backwpup', 'duplicator', 'all-in-one-wp-migration' ),
		'page builder'   => array( 'elementor', 'siteorigin-panels', 'beaver-builder-lite-version', 'js_composer', 'brizy', 'divi-builder' ),
		'analytics'      => array( 'google-site-kit', 'google-analytics-for-wordpress', 'jetpack', 'exactmetrics-premium' ),
		'image optimise' => array( 'ewww-image-optimizer', 'shortpixel-image-optimiser', 'wp-smushit', 'imagify', 'webp-express', 'converter-for-media' ),
	);

	/**
	 * Code patterns worth a human look.
	 *
	 * These are SIGNALS, not proof of malware — base64_decode and file_get_contents
	 * appear in plenty of legitimate plugins. Severity reflects how often the pattern
	 * shows up in genuinely malicious or destructive code, not certainty.
	 *
	 * @var array<int, array{pattern: string, severity: string, why: string}>
	 */
	const RISKY_PATTERNS = array(
		array( 'pattern' => '/\beval\s*\(/i',                       'severity' => 'critical', 'why' => 'eval() executes arbitrary code — the single most common malware primitive.' ),
		array( 'pattern' => '/\bcreate_function\s*\(/i',            'severity' => 'critical', 'why' => 'create_function() is removed in PHP 8 and was a common obfuscation vector.' ),
		array( 'pattern' => '/\b(shell_exec|passthru|proc_open|popen)\s*\(/i', 'severity' => 'critical', 'why' => 'Executes shell commands from PHP.' ),
		array( 'pattern' => '/\bsystem\s*\(/i',                     'severity' => 'critical', 'why' => 'Executes shell commands from PHP.' ),
		array( 'pattern' => '/\bgzinflate\s*\(\s*base64_decode/i',  'severity' => 'critical', 'why' => 'gzinflate(base64_decode(...)) is a classic packed-payload signature.' ),
		array( 'pattern' => '/\bstr_rot13\s*\(/i',                  'severity' => 'warn',     'why' => 'ROT13 is used almost exclusively to hide strings from casual reading.' ),
		array( 'pattern' => '/preg_replace\s*\(\s*[\'"][^\'"]*\/\w*e\w*[\'"]/i', 'severity' => 'critical', 'why' => 'preg_replace with the /e modifier executes the replacement as code.' ),
		array( 'pattern' => '/\bdelete_post_meta\s*\(/i',           'severity' => 'warn',     'why' => 'Deletes post metadata. If called at load time this destroys content — see the IIMT SEO Booster incident.' ),
		array( 'pattern' => '/\bwp_delete_post\s*\(/i',             'severity' => 'warn',     'why' => 'Deletes posts. Verify it is user-initiated and not running on every request.' ),
		array( 'pattern' => '/\$GLOBALS\s*\[\s*[\'"]\w+[\'"]\s*\]\s*\(/', 'severity' => 'warn', 'why' => 'Calling a function stored in $GLOBALS is a common way to disguise the callee.' ),
		array( 'pattern' => '/\bbase64_decode\s*\(/i',              'severity' => 'info',     'why' => 'Common in legitimate code, but also the usual wrapper for hidden payloads.' ),
	);

	/**
	 * @return array<int, array<string, mixed>>
	 */
	public static function tools() {
		return array(
			array(
				'name'        => 'audit_plugins',
				'description' => 'Audit every installed plugin for risk: abandoned or removed-from-repo plugins, versions incompatible with the running WordPress/PHP, custom code that is not in the WordPress.org repository, several plugins doing the same job, and risky code patterns. Read-only. Use this before blaming a slow or broken site on hosting.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'scan_code'      => array(
							'type'        => 'boolean',
							'description' => 'Also grep each plugin for risky code patterns (eval, packed payloads, destructive deletes). Default true. Slower on large installs.',
						),
						'check_repo'     => array(
							'type'        => 'boolean',
							'description' => 'Query WordPress.org for latest version, last-updated date and whether the plugin has been closed. Default true. Results cached 24h.',
						),
						'include_active' => array(
							'type'        => 'string',
							'description' => 'Which plugins to audit: "all" (default), "active", or "inactive".',
						),
					),
					'required'   => array(),
				),
				'callback'    => array( __CLASS__, 'audit_plugins' ),
			),
			array(
				'name'        => 'audit_site_hardening',
				'description' => 'Check WordPress configuration and exposure: core/PHP versions, file-editor access, debug output, XML-RPC, REST user enumeration, admin usernames, dormant administrator accounts, SSL and security headers. Read-only, returns findings ranked by severity with the exact fix for each.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'dormant_days' => array(
							'type'        => 'integer',
							'description' => 'Flag administrator accounts with no post activity for this many days. Default 365.',
						),
					),
					'required'   => array(),
				),
				'callback'    => array( __CLASS__, 'audit_site_hardening' ),
			),
			array(
				'name'        => 'check_core_integrity',
				'description' => 'Verify WordPress core files against the official WordPress.org checksums for the exact version and locale in use. Reports modified core files (a strong compromise signal) and unexpected PHP files in core directories. Read-only.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => new stdClass(),
					'required'   => array(),
				),
				'callback'    => array( __CLASS__, 'check_core_integrity' ),
			),
		);
	}

	/* ===================================================================== */
	/* audit_plugins                                                          */
	/* ===================================================================== */

	/**
	 * @param array $args
	 * @return array|WP_Error
	 */
	public static function audit_plugins( $args ) {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return new WP_Error( 'forbidden', 'You need the activate_plugins capability to audit plugins.' );
		}

		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$scan_code  = ! isset( $args['scan_code'] ) || (bool) $args['scan_code'];
		$check_repo = ! isset( $args['check_repo'] ) || (bool) $args['check_repo'];
		$which      = isset( $args['include_active'] ) ? (string) $args['include_active'] : 'all';

		$all       = get_plugins();
		$active    = (array) get_option( 'active_plugins', array() );
		$wp_ver    = get_bloginfo( 'version' );
		$results   = array();
		$by_cat    = array();

		foreach ( $all as $file => $data ) {
			$is_active = in_array( $file, $active, true );
			if ( 'active' === $which && ! $is_active ) {
				continue;
			}
			if ( 'inactive' === $which && $is_active ) {
				continue;
			}

			$slug   = dirname( $file );
			$slug   = ( '.' === $slug ) ? basename( $file, '.php' ) : $slug;
			$issues = array();

			// --- Inactive plugins are still reachable files on disk.
			if ( ! $is_active ) {
				$issues[] = self::issue(
					'inactive',
					'warn',
					'Inactive but still installed. The files remain on the server and can still be exploited if they contain a vulnerability. Delete what you do not use.'
				);
			}

			// --- Environment compatibility.
			if ( ! empty( $data['RequiresPHP'] ) && version_compare( PHP_VERSION, $data['RequiresPHP'], '<' ) ) {
				$issues[] = self::issue(
					'php_incompatible',
					'critical',
					sprintf( 'Requires PHP %s but this server runs %s. Expect fatal errors.', $data['RequiresPHP'], PHP_VERSION )
				);
			}
			if ( ! empty( $data['RequiresWP'] ) && version_compare( $wp_ver, $data['RequiresWP'], '<' ) ) {
				$issues[] = self::issue(
					'wp_incompatible',
					'warn',
					sprintf( 'Declares it needs WordPress %s but this site runs %s.', $data['RequiresWP'], $wp_ver )
				);
			}

			// --- WordPress.org repository status.
			$repo = $check_repo ? self::repo_info( $slug ) : null;
			if ( is_array( $repo ) ) {
				if ( 'closed' === ( $repo['status'] ?? '' ) ) {
					$issues[] = self::issue(
						'removed_from_repo',
						'critical',
						'This plugin has been CLOSED on WordPress.org. Plugins are usually closed for unpatched security issues or guideline breaches. Replace it.'
					);
				} elseif ( 'unknown' === ( $repo['status'] ?? '' ) ) {
					$issues[] = self::issue(
						'not_in_repo',
						'warn',
						'Not found in the WordPress.org repository — it is custom, premium, or side-loaded code. It will never auto-update, and nobody is reviewing it. Confirm you know where it came from.'
					);
				} else {
					if ( ! empty( $repo['version'] ) && version_compare( (string) $data['Version'], $repo['version'], '<' ) ) {
						$issues[] = self::issue(
							'outdated',
							'warn',
							sprintf( 'Version %s installed, %s available. Outdated plugins are the most common WordPress attack vector.', $data['Version'], $repo['version'] )
						);
					}
					if ( ! empty( $repo['last_updated_ts'] ) ) {
						$days = (int) floor( ( time() - $repo['last_updated_ts'] ) / DAY_IN_SECONDS );
						if ( $days > self::ABANDONED_DAYS ) {
							$issues[] = self::issue(
								'abandoned',
								'warn',
								sprintf( 'No update for %d days (~%d years). Effectively abandoned — it will not be patched.', $days, (int) round( $days / 365 ) )
							);
						}
					}
				}
			}

			// --- Static code smell scan.
			if ( $scan_code ) {
				foreach ( self::scan_plugin_code( $file ) as $hit ) {
					$issues[] = $hit;
				}
			}

			// --- Duplicate-purpose grouping (only for plugins that are switched on).
			if ( $is_active ) {
				foreach ( self::CATEGORIES as $cat => $slugs ) {
					if ( in_array( $slug, $slugs, true ) ) {
						$by_cat[ $cat ][] = $data['Name'];
					}
				}
			}

			if ( $issues ) {
				// Worst issue first so the caller can read top-down.
				$rank = array( 'critical' => 0, 'warn' => 1, 'info' => 2 );
				usort( $issues, static fn( $a, $b ) => $rank[ $a['severity'] ] <=> $rank[ $b['severity'] ] );

				$results[] = array(
					'plugin'   => $file,
					'name'     => $data['Name'],
					'version'  => $data['Version'],
					'active'   => $is_active,
					'severity' => $issues[0]['severity'],
					'issues'   => $issues,
				);
			}
		}

		// --- Overlapping plugins.
		$overlaps = array();
		foreach ( $by_cat as $cat => $names ) {
			if ( count( $names ) > 1 ) {
				$overlaps[] = array(
					'category' => $cat,
					'plugins'  => $names,
					'message'  => sprintf(
						'%d active plugins all handle %s: %s. Each one loads its own CSS/JS on every page. Keep one.',
						count( $names ),
						$cat,
						implode( ', ', $names )
					),
				);
			}
		}

		$rank = array( 'critical' => 0, 'warn' => 1, 'info' => 2 );
		usort( $results, static fn( $a, $b ) => $rank[ $a['severity'] ] <=> $rank[ $b['severity'] ] );

		return array(
			'wordpress_version' => $wp_ver,
			'php_version'       => PHP_VERSION,
			'totals'            => array(
				'installed'          => count( $all ),
				'active'             => count( $active ),
				'inactive'           => count( $all ) - count( $active ),
				'with_issues'        => count( $results ),
				'critical'           => count( array_filter( $results, static fn( $r ) => 'critical' === $r['severity'] ) ),
				'overlapping_groups' => count( $overlaps ),
			),
			'overlaps'          => $overlaps,
			'plugins'           => $results,
			'note'              => 'Code-pattern hits are signals for a human to review, not proof of malware. Many legitimate plugins use base64_decode or file_get_contents.',
		);
	}

	/**
	 * Grep a plugin's PHP for risky constructs.
	 *
	 * Capped at 40 files / 500 KB each so a huge plugin cannot stall the request.
	 *
	 * @param string $plugin_file
	 * @return array<int, array<string, mixed>>
	 */
	private static function scan_plugin_code( $plugin_file ) {
		$dir = WP_PLUGIN_DIR . '/' . dirname( $plugin_file );
		if ( '.' === dirname( $plugin_file ) ) {
			$dir = WP_PLUGIN_DIR;
		}
		if ( ! is_dir( $dir ) || ! is_readable( $dir ) ) {
			return array();
		}

		$files = array();
		try {
			$it = new RecursiveIteratorIterator(
				new RecursiveDirectoryIterator( $dir, FilesystemIterator::SKIP_DOTS )
			);
			foreach ( $it as $f ) {
				if ( count( $files ) >= 40 ) {
					break;
				}
				if ( $f->isFile() && 'php' === strtolower( $f->getExtension() ) && $f->getSize() < 512000 ) {
					$files[] = $f->getPathname();
				}
			}
		} catch ( Exception $e ) {
			return array();
		}

		$found = array();
		$seen  = array();
		foreach ( $files as $path ) {
			$code = @file_get_contents( $path );
			if ( false === $code ) {
				continue;
			}
			foreach ( self::RISKY_PATTERNS as $rule ) {
				if ( isset( $seen[ $rule['pattern'] ] ) ) {
					continue; // Report each pattern once per plugin, not once per file.
				}
				if ( ! preg_match( $rule['pattern'], $code, $m, PREG_OFFSET_CAPTURE ) ) {
					continue;
				}

				$severity = $rule['severity'];
				$extra    = '';

				// A destructive call is only alarming when it can fire unattended.
				// wp_delete_post() behind a capability check is a feature; the same call
				// running from a bootstrap method on every page load is what silently
				// destroyed Elementor layouts on theiimt.com. Look at the enclosing
				// function to tell the two apart instead of flagging both.
				if ( in_array( $rule['severity'], array( 'warn' ), true ) && self::is_destructive_rule( $rule['pattern'] ) ) {
					$scope = self::enclosing_scope( $code, (int) $m[0][1] );
					if ( self::has_guard( $scope ) ) {
						$severity = 'info';
						$extra    = ' It sits behind a permission or nonce check, which is the correct pattern.';
					} else {
						$severity = 'critical';
						$extra    = ' It is NOT guarded by a capability or nonce check, so it can run unattended on a normal page load. Review this before activating the plugin.';
					}
				}

				$seen[ $rule['pattern'] ] = true;
				$found[]                  = self::issue(
					'risky_code',
					$severity,
					$rule['why'] . $extra . ' Found in ' . str_replace( WP_PLUGIN_DIR . '/', '', $path ) . '.'
				);
			}
		}
		return $found;
	}

	/**
	 * Does this rule describe a call that destroys data?
	 *
	 * @param string $pattern
	 * @return bool
	 */
	private static function is_destructive_rule( $pattern ) {
		return (bool) preg_match( '/delete_post_meta|wp_delete_post/', $pattern );
	}

	/**
	 * Source of the function containing $offset, so a match can be judged in context.
	 *
	 * Brace-counts forward from the nearest preceding `function` keyword. Falls back to
	 * a fixed window when the structure cannot be resolved — this is a heuristic for
	 * ranking findings, not a parser.
	 *
	 * @param string $code
	 * @param int    $offset
	 * @return string
	 */
	private static function enclosing_scope( $code, $offset ) {
		$start = strrpos( substr( $code, 0, $offset ), 'function ' );
		if ( false === $start ) {
			// File scope: nothing wraps it, so it runs the moment the file is included.
			return substr( $code, max( 0, $offset - 1500 ), 3000 );
		}

		$brace = strpos( $code, '{', $start );
		if ( false === $brace ) {
			return substr( $code, $start, 3000 );
		}

		$depth = 0;
		$len   = strlen( $code );
		for ( $i = $brace; $i < $len; $i++ ) {
			if ( '{' === $code[ $i ] ) {
				++$depth;
			} elseif ( '}' === $code[ $i ] ) {
				--$depth;
				if ( 0 === $depth ) {
					return substr( $code, $start, $i - $start + 1 );
				}
			}
			// Runaway guard for minified or malformed files.
			if ( $i - $start > 40000 ) {
				break;
			}
		}
		return substr( $code, $start, 3000 );
	}

	/**
	 * Is this block gated by a permission or intent check?
	 *
	 * @param string $scope
	 * @return bool
	 */
	private static function has_guard( $scope ) {
		return (bool) preg_match(
			'/current_user_can\s*\(|check_admin_referer\s*\(|check_ajax_referer\s*\(|wp_verify_nonce\s*\(|user_can\s*\(/i',
			$scope
		);
	}

	/**
	 * Look a slug up on WordPress.org. Cached, and failures are cached too so a
	 * flaky network does not mean one blocking request per plugin every time.
	 *
	 * @param string $slug
	 * @return array<string, mixed>
	 */
	private static function repo_info( $slug ) {
		$key    = 'axon_repo_' . md5( $slug );
		$cached = get_transient( $key );
		if ( is_array( $cached ) ) {
			return $cached;
		}

		$res = wp_remote_get(
			add_query_arg(
				array(
					'action'         => 'plugin_information',
					'request[slug]'  => $slug,
					'request[fields][sections]' => 'false',
				),
				'https://api.wordpress.org/plugins/info/1.2/'
			),
			array( 'timeout' => 8 )
		);

		$out = array( 'status' => 'unknown' );

		if ( ! is_wp_error( $res ) ) {
			$body = json_decode( (string) wp_remote_retrieve_body( $res ), true );
			if ( is_array( $body ) ) {
				if ( ! empty( $body['error'] ) ) {
					// The API says "closed" for withdrawn plugins and 404s for ones that never existed.
					$out['status'] = ( false !== stripos( (string) $body['error'], 'closed' ) ) ? 'closed' : 'unknown';
				} elseif ( ! empty( $body['version'] ) ) {
					$out = array(
						'status'          => 'ok',
						'version'         => (string) $body['version'],
						'last_updated_ts' => ! empty( $body['last_updated'] ) ? strtotime( (string) $body['last_updated'] ) : 0,
						'active_installs' => (int) ( $body['active_installs'] ?? 0 ),
					);
				}
			}
		}

		set_transient( $key, $out, self::REPO_CACHE_TTL );
		return $out;
	}

	/* ===================================================================== */
	/* audit_site_hardening                                                   */
	/* ===================================================================== */

	/**
	 * @param array $args
	 * @return array|WP_Error
	 */
	public static function audit_site_hardening( $args ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'forbidden', 'You need the manage_options capability to audit site hardening.' );
		}

		$dormant_days = isset( $args['dormant_days'] ) ? max( 30, absint( $args['dormant_days'] ) ) : 365;
		$f            = array();

		// --- Versions
		$core_latest = self::latest_core_version();
		$core_now    = get_bloginfo( 'version' );
		$f[]         = self::issue(
			'core_version',
			( $core_latest && version_compare( $core_now, $core_latest, '<' ) ) ? 'critical' : 'ok',
			$core_latest && version_compare( $core_now, $core_latest, '<' )
				? "WordPress {$core_now} is behind the current release {$core_latest}. Core updates almost always contain security fixes."
				: "WordPress {$core_now} is current."
		);

		$php_eol = version_compare( PHP_VERSION, '8.1', '<' );
		$f[]     = self::issue(
			'php_version',
			$php_eol ? 'critical' : 'ok',
			$php_eol
				? 'PHP ' . PHP_VERSION . ' no longer receives security patches. Ask your host to move to PHP 8.1 or newer.'
				: 'PHP ' . PHP_VERSION . ' is supported.'
		);

		// --- Configuration constants
		$f[] = self::issue(
			'file_editor',
			( defined( 'DISALLOW_FILE_EDIT' ) && DISALLOW_FILE_EDIT ) ? 'ok' : 'warn',
			( defined( 'DISALLOW_FILE_EDIT' ) && DISALLOW_FILE_EDIT )
				? 'The dashboard plugin/theme file editor is disabled.'
				: "The dashboard file editor is enabled. Anyone who gets one admin session can write PHP straight to your server. Add define('DISALLOW_FILE_EDIT', true); to wp-config.php."
		);

		$debug_shown = defined( 'WP_DEBUG' ) && WP_DEBUG && ( ! defined( 'WP_DEBUG_DISPLAY' ) || WP_DEBUG_DISPLAY );
		$f[]         = self::issue(
			'debug_output',
			$debug_shown ? 'critical' : 'ok',
			$debug_shown
				? 'WP_DEBUG output is being displayed publicly, which leaks file paths and database details. Set WP_DEBUG_DISPLAY to false.'
				: 'Debug output is not displayed publicly.'
		);

		$f[] = self::issue(
			'table_prefix',
			( 'wp_' === $GLOBALS['wpdb']->prefix ) ? 'info' : 'ok',
			( 'wp_' === $GLOBALS['wpdb']->prefix )
				? 'Database uses the default wp_ prefix. Minor hardening only — do not rename tables on a live site to "fix" this; the risk of breaking things is higher than the benefit.'
				: 'Non-default database prefix in use.'
		);

		// --- Exposure
		$xmlrpc = (bool) apply_filters( 'xmlrpc_enabled', true );
		$f[]    = self::issue(
			'xmlrpc',
			$xmlrpc ? 'warn' : 'ok',
			$xmlrpc
				? 'XML-RPC is enabled. It is a favourite target for brute-force amplification. Disable it unless the Jetpack app or a remote publisher needs it.'
				: 'XML-RPC is disabled.'
		);

		$users_public = self::rest_users_public();
		$f[]          = self::issue(
			'user_enumeration',
			$users_public ? 'warn' : 'ok',
			$users_public
				? 'The REST endpoint /wp-json/wp/v2/users lists usernames to anonymous visitors, handing attackers half of every login.'
				: 'User listing is not exposed to anonymous requests.'
		);

		$f[] = self::issue(
			'ssl',
			is_ssl() || 0 === stripos( (string) get_option( 'home' ), 'https' ) ? 'ok' : 'critical',
			is_ssl() || 0 === stripos( (string) get_option( 'home' ), 'https' )
				? 'Site is served over HTTPS.'
				: 'Site is not using HTTPS. Logins and form submissions travel in clear text.'
		);

		// --- Accounts
		$admins  = get_users( array( 'role' => 'administrator', 'fields' => array( 'ID', 'user_login', 'user_email' ) ) );
		$f[]     = self::issue(
			'admin_count',
			count( $admins ) > 3 ? 'warn' : 'ok',
			sprintf( '%d administrator account(s). Every one is a full compromise if taken over — keep the number as low as you can.', count( $admins ) )
		);

		$bad_names = array();
		$dormant   = array();
		foreach ( $admins as $u ) {
			if ( in_array( strtolower( $u->user_login ), array( 'admin', 'administrator', 'root', 'test' ), true ) ) {
				$bad_names[] = $u->user_login;
			}
			$last = self::last_activity( (int) $u->ID );
			if ( $last && ( time() - $last ) > $dormant_days * DAY_IN_SECONDS ) {
				$dormant[] = $u->user_login . ' (' . human_time_diff( $last ) . ' ago)';
			} elseif ( ! $last ) {
				$dormant[] = $u->user_login . ' (no content ever published)';
			}
		}

		$f[] = self::issue(
			'guessable_admin_usernames',
			$bad_names ? 'warn' : 'ok',
			$bad_names
				? 'Guessable administrator username(s): ' . implode( ', ', $bad_names ) . '. Attackers start here, so half the login is already known.'
				: 'No obviously guessable administrator usernames.'
		);

		$f[] = self::issue(
			'dormant_admins',
			$dormant ? 'warn' : 'ok',
			$dormant
				? 'Administrator accounts with no recent activity: ' . implode( '; ', $dormant ) . '. Unused admin accounts are the ones nobody notices being used. Note: this measures published content, so a legitimate admin who only changes settings can appear dormant.'
				: 'All administrator accounts show recent activity.'
		);

		// --- Response headers on the front page
		$f = array_merge( $f, self::header_findings() );

		$rank = array( 'critical' => 0, 'warn' => 1, 'info' => 2, 'ok' => 3 );
		usort( $f, static fn( $a, $b ) => $rank[ $a['severity'] ] <=> $rank[ $b['severity'] ] );

		$crit = count( array_filter( $f, static fn( $x ) => 'critical' === $x['severity'] ) );
		$warn = count( array_filter( $f, static fn( $x ) => 'warn' === $x['severity'] ) );

		return array(
			'site'     => home_url(),
			'summary'  => array(
				'critical' => $crit,
				'warnings' => $warn,
				'grade'    => $crit > 0 ? 'D' : ( $warn > 3 ? 'C' : ( $warn > 0 ? 'B' : 'A' ) ),
			),
			'findings' => $f,
		);
	}

	/**
	 * Security-relevant response headers, checked by asking our own front page.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private static function header_findings() {
		$res = wp_remote_get( home_url( '/' ), array( 'timeout' => 10, 'sslverify' => false ) );
		if ( is_wp_error( $res ) ) {
			return array( self::issue( 'headers', 'info', 'Could not fetch the home page to inspect security headers.' ) );
		}

		$hdr  = array_change_key_case( (array) wp_remote_retrieve_headers( $res )->getAll(), CASE_LOWER );
		$want = array(
			'strict-transport-security' => 'Tells browsers to only ever use HTTPS for this domain.',
			'x-content-type-options'    => 'Stops browsers guessing a file type and executing an upload as script.',
			'x-frame-options'           => 'Prevents your pages being framed for clickjacking.',
			'referrer-policy'           => 'Stops full URLs leaking to third parties.',
			'content-security-policy'   => 'The strongest defence against injected scripts.',
		);

		$out = array();
		foreach ( $want as $h => $why ) {
			$out[] = self::issue(
				'header_' . str_replace( '-', '_', $h ),
				isset( $hdr[ $h ] ) ? 'ok' : 'info',
				isset( $hdr[ $h ] ) ? "Header {$h} is set." : "Missing header {$h}. {$why}"
			);
		}

		if ( ! empty( $hdr['x-powered-by'] ) ) {
			$out[] = self::issue( 'version_disclosure', 'info', 'X-Powered-By reveals ' . ( is_array( $hdr['x-powered-by'] ) ? implode( ', ', $hdr['x-powered-by'] ) : $hdr['x-powered-by'] ) . '. Minor, but it tells an attacker which exploits to try first.' );
		}

		return $out;
	}

	/**
	 * Most recent published content by a user — our proxy for "is this account in use".
	 *
	 * @param int $user_id
	 * @return int Unix timestamp, 0 if never.
	 */
	private static function last_activity( $user_id ) {
		global $wpdb;
		$date = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT post_date_gmt FROM {$wpdb->posts}
				 WHERE post_author = %d AND post_status NOT IN ('auto-draft')
				 ORDER BY post_date_gmt DESC LIMIT 1",
				$user_id
			)
		);
		return $date ? (int) strtotime( $date . ' GMT' ) : 0;
	}

	/**
	 * @return bool
	 */
	private static function rest_users_public() {
		$res = wp_remote_get(
			rest_url( 'wp/v2/users' ),
			array( 'timeout' => 10, 'sslverify' => false, 'cookies' => array() )
		);
		if ( is_wp_error( $res ) ) {
			return false;
		}
		if ( 200 !== (int) wp_remote_retrieve_response_code( $res ) ) {
			return false;
		}
		$body = json_decode( (string) wp_remote_retrieve_body( $res ), true );
		return is_array( $body ) && ! empty( $body );
	}

	/**
	 * @return string
	 */
	private static function latest_core_version() {
		$cached = get_transient( 'axon_core_latest' );
		if ( is_string( $cached ) && '' !== $cached ) {
			return $cached;
		}
		$res = wp_remote_get( 'https://api.wordpress.org/core/version-check/1.7/', array( 'timeout' => 8 ) );
		if ( is_wp_error( $res ) ) {
			return '';
		}
		$body = json_decode( (string) wp_remote_retrieve_body( $res ), true );
		$ver  = $body['offers'][0]['current'] ?? '';
		if ( $ver ) {
			set_transient( 'axon_core_latest', $ver, HOUR_IN_SECONDS * 12 );
		}
		return (string) $ver;
	}

	/* ===================================================================== */
	/* check_core_integrity                                                   */
	/* ===================================================================== */

	/**
	 * @return array|WP_Error
	 */
	public static function check_core_integrity() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'forbidden', 'You need the manage_options capability to check core integrity.' );
		}

		$version = get_bloginfo( 'version' );
		$locale  = get_locale();

		$res = wp_remote_get(
			add_query_arg(
				array( 'version' => $version, 'locale' => $locale ),
				'https://api.wordpress.org/core/checksums/1.0/'
			),
			array( 'timeout' => 20 )
		);
		if ( is_wp_error( $res ) ) {
			return new WP_Error( 'checksums_unavailable', 'Could not reach the WordPress.org checksums API: ' . $res->get_error_message() );
		}

		$body      = json_decode( (string) wp_remote_retrieve_body( $res ), true );
		$checksums = $body['checksums'] ?? null;

		// en_US is the fallback when a locale has no separate checksum set.
		if ( ! is_array( $checksums ) && 'en_US' !== $locale ) {
			$res       = wp_remote_get( "https://api.wordpress.org/core/checksums/1.0/?version={$version}&locale=en_US", array( 'timeout' => 20 ) );
			$body      = is_wp_error( $res ) ? array() : json_decode( (string) wp_remote_retrieve_body( $res ), true );
			$checksums = $body['checksums'] ?? null;
		}

		if ( ! is_array( $checksums ) ) {
			return new WP_Error( 'no_checksums', "WordPress.org has no checksums for version {$version} ({$locale}). This is normal for release candidates and very new releases." );
		}

		$modified = array();
		$missing  = array();
		$checked  = 0;

		foreach ( $checksums as $rel => $md5 ) {
			// wp-content is the user's own files; it is never part of core integrity.
			if ( 0 === strpos( $rel, 'wp-content/' ) ) {
				continue;
			}
			$path = ABSPATH . $rel;
			if ( ! file_exists( $path ) ) {
				$missing[] = $rel;
				continue;
			}
			++$checked;
			if ( md5_file( $path ) !== $md5 ) {
				$modified[] = $rel;
			}
		}

		$severity = $modified ? 'critical' : 'ok';

		return array(
			'wordpress_version' => $version,
			'locale'            => $locale,
			'files_checked'     => $checked,
			'modified_files'    => $modified,
			'missing_files'     => $missing,
			'severity'          => $severity,
			'verdict'           => $modified
				? 'Core files differ from the official release. This is one of the strongest signals of a compromise — but a host applying its own patches, or a half-finished update, produces the same result. Investigate each file before panicking.'
				: 'All core files match the official WordPress release.',
			'next_step'         => $modified
				? 'Compare each modified file against the official copy, then reinstall core from Dashboard > Updates > Reinstall.'
				: '',
		);
	}

	/* ===================================================================== */

	/**
	 * @param string $id
	 * @param string $severity critical|warn|info|ok
	 * @param string $message
	 * @return array<string, string>
	 */
	private static function issue( $id, $severity, $message ) {
		return array(
			'id'       => $id,
			'severity' => $severity,
			'message'  => $message,
		);
	}
}
