<?php
/**
 * SEO tools: read/write the active SEO plugin's meta and run a pre-publish readiness check.
 *
 * Logic lives in static methods so it can be re-registered against
 * WordPress/mcp-adapter (`wp_register_ability()`) later without rewriting it.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Axon_SEO_Tools {

	/** Yoast post-meta keys. */
	const META_TITLE   = '_yoast_wpseo_title';
	const META_DESC    = '_yoast_wpseo_metadesc';
	const META_FOCUSKW = '_yoast_wpseo_focuskw';

	/** Rank Math post-meta keys. Different names entirely; neither plugin reads the other's. */
	const RM_TITLE   = 'rank_math_title';
	const RM_DESC    = 'rank_math_description';
	const RM_FOCUSKW = 'rank_math_focus_keyword';

	/**
	 * Which SEO plugin's meta keys this site actually uses.
	 *
	 * This class originally wrote Yoast keys unconditionally. On a Rank Math site that is a
	 * silent no-op: the write succeeds, the tool reports success, and Rank Math goes on
	 * showing "Keyword: Not Set" because it reads `rank_math_*` and never looks at
	 * `_yoast_wpseo_*`. Whole publishing routines were built around browser automation to
	 * work around what was really this bug.
	 *
	 * Detection is by active plugin, and both are written when both are somehow active, so
	 * whichever one is rendering the page gets the value.
	 *
	 * @return array<int, array{0:string,1:string,2:string}> Key triples: title, description, focus keyword.
	 */
	private static function meta_key_sets() {
		$sets = array();

		if ( defined( 'RANK_MATH_VERSION' ) || class_exists( 'RankMath' ) ) {
			$sets[] = array( self::RM_TITLE, self::RM_DESC, self::RM_FOCUSKW );
		}
		if ( self::yoast_active() ) {
			$sets[] = array( self::META_TITLE, self::META_DESC, self::META_FOCUSKW );
		}

		// No SEO plugin detected: still store somewhere consistent so the values survive and
		// this plugin's own schema/llms.txt generators can read them back.
		if ( ! $sets ) {
			$sets[] = array( self::RM_TITLE, self::RM_DESC, self::RM_FOCUSKW );
		}

		return $sets;
	}

	/**
	 * Name of the SEO plugin detected, for reporting back to the caller.
	 *
	 * @return string
	 */
	private static function seo_plugin_name() {
		$names = array();
		if ( defined( 'RANK_MATH_VERSION' ) || class_exists( 'RankMath' ) ) {
			$names[] = 'Rank Math';
		}
		if ( self::yoast_active() ) {
			$names[] = 'Yoast SEO';
		}

		return $names ? implode( ' + ', $names ) : 'none detected';
	}

	/**
	 * Tool definitions for the base plugin's register_tool().
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function tools() {
		return array(
			array(
				'name'        => 'get_seo_meta',
				'description' => 'Get the SEO metadata (meta title, meta description, focus keyword) for a post or page. Reads whichever SEO plugin the site actually uses — Rank Math or Yoast.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'post_id' => array(
							'type'        => 'integer',
							'description' => 'The ID of the post or page.',
						),
					),
					'required'   => array( 'post_id' ),
				),
				'callback'    => array( __CLASS__, 'get_seo_meta' ),
			),
			array(
				'name'        => 'set_seo_meta',
				'description' => 'Set the SEO metadata for a post or page (meta title, meta description, and/or focus keyword). Only provided fields are changed. Detects whether the site runs Rank Math or Yoast and writes that plugin\'s own meta keys, so the values really do appear in the SEO plugin and in Google rather than being silently ignored.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'post_id'          => array(
							'type'        => 'integer',
							'description' => 'The ID of the post or page.',
						),
						'meta_title'       => array(
							'type'        => 'string',
							'description' => 'SEO meta title (the <title> shown in search results). Aim for ~50-60 characters.',
						),
						'meta_description' => array(
							'type'        => 'string',
							'description' => 'SEO meta description shown under the title in search results. Aim for ~120-156 characters.',
						),
						'focus_keyword'    => array(
							'type'        => 'string',
							'description' => 'The primary keyword/phrase this content targets.',
						),
					),
					'required'   => array( 'post_id' ),
				),
				'callback'    => array( __CLASS__, 'set_seo_meta' ),
			),
			array(
				'name'        => 'seo_readiness_check',
				'description' => 'Run a pre-publish SEO/accessibility checklist on a post: title length, meta description presence/length, focus keyword set, featured image present, and images missing alt text. Read-only.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'post_id' => array(
							'type'        => 'integer',
							'description' => 'The ID of the post or page to check.',
						),
					),
					'required'   => array( 'post_id' ),
				),
				'callback'    => array( __CLASS__, 'seo_readiness_check' ),
			),
		);
	}

	/**
	 * @param array $args
	 * @return array|WP_Error
	 */
	public static function get_seo_meta( $args ) {
		$post = self::resolve_post( $args, 'read' );
		if ( is_wp_error( $post ) ) {
			return $post;
		}

		// Read from the first key set that actually holds something, so a value written by
		// either plugin is found rather than reported as empty.
		$title = '';
		$desc  = '';
		$kw    = '';

		foreach ( self::meta_key_sets() as $keys ) {
			$title = $title ? $title : (string) get_post_meta( $post->ID, $keys[0], true );
			$desc  = $desc ? $desc : (string) get_post_meta( $post->ID, $keys[1], true );
			$kw    = $kw ? $kw : (string) get_post_meta( $post->ID, $keys[2], true );
		}

		return array(
			'post_id'          => $post->ID,
			'seo_plugin'       => self::seo_plugin_name(),
			'meta_title'       => $title,
			'meta_description' => $desc,
			'focus_keyword'    => $kw,
		);
	}

	/**
	 * @param array $args
	 * @return array|WP_Error
	 */
	public static function set_seo_meta( $args ) {
		$post = self::resolve_post( $args, 'edit' );
		if ( is_wp_error( $post ) ) {
			return $post;
		}

		$updated = array();
		$sets    = self::meta_key_sets();

		foreach ( $sets as $keys ) {
			if ( array_key_exists( 'meta_title', $args ) ) {
				update_post_meta( $post->ID, $keys[0], sanitize_text_field( $args['meta_title'] ) );
				$updated['meta_title'] = (string) $args['meta_title'];
			}
			if ( array_key_exists( 'meta_description', $args ) ) {
				update_post_meta( $post->ID, $keys[1], sanitize_textarea_field( $args['meta_description'] ) );
				$updated['meta_description'] = (string) $args['meta_description'];
			}
			if ( array_key_exists( 'focus_keyword', $args ) ) {
				update_post_meta( $post->ID, $keys[2], sanitize_text_field( $args['focus_keyword'] ) );
				$updated['focus_keyword'] = (string) $args['focus_keyword'];
			}
		}

		if ( empty( $updated ) ) {
			return new WP_Error( 'no_fields', 'No SEO fields provided. Pass at least one of: meta_title, meta_description, focus_keyword.' );
		}

		return array(
			'post_id'    => $post->ID,
			'seo_plugin' => self::seo_plugin_name(),
			'written_to' => array_map(
				static function ( $k ) {
					return $k[0];
				},
				$sets
			),
			'updated'    => $updated,
			'note'       => 'none detected' === self::seo_plugin_name()
				? 'No SEO plugin is active, so these values are stored but nothing is rendering them yet.'
				: null,
		);
	}

	/**
	 * @param array $args
	 * @return array|WP_Error
	 */
	public static function seo_readiness_check( $args ) {
		$post = self::resolve_post( $args, 'read' );
		if ( is_wp_error( $post ) ) {
			return $post;
		}

		$title       = get_post_meta( $post->ID, self::META_TITLE, true );
		$title       = $title !== '' ? $title : $post->post_title;
		$description = (string) get_post_meta( $post->ID, self::META_DESC, true );
		$focus_kw    = (string) get_post_meta( $post->ID, self::META_FOCUSKW, true );
		$title_len   = function_exists( 'mb_strlen' ) ? mb_strlen( $title ) : strlen( $title );
		$desc_len    = function_exists( 'mb_strlen' ) ? mb_strlen( $description ) : strlen( $description );

		$checks = array(
			array(
				'check' => 'title_length',
				'pass'  => $title_len >= 15 && $title_len <= 60,
				'value' => $title_len,
				'hint'  => 'SEO title should be roughly 15-60 characters.',
			),
			array(
				'check' => 'meta_description_present',
				'pass'  => $description !== '',
				'hint'  => 'Add a meta description.',
			),
			array(
				'check' => 'meta_description_length',
				'pass'  => $desc_len >= 70 && $desc_len <= 156,
				'value' => $desc_len,
				'hint'  => 'Meta description should be roughly 70-156 characters.',
			),
			array(
				'check' => 'focus_keyword_set',
				'pass'  => $focus_kw !== '',
				'hint'  => 'Set a focus keyword.',
			),
			array(
				'check' => 'focus_keyword_in_title',
				'pass'  => $focus_kw !== '' && stripos( $title, $focus_kw ) !== false,
				'hint'  => 'Include the focus keyword in the SEO title.',
			),
			array(
				'check' => 'featured_image_set',
				'pass'  => has_post_thumbnail( $post->ID ),
				'hint'  => 'Set a featured image.',
			),
			array(
				'check' => 'images_missing_alt',
				'pass'  => 0 === self::count_images_missing_alt( $post->post_content ),
				'value' => self::count_images_missing_alt( $post->post_content ),
				'hint'  => 'Every content image should have descriptive alt text (accessibility + AEO).',
			),
		);

		$failed = array_values(
			array_filter(
				$checks,
				static function ( $c ) {
					return empty( $c['pass'] );
				}
			)
		);

		return array(
			'post_id'    => $post->ID,
			'ready'      => empty( $failed ),
			'checks'     => $checks,
			'to_improve' => wp_list_pluck( $failed, 'hint' ),
		);
	}

	/* ---------- helpers ---------- */

	/**
	 * Validate post_id and capability. $mode is 'read' or 'edit'.
	 *
	 * @return WP_Post|WP_Error
	 */
	protected static function resolve_post( $args, $mode ) {
		$post_id = isset( $args['post_id'] ) ? absint( $args['post_id'] ) : 0;
		if ( ! $post_id ) {
			return new WP_Error( 'invalid_post_id', 'A valid post_id is required.' );
		}
		$post = get_post( $post_id );
		if ( ! $post ) {
			return new WP_Error( 'not_found', "No post found with ID {$post_id}." );
		}
		$cap = ( 'edit' === $mode ) ? 'edit_post' : 'read_post';
		if ( ! current_user_can( $cap, $post_id ) ) {
			return new WP_Error( 'forbidden', 'You do not have permission to ' . $mode . ' this post.' );
		}
		return $post;
	}

	protected static function yoast_active() {
		return defined( 'WPSEO_VERSION' ) || class_exists( 'WPSEO_Options' );
	}

	protected static function count_images_missing_alt( $content ) {
		if ( false === strpos( $content, '<img' ) ) {
			return 0;
		}
		if ( ! preg_match_all( '/<img\b[^>]*>/i', $content, $imgs ) ) {
			return 0;
		}
		$missing = 0;
		foreach ( $imgs[0] as $img ) {
			if ( ! preg_match( '/\balt\s*=\s*("|\')(.*?)\1/i', $img, $m ) || '' === trim( $m[2] ) ) {
				$missing++;
			}
		}
		return $missing;
	}
}
