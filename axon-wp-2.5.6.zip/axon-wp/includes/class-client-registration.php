<?php
/**
 * Dynamic Client Registration (RFC 7591).
 *
 * Lets an MCP client (claude.ai, etc.) register itself by POSTing its
 * redirect_uris — no manual "create an app" step for the site owner.
 *
 * @package MCP_OAuth_Bridge
 */

declare(strict_types=1);

namespace MCP_OAuth_Bridge;

use WP_REST_Request;
use WP_REST_Response;
use WP_Error;

defined( 'ABSPATH' ) || exit;

class Client_Registration {

	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	public function register_routes(): void {
		register_rest_route(
			'mcp-oauth/v1',
			'/register',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle_register' ),
				'permission_callback' => '__return_true', // Public per RFC 7591 — anyone can register a client.
			)
		);
	}

	public function handle_register( WP_REST_Request $request ) {
		$params        = $request->get_json_params();
		$redirect_uris = isset( $params['redirect_uris'] ) && is_array( $params['redirect_uris'] ) ? $params['redirect_uris'] : array();
		$client_name   = isset( $params['client_name'] ) ? sanitize_text_field( $params['client_name'] ) : 'Unnamed MCP Client';

		if ( empty( $redirect_uris ) ) {
			return new WP_Error( 'invalid_client_metadata', 'redirect_uris is required.', array( 'status' => 400 ) );
		}

		foreach ( $redirect_uris as $uri ) {
			// Require HTTPS redirect URIs, except localhost (used by local/dev MCP clients).
			$scheme = wp_parse_url( $uri, PHP_URL_SCHEME );
			$host   = wp_parse_url( $uri, PHP_URL_HOST );
			$is_localhost = in_array( $host, array( 'localhost', '127.0.0.1' ), true );
			if ( 'https' !== $scheme && ! $is_localhost ) {
				return new WP_Error( 'invalid_redirect_uri', 'redirect_uris must use https (localhost exempted).', array( 'status' => 400 ) );
			}
		}

		$client = Token_Store::create_client( $client_name, $redirect_uris, 'none' );

		return new WP_REST_Response(
			array(
				'client_id'                 => $client['client_id'],
				'client_name'                => $client_name,
				'redirect_uris'              => $client['redirect_uris'],
				'token_endpoint_auth_method' => 'none',
				'grant_types'                => array( 'authorization_code', 'refresh_token' ),
				'response_types'             => array( 'code' ),
			),
			201
		);
	}
}
