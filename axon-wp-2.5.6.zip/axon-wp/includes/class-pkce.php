<?php
/**
 * PKCE (RFC 7636) verification. OAuth 2.1 requires S256 only — 'plain' is rejected.
 *
 * @package MCP_OAuth_Bridge
 */

declare(strict_types=1);

namespace MCP_OAuth_Bridge;

defined( 'ABSPATH' ) || exit;

class PKCE {

	public static function verify( string $code_verifier, string $code_challenge, string $method ): bool {
		if ( 'S256' !== $method ) {
			// OAuth 2.1: plain method is not permitted.
			return false;
		}

		if ( strlen( $code_verifier ) < 43 || strlen( $code_verifier ) > 128 ) {
			return false;
		}

		$computed = self::base64url_encode( hash( 'sha256', $code_verifier, true ) );

		return hash_equals( $code_challenge, $computed );
	}

	public static function base64url_encode( string $data ): string {
		return rtrim( strtr( base64_encode( $data ), '+/', '-_' ), '=' );
	}
}
