<?php
/**
 * Authorization endpoint: shows the consent screen and issues auth codes.
 *
 * Deliberately NOT a register_rest_route() endpoint. WordPress's REST API
 * requires an X-WP-Nonce header for cookie-based auth (rest_cookie_check_errors),
 * which a browser navigating here directly can't provide. This is a normal
 * browser-navigated page in the OAuth redirect flow, so it hooks directly into
 * `init` (same as the discovery endpoints) and uses plain WP cookie auth —
 * exactly how wp-admin itself authenticates page loads.
 *
 * @package MCP_OAuth_Bridge
 */

declare(strict_types=1);

namespace MCP_OAuth_Bridge;

use WP_Error;

defined( 'ABSPATH' ) || exit;

class Authorize {

	const NONCE_ACTION = 'mcp_oauth_consent';
	const PATH          = '/wp-json/mcp-oauth/v1/authorize';

	public function __construct() {
		add_action( 'init', array( $this, 'maybe_handle' ), 0 );
	}

	public function maybe_handle(): void {
		$path = parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ); // phpcs:ignore
		$path = is_string( $path ) ? untrailingslashit( $path ) : '';

		if ( self::PATH !== $path ) {
			return;
		}

		if ( 'POST' === ( $_SERVER['REQUEST_METHOD'] ?? 'GET' ) ) {
			$this->handle_post();
		} else {
			$this->handle_get();
		}
		exit;
	}

	/**
	 * Validate the incoming authorize request's client/redirect/PKCE params.
	 *
	 * @return array{client:array,redirect_uri:string,params:array}|WP_Error
	 */
	private function validate_request( array $input ) {
		$client_id            = (string) ( $input['client_id'] ?? '' );
		$redirect_uri          = (string) ( $input['redirect_uri'] ?? '' );
		$response_type         = (string) ( $input['response_type'] ?? '' );
		$code_challenge        = (string) ( $input['code_challenge'] ?? '' );
		$code_challenge_method = (string) ( $input['code_challenge_method'] ?? '' );

		if ( 'code' !== $response_type ) {
			return new WP_Error( 'unsupported_response_type', 'Only response_type=code is supported.', array( 'status' => 400 ) );
		}

		if ( empty( $client_id ) || empty( $redirect_uri ) ) {
			return new WP_Error( 'invalid_request', 'client_id and redirect_uri are required.', array( 'status' => 400 ) );
		}

		if ( empty( $code_challenge ) || 'S256' !== $code_challenge_method ) {
			return new WP_Error( 'invalid_request', 'PKCE code_challenge with S256 is required (OAuth 2.1).', array( 'status' => 400 ) );
		}

		$client = Token_Store::get_client( $client_id );
		if ( ! $client ) {
			return new WP_Error( 'invalid_client', 'Unknown client_id.', array( 'status' => 400 ) );
		}

		// Exact-match redirect_uri against the client's registered URIs — prevents auth-code interception via open redirect.
		if ( ! in_array( $redirect_uri, $client['redirect_uris'], true ) ) {
			return new WP_Error( 'invalid_request', 'redirect_uri does not match a registered URI for this client.', array( 'status' => 400 ) );
		}

		return array(
			'client'       => $client,
			'redirect_uri' => $redirect_uri,
			'params'       => array(
				'client_id'             => $client_id,
				'redirect_uri'          => $redirect_uri,
				'code_challenge'        => $code_challenge,
				'code_challenge_method' => $code_challenge_method,
				'state'                 => (string) ( $input['state'] ?? '' ),
				'scope'                 => (string) ( $input['scope'] ?? 'mcp' ),
			),
		);
	}

	private function handle_get(): void {
		$validated = $this->validate_request( $_GET ); // phpcs:ignore
		if ( is_wp_error( $validated ) ) {
			$this->render_error_page( $validated );
			return;
		}

		if ( ! is_user_logged_in() ) {
			$login_url = wp_login_url( $_SERVER['REQUEST_URI'] ?? '' ); // phpcs:ignore
			wp_safe_redirect( $login_url );
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			$this->render_error_page( new WP_Error( 'access_denied', 'Only administrators can authorize MCP access.', array( 'status' => 403 ) ) );
			return;
		}

		$this->render_consent_page( $validated['client'], $validated['params'] );
	}

	private function handle_post(): void {
		if ( ! is_user_logged_in() || ! current_user_can( 'manage_options' ) ) {
			$this->render_error_page( new WP_Error( 'access_denied', 'You must be logged in as an administrator.', array( 'status' => 403 ) ) );
			return;
		}

		if ( ! wp_verify_nonce( (string) ( $_POST['_wpnonce'] ?? '' ), self::NONCE_ACTION ) ) { // phpcs:ignore
			$this->render_error_page( new WP_Error( 'invalid_nonce', 'Consent form expired — please try connecting again.', array( 'status' => 400 ) ) );
			return;
		}

		$validated = $this->validate_request( $_POST ); // phpcs:ignore
		if ( is_wp_error( $validated ) ) {
			$this->render_error_page( $validated );
			return;
		}

		$redirect_uri = $validated['params']['redirect_uri'];
		$state        = $validated['params']['state'];
		$decision     = (string) ( $_POST['mcp_oauth_decision'] ?? '' ); // phpcs:ignore

		if ( 'approve' !== $decision ) {
			$url = add_query_arg(
				array(
					'error' => 'access_denied',
					'state' => $state,
				),
				$redirect_uri
			);
			// wp_redirect (not wp_safe_redirect): this target is a third-party OAuth
			// client callback by design. Its safety comes from the exact-match check
			// against the client's registered redirect_uris in validate_request()
			// above — wp_safe_redirect's same-host restriction would incorrectly
			// block every legitimate external MCP client callback.
			wp_redirect( $url ); // phpcs:ignore WordPress.Security.SafeRedirect
			return;
		}

		$code = Token_Store::create_auth_code(
			$validated['params']['client_id'],
			get_current_user_id(),
			$redirect_uri,
			$validated['params']['code_challenge'],
			$validated['params']['code_challenge_method'],
			$validated['params']['scope']
		);

		$url = add_query_arg(
			array(
				'code'  => $code,
				'state' => $state,
			),
			$redirect_uri
		);
		wp_redirect( $url ); // phpcs:ignore WordPress.Security.SafeRedirect
	}

	private function render_consent_page( array $client, array $params ): void {
		$site_name   = get_bloginfo( 'name' );
		$client_name = esc_html( $client['client_name'] ?: 'An application' );
		$nonce       = wp_create_nonce( self::NONCE_ACTION );
		$action_url  = esc_url( home_url( self::PATH ) );

		header( 'Content-Type: text/html; charset=utf-8' );
		?>
		<!DOCTYPE html>
		<html>
		<head>
			<meta charset="utf-8">
			<title>Authorize MCP Access — <?php echo esc_html( $site_name ); ?></title>
			<meta name="viewport" content="width=device-width, initial-scale=1">
			<style>
				body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; background: #f0f0f1; margin: 0; padding: 40px 20px; }
				.card { max-width: 420px; margin: 0 auto; background: #fff; border-radius: 8px; padding: 32px; box-shadow: 0 1px 3px rgba(0,0,0,.1); }
				h1 { font-size: 18px; margin: 0 0 8px; }
				p { color: #555; line-height: 1.5; }
				.scope-box { background: #f6f7f7; border: 1px solid #dcdcde; border-radius: 4px; padding: 12px 16px; margin: 16px 0; font-size: 13px; }
				.buttons { display: flex; gap: 12px; margin-top: 24px; }
				button { flex: 1; padding: 10px 16px; border-radius: 4px; border: 1px solid #ccc; font-size: 14px; cursor: pointer; }
				.approve { background: #2271b1; color: #fff; border-color: #2271b1; }
				.deny { background: #fff; color: #333; }
			</style>
		</head>
		<body>
			<div class="card">
				<h1><?php echo esc_html( $client_name ); ?> wants to access</h1>
				<p><strong><?php echo esc_html( $site_name ); ?></strong> via the Model Context Protocol.</p>
				<div class="scope-box">
					This will allow the application to read and manage your site's content
					(posts, pages, media, and settings) with your administrator permissions.
				</div>
				<form method="post" action="<?php echo $action_url; ?>">
					<?php foreach ( $params as $key => $value ) : ?>
						<input type="hidden" name="<?php echo esc_attr( $key ); ?>" value="<?php echo esc_attr( $value ); ?>">
					<?php endforeach; ?>
					<input type="hidden" name="response_type" value="code">
					<input type="hidden" name="_wpnonce" value="<?php echo esc_attr( $nonce ); ?>">
					<div class="buttons">
						<button type="submit" name="mcp_oauth_decision" value="deny" class="deny">Deny</button>
						<button type="submit" name="mcp_oauth_decision" value="approve" class="approve">Approve</button>
					</div>
				</form>
			</div>
		</body>
		</html>
		<?php
	}

	private function render_error_page( WP_Error $error ): void {
		header( 'Content-Type: text/html; charset=utf-8' );
		status_header( (int) ( $error->get_error_data()['status'] ?? 400 ) );
		echo '<p style="font-family:sans-serif;max-width:420px;margin:60px auto;">' . esc_html( $error->get_error_message() ) . '</p>';
	}
}
