<?php
/**
 * Editorial workflow tools: move a post through Draft -> Review -> Publish,
 * and schedule a post for a future date/time.
 *
 * "in_review" maps to WordPress core's `pending` status (Pending Review), which works
 * out of the box. If Edit Flow / PublishPress custom statuses are installed and registered,
 * those status slugs are also accepted.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Axon_Workflow_Tools {

	/**
	 * @return array<int, array<string, mixed>>
	 */
	public static function tools() {
		return array(
			array(
				'name'        => 'set_editorial_status',
				'description' => 'Move a post through the editorial workflow. status: "draft", "in_review" (Pending Review), or "publish". Publishing requires publish capability.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'post_id' => array(
							'type'        => 'integer',
							'description' => 'The ID of the post or page.',
						),
						'status'  => array(
							'type'        => 'string',
							'description' => 'Target editorial status.',
							'enum'        => array( 'draft', 'in_review', 'publish' ),
						),
					),
					'required'   => array( 'post_id', 'status' ),
				),
				'callback'    => array( __CLASS__, 'set_editorial_status' ),
			),
			array(
				'name'        => 'schedule_post',
				'description' => 'Schedule a post to publish automatically at a future date/time. Sets status to "future".',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'post_id'   => array(
							'type'        => 'integer',
							'description' => 'The ID of the post or page.',
						),
						'datetime'  => array(
							'type'        => 'string',
							'description' => 'Future publish time. ISO 8601, e.g. "2026-07-01T09:00:00". Interpreted in the site timezone unless an offset is given.',
						),
					),
					'required'   => array( 'post_id', 'datetime' ),
				),
				'callback'    => array( __CLASS__, 'schedule_post' ),
			),
		);
	}

	/**
	 * @param array $args
	 * @return array|WP_Error
	 */
	public static function set_editorial_status( $args ) {
		$post = self::resolve_editable_post( $args );
		if ( is_wp_error( $post ) ) {
			return $post;
		}

		$requested = isset( $args['status'] ) ? sanitize_key( $args['status'] ) : '';
		$map        = array(
			'draft'     => 'draft',
			'in_review' => 'pending',
			'publish'   => 'publish',
		);

		if ( isset( $map[ $requested ] ) ) {
			$wp_status = $map[ $requested ];
		} elseif ( in_array( $requested, self::known_statuses(), true ) ) {
			// Allow custom statuses from Edit Flow / PublishPress if registered.
			$wp_status = $requested;
		} else {
			return new WP_Error( 'invalid_status', 'status must be one of: draft, in_review, publish (or a registered custom status).' );
		}

		if ( 'publish' === $wp_status && ! current_user_can( 'publish_post', $post->ID ) ) {
			return new WP_Error( 'forbidden', 'You do not have permission to publish this post.' );
		}

		$result = wp_update_post(
			array(
				'ID'          => $post->ID,
				'post_status' => $wp_status,
			),
			true
		);
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return array(
			'post_id'           => $post->ID,
			'requested_status'  => $requested,
			'wordpress_status'  => get_post_status( $post->ID ),
		);
	}

	/**
	 * @param array $args
	 * @return array|WP_Error
	 */
	public static function schedule_post( $args ) {
		$post = self::resolve_editable_post( $args );
		if ( is_wp_error( $post ) ) {
			return $post;
		}
		if ( ! current_user_can( 'publish_post', $post->ID ) ) {
			return new WP_Error( 'forbidden', 'Scheduling requires permission to publish this post.' );
		}

		$raw = isset( $args['datetime'] ) ? trim( (string) $args['datetime'] ) : '';
		$ts  = strtotime( $raw );
		if ( ! $raw || false === $ts ) {
			return new WP_Error( 'invalid_datetime', 'Provide a valid future datetime, e.g. "2026-07-01T09:00:00".' );
		}
		if ( $ts <= current_time( 'timestamp' ) ) {
			return new WP_Error( 'not_future', 'The scheduled time must be in the future.' );
		}

		$post_date     = gmdate( 'Y-m-d H:i:s', $ts - ( (int) ( get_option( 'gmt_offset' ) * HOUR_IN_SECONDS ) ) );
		$post_date_loc = gmdate( 'Y-m-d H:i:s', $ts );

		$result = wp_update_post(
			array(
				'ID'            => $post->ID,
				'post_status'   => 'future',
				'post_date'     => $post_date_loc,
				'post_date_gmt' => $post_date,
			),
			true
		);
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return array(
			'post_id'          => $post->ID,
			'wordpress_status' => get_post_status( $post->ID ),
			'scheduled_for'    => $post_date_loc . ' (site time)',
		);
	}

	/* ---------- helpers ---------- */

	/**
	 * @return WP_Post|WP_Error
	 */
	protected static function resolve_editable_post( $args ) {
		$post_id = isset( $args['post_id'] ) ? absint( $args['post_id'] ) : 0;
		if ( ! $post_id ) {
			return new WP_Error( 'invalid_post_id', 'A valid post_id is required.' );
		}
		$post = get_post( $post_id );
		if ( ! $post ) {
			return new WP_Error( 'not_found', "No post found with ID {$post_id}." );
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return new WP_Error( 'forbidden', 'You do not have permission to edit this post.' );
		}
		return $post;
	}

	protected static function known_statuses() {
		return array_values( get_post_stati() );
	}
}
