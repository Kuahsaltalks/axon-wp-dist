<?php
/**
 * Media tools: set the alt text on an image in the Media Library.
 * Alt text matters for accessibility (WCAG) and for AI/answer-engine readability (AEO).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Axon_Media_Tools {

	const ALT_META = '_wp_attachment_image_alt';

	/**
	 * @return array<int, array<string, mixed>>
	 */
	public static function tools() {
		return array(
			array(
				'name'        => 'set_media_alt_text',
				'description' => 'Set (or clear) the alternative text on a Media Library image attachment, for accessibility and SEO/AEO.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'attachment_id' => array(
							'type'        => 'integer',
							'description' => 'The ID of the media attachment (image).',
						),
						'alt_text'      => array(
							'type'        => 'string',
							'description' => 'Descriptive alt text. Pass an empty string to clear it.',
						),
					),
					'required'   => array( 'attachment_id', 'alt_text' ),
				),
				'callback'    => array( __CLASS__, 'set_media_alt_text' ),
			),
		);
	}

	/**
	 * @param array $args
	 * @return array|WP_Error
	 */
	public static function set_media_alt_text( $args ) {
		$attachment_id = isset( $args['attachment_id'] ) ? absint( $args['attachment_id'] ) : 0;
		if ( ! $attachment_id ) {
			return new WP_Error( 'invalid_attachment_id', 'A valid attachment_id is required.' );
		}
		if ( ! array_key_exists( 'alt_text', $args ) ) {
			return new WP_Error( 'missing_alt_text', 'alt_text is required (use an empty string to clear).' );
		}

		$post = get_post( $attachment_id );
		if ( ! $post || 'attachment' !== $post->post_type ) {
			return new WP_Error( 'not_found', "No media attachment found with ID {$attachment_id}." );
		}
		if ( 0 !== strpos( (string) get_post_mime_type( $post ), 'image/' ) ) {
			return new WP_Error( 'not_an_image', 'Alt text only applies to image attachments.' );
		}
		// Editing an attachment is gated by edit_post on the attachment; upload_files is the broader media cap.
		if ( ! current_user_can( 'edit_post', $attachment_id ) ) {
			return new WP_Error( 'forbidden', 'You do not have permission to edit this media item.' );
		}

		$alt = sanitize_text_field( (string) $args['alt_text'] );
		update_post_meta( $attachment_id, self::ALT_META, $alt );

		return array(
			'attachment_id' => $attachment_id,
			'alt_text'      => $alt,
			'cleared'       => '' === $alt,
		);
	}
}
