=== Axon ===
Contributors: waahschool
Requires at least: 6.9
Requires PHP: 8.0
Stable tag: 2.5.4
License: GPL-2.0-or-later

Turn WordPress into a site your AI can run. One install, nothing else needed: the MCP
server, one-click sign-in, and 24 tools for SEO, speed, security, AI-search visibility,
schema and redirects. Self-hosted, no subscription, and it updates itself.

== Description ==

**Install one plugin. That is the whole setup.**

No companion plugins, no dependencies to chase, no tokens to generate. Activate it, open
the **Axon** screen, copy your connection URL, and paste it into Claude, Codex, or any
other MCP client. Everything needed is inside:

**The MCP server.** Bundled, so there is nothing else to install. If you already run the
standalone MCP Adapter plugin, that one is used instead and the two never conflict.

**One-click sign-in.** A full OAuth 2.1 authorization server (PKCE, dynamic client
registration, discovery metadata). Your client sends you to your own WordPress login, you
click Authorize, and you are connected. No token to generate, copy, or paste, and nothing
to redo when one expires.

**32 tools.** Everything an assistant needs to *build and run* the site, not just audit it:
create and edit posts and pages, upload media, manage categories, tags and settings, plus the
full SEO, speed, schema, redirect and AI-visibility toolkit. Every tool checks the connected
user's WordPress capabilities before acting, so it can never exceed what that account could
already do in wp-admin.

**Direct REST access.** A `wp_rest` tool reaches any WordPress REST route — menus, comments,
users, plugins, and anything a plugin like WooCommerce or ACF registers — so the plugin is not
limited to the tools shipped with it.

**Guided setup.** The Axon screen shows live status — is the server running, how many
tools registered, is OAuth ready, is HTTPS on — plus copy-paste instructions for each
client. If something is not working, that screen tells you which part.

= Content control =
* `create_post` / `update_post` — create and edit posts, pages and custom post types. Partial
  updates only change the fields you pass.
* `get_post` / `list_posts` — read and search content, including Elementor layout data.
* `delete_post` — trashes by default; permanent removal needs an explicit flag.
* `manage_terms` — list, create, rename and delete categories and tags.
* `upload_media` — add images from a URL or base64, with alt text set at upload time.
* `wp_rest` — call any WordPress REST route directly.

= Content & workflow =
* `get_seo_meta` / `set_seo_meta` — read and write meta title, description, focus keyword.
* `seo_readiness_check` — pre-publish SEO and accessibility checklist (read-only).
* `set_media_alt_text` — set alt text on a Media Library image.
* `set_editorial_status` — Draft → Pending → Publish.
* `schedule_post` — schedule a post for a future date and time.

= Speed =
* `get_performance_report` — media formats, WebP coverage, autoloaded option size,
  revisions, transients.
* `convert_media_to_webp` — converts JPEG/PNG to WebP **locally** via GD or Imagick. No
  QUIC.cloud, no account, no per-image fee. Originals are never modified.
* `enable_webp_delivery` — serve the WebP copies to browsers that accept them.
* `cleanup_database` — remove revisions, spam, expired transients.

= Security =
* `audit_plugins` — inactive, abandoned and known-destructive plugins.
* `audit_site_hardening` — file permissions, editor access, XML-RPC, version disclosure.
* `check_core_integrity` — compare core files against the official checksums.

All three are read-only. This plugin reports; it never silently changes security settings.

= AI search visibility (GEO / AEO) =
* `audit_ai_crawlers` — whether GPTBot, ClaudeBot, PerplexityBot and others can read the site.
* `audit_ai_readiness` — passage-level citability scoring.
* `generate_llms_txt` — publish an llms.txt.
* `find_orphan_pages` — pages nothing links to.

= Structured data =
* `generate_schema` / `apply_schema` / `validate_schema` / `audit_schema_coverage` —
  JSON-LD, with conflict detection against Rank Math and Yoast.

= Redirects =
* `manage_redirects` — redirects fire only on a real 404, so nothing is intercepted that
  currently works.
* `audit_404s` — 404 log with suggested targets.
* `find_broken_links` — internal links pointing at nothing.

== Updates ==

After the first upload, this plugin keeps itself up to date. New versions appear on your
Plugins screen with the normal "Update now" link — no re-uploading zips.

WordPress checks roughly every 12 hours. To check immediately, use the
**Check for updates** link in this plugin's row on the Plugins screen.

If the update server is ever unreachable, nothing breaks: the site keeps running the
version it has and simply tries again later.

== Installation ==

1. **Plugins → Add New → Upload Plugin**, choose the zip, **Install Now**, **Activate**.
2. Open **Axon** in the admin menu. It shows your connection URL and the steps.
3. Paste that URL into your AI client and click Authorize.

That is the entire setup. Requires WordPress 6.9 or newer (for the core Abilities API) and
HTTPS, which MCP clients require.

Upgrading from the older split plugins? Activating this one offers a single button to
retire *Waah School WP MCP Extensions* and *MCP OAuth Bridge*. Existing OAuth connections
keep working — you do not need to reconnect.

== Frequently Asked Questions ==

= Do I need any other plugin? =

No. The MCP server is bundled and the Abilities API is part of WordPress core from 6.9.
Earlier versions of this plugin needed *MCP Adapter* and *WordPress MCP* alongside them;
2.0.0 does not.

= I already have the MCP Adapter plugin installed. =

Fine — it is detected and used, and the bundled copy stays out of the way. Nothing
conflicts and nothing is registered twice.

== Changelog ==

= 2.0.0 =
* **One plugin, no dependencies.** The MCP server is now bundled, so *MCP Adapter* and
  *WordPress MCP* are no longer required. Install this and nothing else.
* Added the **Axon** setup screen: live status checks, your connection URL with a copy
  button, and step-by-step instructions for Claude, Claude Desktop/Code and Codex.
* An existing standalone MCP Adapter install is detected and takes precedence, so the two
  can never collide.

= 1.0.0 =
* Merged *Waah School WP MCP Extensions* (0.7.1) and *MCP OAuth Bridge* (0.2.0) into a
  single plugin with one version number.
* Added self-updating: new versions install with one click from the Plugins screen.
* Added a **Check for updates** link for checking without waiting for the 12-hour cycle.
* Existing OAuth tokens are preserved across the merge — connected clients stay connected.
